const fs = require('fs');
const path = require('path');

const replacements = [
  { regex: /bg-\[#050505\]\/90/g, replacement: 'bg-glass-bg' },
  { regex: /bg-\[#0A0A0A\]\/80/g, replacement: 'bg-glass-bg' },
  { regex: /bg-\[#050505\]/g, replacement: 'bg-bg-primary' },
  { regex: /bg-\[#0A0A0A\]/g, replacement: 'bg-bg-secondary' },
  { regex: /bg-white\/\[0\.02\]/g, replacement: 'bg-bg-card' },
  { regex: /bg-white\/\[0\.03\]/g, replacement: 'bg-bg-card' },
  { regex: /hover:bg-white\/\[0\.04\]/g, replacement: 'hover:bg-bg-card-hover' },
  { regex: /hover:bg-white\/\[0\.08\]/g, replacement: 'hover:bg-bg-card-hover' },
  { regex: /bg-white\/5/g, replacement: 'bg-bg-card' },
  { regex: /hover:bg-white\/10/g, replacement: 'hover:bg-bg-card-hover' },
  { regex: /border-white\/5/g, replacement: 'border-glass-border' },
  { regex: /border-white\/10/g, replacement: 'border-border-color' },
  { regex: /hover:border-white\/10/g, replacement: 'hover:border-border-hover' },
  { regex: /text-gray-200/g, replacement: 'text-text-primary' },
  { regex: /text-gray-300/g, replacement: 'text-text-primary' },
  { regex: /text-gray-400/g, replacement: 'text-text-secondary' },
  { regex: /text-gray-500/g, replacement: 'text-text-muted' },
  { regex: /text-white/g, replacement: 'text-text-primary' },
  { regex: /backdrop-blur-\[45px\]/g, replacement: 'backdrop-blur-[var(--blur-strength)]' },
  { regex: /backdrop-blur-2xl/g, replacement: 'backdrop-blur-[var(--blur-strength)]' },
  { regex: /text-cyan-400/g, replacement: 'text-accent-primary' },
  { regex: /text-cyan-500/g, replacement: 'text-accent-primary' },
  { regex: /bg-cyan-500/g, replacement: 'bg-accent-primary' },
  { regex: /border-cyan-500/g, replacement: 'border-accent-primary' },
];

function processDirectory(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      processDirectory(fullPath);
    } else if (fullPath.endsWith('.tsx') || fullPath.endsWith('.ts')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      let original = content;
      for (const { regex, replacement } of replacements) {
        content = content.replace(regex, replacement);
      }
      if (content !== original) {
        fs.writeFileSync(fullPath, content, 'utf8');
        console.log(`Updated ${fullPath}`);
      }
    }
  }
}

processDirectory('./src/components');
