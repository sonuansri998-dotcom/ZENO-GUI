import { useState, useEffect } from 'react';

export const useSystemMetrics = () => {
  const [cpu, setCpu] = useState(12);
  const [ram, setRam] = useState(3.2); // GB
  const [ping, setPing] = useState(24); // ms
  const [networkActivity, setNetworkActivity] = useState([10, 25, 40, 30, 50, 20, 60, 45, 30, 55]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCpu(prev => Math.min(100, Math.max(5, prev + (Math.random() * 10 - 5))));
      setRam(prev => Math.min(8, Math.max(2, prev + (Math.random() * 0.5 - 0.25))));
      setPing(prev => Math.max(5, prev + (Math.random() * 10 - 5)));
      
      setNetworkActivity(prev => {
        const next = [...prev.slice(1), Math.random() * 100];
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return { cpu, ram, ping, networkActivity };
};
