/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Starfield } from '@/components/visuals/Starfield';
import { Header } from '@/components/layout/Header';
import { LeftPanel } from '@/components/hub/LeftPanel';
import { CenterPanel } from '@/components/hub/CenterPanel';
import { RightPanel } from '@/components/hub/RightPanel';
import { Dashboard } from '@/components/dashboard/Dashboard';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [view, setView] = useState<'hub' | 'dashboard'>('hub');
  const [dashboardTab, setDashboardTab] = useState<string>('overview');

  const handleViewChange = (newView: 'hub' | 'dashboard', tab?: string) => {
    if (tab) setDashboardTab(tab);
    setView(newView);
  };

  if (view === 'dashboard') {
    return <Dashboard onBack={() => setView('hub')} initialTab={dashboardTab} />;
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-bg-primary text-text-primary font-inter selection:bg-accent-primary/30 selection:text-white flex flex-col">
      <Starfield />
      
      <Header onViewChange={handleViewChange} currentView={view} />

      <div className="flex-1 overflow-hidden relative w-full max-w-[1920px] mx-auto">
        <AnimatePresence mode="wait">
          <motion.div 
            key="hub"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-12 gap-4 p-4 h-full"
          >
            {/* Left Panel - System & History */}
            <div className="col-span-3 h-full min-w-[300px] flex flex-col overflow-hidden">
              <LeftPanel />
            </div>

            {/* Center Panel - Conversational Core */}
            <div className="col-span-6 h-full relative min-w-[400px] flex flex-col overflow-hidden">
              <CenterPanel />
            </div>

            {/* Right Panel - Vision & Action */}
            <div className="col-span-3 h-full min-w-[300px] flex flex-col overflow-hidden">
              <RightPanel />
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

