import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface BackToChatButtonProps {
  onClick: () => void;
  className?: string;
}

export const BackToChatButton: React.FC<BackToChatButtonProps> = ({ onClick, className = "" }) => {
  return (
    <button 
      onClick={onClick}
      className={`back-to-chat-btn flex items-center gap-3 pl-4 pr-6 py-2.5 rounded-full bg-bg-card/80 backdrop-blur-md border border-border-color hover:border-accent-primary/30 shadow-lg ${className}`}
    >
      {/* Icon Container */}
      <div className="arrow-icon relative z-10 flex items-center justify-center">
        <ArrowLeft size={16} className="text-text-secondary group-hover:text-accent-primary transition-colors duration-300" />
      </div>
      
      {/* Text Container */}
      <div className="relative z-10 flex flex-col items-start justify-center h-full">
        <span className="text-[11px] font-bold uppercase tracking-[0.2em] leading-none text-text-secondary group-hover:text-text-primary transition-colors duration-300">
          Back to Chat
        </span>
      </div>
    </button>
  );
};
