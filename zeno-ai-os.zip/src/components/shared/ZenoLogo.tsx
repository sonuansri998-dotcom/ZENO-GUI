import React from 'react';
import { Box } from 'lucide-react';

interface ZenoLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const ZenoLogo: React.FC<ZenoLogoProps> = ({ className = "", size = 'md', showText = true }) => {
  const sizeMap = {
    sm: { icon: 24, text: 'text-lg' },
    md: { icon: 32, text: 'text-2xl' },
    lg: { icon: 44, text: 'text-4xl' },
    xl: { icon: 88, text: 'text-7xl' }
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      <div className="relative flex items-center justify-center">
        <div className="absolute inset-0 bg-white/5 blur-sm rounded-full" />
        <Box 
          size={sizeMap[size].icon} 
          className="text-white relative z-10 drop-shadow-[0_0_4px_rgba(255,255,255,0.3)]" 
          strokeWidth={2}
        />
      </div>
      {showText && (
        <span className={`font-bold tracking-wide text-white ${sizeMap[size].text}`}>
          ZENO
        </span>
      )}
    </div>
  );
};
