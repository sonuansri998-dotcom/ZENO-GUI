import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Save } from 'lucide-react';

interface SaveButtonProps {
  onSave: () => void;
  disabled?: boolean;
  isDirty?: boolean;
  noWrapper?: boolean;
}

export const SaveButton: React.FC<SaveButtonProps> = ({ onSave, disabled = false, isDirty = false, noWrapper = false }) => {
  const [isSaved, setIsSaved] = useState(false);

  const handleClick = () => {
    onSave();
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const button = (
    <button
      onClick={handleClick}
      disabled={disabled}
      className={`
        relative overflow-hidden px-6 py-3 rounded-xl font-bold text-sm flex items-center gap-2 transition-colors
        ${disabled 
          ? 'bg-bg-card text-text-muted cursor-not-allowed border border-glass-border' 
          : 'bg-accent-primary text-black hover:bg-accent-primary/80 shadow-[0_0_20px_rgba(6,182,212,0.3)] border border-accent-primary'
        }
      `}
    >
      <AnimatePresence mode="wait">
        {isSaved ? (
          <motion.div
            key="saved"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
            className="flex items-center gap-2"
          >
            <Check size={18} />
            <span>Settings Saved</span>
          </motion.div>
        ) : (
          <motion.div
            key="save"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
            className="flex items-center gap-2"
          >
            <Save size={18} />
            <span>Save Changes</span>
          </motion.div>
        )}
      </AnimatePresence>
    </button>
  );

  if (noWrapper) {
    return button;
  }

  return (
    <div className="flex justify-end pt-6 border-t border-glass-border mt-6">
      {button}
    </div>
  );
};
