import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle } from 'lucide-react';

interface ConfirmationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDanger?: boolean;
}

export const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = "Confirm",
  cancelText = "Cancel",
  isDanger = false,
}) => {
  const dialogRef = useRef<HTMLDivElement>(null);

  // Handle ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  // Handle Focus Trap and Auto Focus
  useEffect(() => {
    if (isOpen && dialogRef.current) {
      // Auto Focus the confirm button (or cancel if preferred, but usually confirm for dialogs unless destructive)
      // For destructive actions, maybe focus cancel? The prompt says "Auto Focus... focus the first input field".
      // Here we have buttons. Let's focus the Cancel button for safety in danger dialogs, or Confirm otherwise.
      // Actually, standard behavior is often to focus the primary action or the first focusable element.
      // Let's focus the first focusable element (Cancel button usually comes first in DOM order if we look at the code? No, Cancel is first).
      
      const focusableElements = dialogRef.current.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      
      const firstElement = focusableElements[0] as HTMLElement;
      const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

      // Focus the first element (Cancel button)
      if (firstElement) {
        firstElement.focus();
      }

      const handleTabKey = (e: KeyboardEvent) => {
        if (e.key === 'Tab') {
          if (e.shiftKey) {
            if (document.activeElement === firstElement) {
              e.preventDefault();
              lastElement.focus();
            }
          } else {
            if (document.activeElement === lastElement) {
              e.preventDefault();
              firstElement.focus();
            }
          }
        }
      };

      const currentDialog = dialogRef.current;
      currentDialog.addEventListener('keydown', handleTabKey);
      return () => {
        currentDialog.removeEventListener('keydown', handleTabKey);
      };
    }
  }, [isOpen]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
            className="absolute inset-0 bg-black/55 backdrop-blur-[6px]"
            onClick={onClose}
          />

          {/* Dialog */}
          <motion.div
            ref={dialogRef}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ 
              duration: 0.22,
              ease: [0.4, 0, 0.2, 1]
            }}
            className={`relative w-full max-w-md overflow-hidden rounded-2xl border ${
              isDanger ? 'border-error/30 bg-[#0A0A0A]' : 'border-white/10 bg-[#0A0A0A]'
            } p-8 shadow-[0_20px_60px_rgba(0,0,0,0.8)]`}
            role="dialog"
            aria-modal="true"
            aria-labelledby="dialog-title"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-4">
              <div className={`rounded-full p-3 shrink-0 ${
                isDanger ? 'bg-error/10 text-error' : 'bg-bg-card text-text-primary'
              }`}>
                <AlertTriangle size={24} />
              </div>
              
              <div className="flex-1">
                <h3 id="dialog-title" className="text-lg font-bold text-text-primary font-space mb-2">
                  {title}
                </h3>
                <p className="text-sm text-text-secondary leading-relaxed mb-6">
                  {message}
                </p>

                <div className="flex justify-end gap-3">
                  <button
                    onClick={onClose}
                    className="px-4 py-2 text-sm font-medium text-text-secondary hover:text-text-primary transition-colors"
                  >
                    {cancelText}
                  </button>
                  <button
                    onClick={onConfirm}
                    className={`px-4 py-2 text-sm font-bold rounded-lg transition-colors ${
                      isDanger 
                        ? 'bg-error hover:bg-error/80 text-text-primary shadow-[0_0_15px_rgba(244,63,94,0.4)]' 
                        : 'bg-white text-black hover:bg-gray-200'
                    }`}
                  >
                    {confirmText}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
};
