import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Clock } from 'lucide-react';

interface CustomDatePickerProps {
  value: Date | null;
  onChange: (date: Date) => void;
  placeholder?: string;
  className?: string;
}

export const CustomDatePicker: React.FC<CustomDatePickerProps> = ({
  value,
  onChange,
  placeholder = 'Select date & time',
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [currentMonth, setCurrentMonth] = useState(value || new Date());

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay();
  
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const blanks = Array.from({ length: firstDayOfMonth }, (_, i) => i);

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const handleDateSelect = (day: number) => {
    const newDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    if (value) {
      newDate.setHours(value.getHours());
      newDate.setMinutes(value.getMinutes());
    } else {
      newDate.setHours(12);
      newDate.setMinutes(0);
    }
    onChange(newDate);
    setIsOpen(false);
  };

  const formatDate = (date: Date | null) => {
    if (!date) return '';
    return date.toLocaleString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  return (
    <div className={`relative ${className}`} ref={containerRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-bg-secondary border border-border-color rounded-xl p-3.5 text-sm text-text-primary focus:border-accent-primary/50 focus:ring-1 focus:ring-accent-primary/50 outline-none transition-all shadow-inner flex items-center justify-between"
      >
        <span className={value ? 'text-text-primary' : 'text-text-muted'}>
          {value ? formatDate(value) : placeholder}
        </span>
        <CalendarIcon size={16} className="text-text-muted" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -10 }}
            transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
            className="absolute z-50 w-72 mt-2 right-0 md:left-0 bg-bg-secondary border border-border-color rounded-xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden backdrop-blur-xl"
            style={{ transformOrigin: 'top center' }}
          >
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <button onClick={handlePrevMonth} className="p-2 hover:bg-white/5 rounded-lg transition-colors">
                  <ChevronLeft size={16} className="text-text-primary" />
                </button>
                <div className="text-sm font-bold text-text-primary">
                  {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                </div>
                <button onClick={handleNextMonth} className="p-2 hover:bg-white/5 rounded-lg transition-colors">
                  <ChevronRight size={16} className="text-text-primary" />
                </button>
              </div>

              <div className="grid grid-cols-7 gap-1 mb-2">
                {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(day => (
                  <div key={day} className="text-center text-[10px] font-bold text-text-muted uppercase tracking-wider">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1">
                {blanks.map(blank => (
                  <div key={`blank-${blank}`} className="h-8" />
                ))}
                {days.map(day => {
                  const isSelected = value && 
                    value.getDate() === day && 
                    value.getMonth() === currentMonth.getMonth() && 
                    value.getFullYear() === currentMonth.getFullYear();
                  
                  const isToday = new Date().getDate() === day && 
                    new Date().getMonth() === currentMonth.getMonth() && 
                    new Date().getFullYear() === currentMonth.getFullYear();

                  return (
                    <button
                      key={day}
                      onClick={() => handleDateSelect(day)}
                      className={`h-8 rounded-lg text-xs flex items-center justify-center transition-all duration-200 ${
                        isSelected 
                          ? 'bg-accent-primary text-black font-bold shadow-[0_0_20px_rgba(0,229,255,0.3)]' 
                          : isToday
                            ? 'bg-white/10 text-text-primary font-bold border border-white/20'
                            : 'text-text-primary hover:bg-white/5'
                      }`}
                    >
                      {day}
                    </button>
                  );
                })}
              </div>

              <div className="mt-4 pt-4 border-t border-border-color flex items-center justify-between">
                <div className="flex items-center gap-2 text-text-muted">
                  <Clock size={14} />
                  <span className="text-xs">Time</span>
                </div>
                <div className="flex items-center gap-1">
                  <select 
                    className="bg-bg-primary border border-border-color rounded-md px-2 py-1 text-xs text-text-primary outline-none focus:border-accent-primary/50"
                    value={value ? value.getHours().toString().padStart(2, '0') : '12'}
                    onChange={(e) => {
                      if (!value) return;
                      const newDate = new Date(value);
                      newDate.setHours(parseInt(e.target.value));
                      onChange(newDate);
                    }}
                  >
                    {Array.from({ length: 24 }, (_, i) => (
                      <option key={i} value={i.toString().padStart(2, '0')}>{i.toString().padStart(2, '0')}</option>
                    ))}
                  </select>
                  <span className="text-text-muted text-xs">:</span>
                  <select 
                    className="bg-bg-primary border border-border-color rounded-md px-2 py-1 text-xs text-text-primary outline-none focus:border-accent-primary/50"
                    value={value ? value.getMinutes().toString().padStart(2, '0') : '00'}
                    onChange={(e) => {
                      if (!value) return;
                      const newDate = new Date(value);
                      newDate.setMinutes(parseInt(e.target.value));
                      onChange(newDate);
                    }}
                  >
                    {['00', '15', '30', '45'].map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
