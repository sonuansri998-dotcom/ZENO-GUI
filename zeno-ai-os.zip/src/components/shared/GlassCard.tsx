import React from 'react';
import { cn } from '@/lib/utils';

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: boolean;
  variant?: 'default' | 'deep';
}

export const GlassCard: React.FC<GlassCardProps> = ({ children, className, hoverEffect = false, variant = 'default', ...props }) => {
  return (
    <div
      className={cn(
        variant === 'deep' ? "bg-black/40" : "bg-white/5",
        "backdrop-blur-md rounded-xl p-4 transition-all duration-300 border border-white/10",
        hoverEffect && "hover:bg-white/10 hover:border-white/20 hover:shadow-[0_0_20px_rgba(255,255,255,0.05)]",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};
