import React, { useState, useEffect } from 'react';
import { Zap } from 'lucide-react';

interface ProviderLogoProps {
  providerName: string;
  modelName?: string;
  className?: string;
  iconSize?: number;
  fallbackColor?: string;
}

export const ProviderLogo: React.FC<ProviderLogoProps> = ({
  providerName,
  modelName = '',
  className = '',
  iconSize = 18,
  fallbackColor = 'text-accent-primary'
}) => {
  const [attemptIndex, setAttemptIndex] = useState(0);
  const [prevProps, setPrevProps] = useState({ providerName, modelName });

  if (providerName !== prevProps.providerName || modelName !== prevProps.modelName) {
    setAttemptIndex(0);
    setPrevProps({ providerName, modelName });
  }

  const domains = getCandidateDomains(providerName, modelName);
  const urls = domains.flatMap(d => [
    `https://logo.clearbit.com/${d}`,
    `https://www.google.com/s2/favicons?domain=${d}&sz=128`
  ]);

  const handleError = () => {
    setAttemptIndex(prev => prev + 1);
  };

  if (urls.length === 0 || attemptIndex >= urls.length) {
    return <Zap size={iconSize} className={fallbackColor} />;
  }

  return (
    <img
      src={urls[attemptIndex]}
      alt={`${providerName} logo`}
      className={`object-contain ${className}`}
      onError={handleError}
      referrerPolicy="no-referrer"
    />
  );
};

// Helper to generate candidate domains based on heuristics
const getCandidateDomains = (providerName: string, modelName: string): string[] => {
  const text = (providerName + ' ' + modelName).toLowerCase();
  const domains: string[] = [];

  // 1. Keyword Matching (High Priority)
  if (text.includes('openai') || text.includes('gpt')) domains.push('openai.com');
  if (text.includes('claude')) domains.push('claude.ai'); // Prioritize claude.ai for Claude
  if (text.includes('anthropic') || text.includes('claude') || text.includes('sonnet') || text.includes('opus')) domains.push('anthropic.com');
  if (text.includes('google') || text.includes('gemini') || text.includes('palm') || text.includes('bard')) domains.push('google.com');
  if (text.includes('deepseek')) domains.push('deepseek.com');
  if (text.includes('mistral') || text.includes('mixtral')) domains.push('mistral.ai');
  if (text.includes('groq')) domains.push('groq.com');
  if (text.includes('openrouter')) domains.push('openrouter.ai');
  if (text.includes('together')) domains.push('together.ai');
  if (text.includes('perplexity')) domains.push('perplexity.ai');
  if (text.includes('ollama')) domains.push('ollama.ai');
  if (text.includes('meta') || text.includes('llama')) domains.push('meta.com');
  if (text.includes('microsoft') || text.includes('bing')) domains.push('microsoft.com');
  if (text.includes('cohere')) domains.push('cohere.com');
  if (text.includes('huggingface')) domains.push('huggingface.co');
  if (text.includes('replicate')) domains.push('replicate.com');
  if (text.includes('midjourney')) domains.push('midjourney.com');
  if (text.includes('stability') || text.includes('stable diffusion')) domains.push('stability.ai');

  // 2. Name-based Guessing (Medium Priority)
  // Clean the provider name to create a potential domain
  const cleanName = providerName.toLowerCase().replace(/[^a-z0-9]/g, '');
  if (cleanName) {
    // Avoid duplicates
    if (!domains.includes(`${cleanName}.com`)) domains.push(`${cleanName}.com`);
    if (!domains.includes(`${cleanName}.ai`)) domains.push(`${cleanName}.ai`);
    if (!domains.includes(`${cleanName}.io`)) domains.push(`${cleanName}.io`);
    if (!domains.includes(`${cleanName}.org`)) domains.push(`${cleanName}.org`);
  }

  return domains;
};
