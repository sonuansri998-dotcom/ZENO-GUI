import React from 'react';

interface PremiumToggleProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  colorClass?: string;
}

export const PremiumToggle: React.FC<PremiumToggleProps> = ({
  checked,
  onChange,
  colorClass = 'bg-accent-primary'
}) => {
  return (
    <label className="relative inline-flex items-center cursor-pointer">
      <input 
        type="checkbox" 
        className="sr-only peer" 
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
      />
      <div className={`w-11 h-6 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-border-color after:border after:rounded-full after:h-5 after:w-5 after:transition-all transition-colors duration-300 ${checked ? colorClass : 'bg-[#2a2d36]'}`}></div>
    </label>
  );
};
