import React from 'react';
import { cn } from '@/lib/utils';
import { motion } from 'motion/react';

interface NeonButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'cyan' | 'lavender' | 'danger';
  children: React.ReactNode;
  icon?: React.ReactNode;
}

export const NeonButton: React.FC<NeonButtonProps> = ({ 
  variant = 'cyan', 
  children, 
  className, 
  icon,
  ...props 
}) => {
  const colors = {
    cyan: "border-zeno-cyan text-zeno-cyan hover:bg-zeno-cyan/10 hover:shadow-[0_0_20px_rgba(0,229,255,0.4)]",
    lavender: "border-zeno-lavender text-zeno-lavender hover:bg-zeno-lavender/10 hover:shadow-[0_0_20px_rgba(162,155,254,0.4)]",
    danger: "border-error text-error hover:bg-error/10 hover:shadow-[0_0_20px_rgba(239,68,68,0.4)]"
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        "relative flex items-center justify-center gap-2 px-6 py-2 rounded-lg border transition-all duration-300 font-syncopate text-xs font-bold tracking-widest uppercase",
        colors[variant],
        className
      )}
      {...props}
    >
      {icon && <span className="text-lg">{icon}</span>}
      {children}
    </motion.button>
  );
};
