import React, { useState, useEffect } from 'react';
import { Brain, Calendar, BarChart2, PieChart, Activity, MessageSquare, Hourglass, AlertTriangle } from 'lucide-react';

export const ContextWindow = () => {
  const [stats, setStats] = useState({
    total: 1048576,
    used: 862450,
    today: 850000,
    weekly: 895000,
    monthly: 1200000,
    lastMessage: 145
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => {
        const growth = Math.floor(Math.random() * 50) + 10;
        const lastMsg = Math.floor(Math.random() * 100) + 20;
        return {
          ...prev,
          used: Math.min(prev.used + growth, prev.total),
          today: prev.today + growth,
          weekly: prev.weekly + growth,
          monthly: prev.monthly + growth,
          lastMessage: lastMsg
        };
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const percentage = (stats.used / stats.total) * 100;
  const radius = 60;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  const remainingToday = stats.total - stats.today;
  const dailyQuotaPercent = (stats.today / stats.total) * 100;
  const showWarning = dailyQuotaPercent >= 80;

  const getStatus = (pct: number) => {
    if (pct < 60) return { label: 'OPTIMAL', color: 'text-success', bg: 'bg-success' };
    if (pct < 85) return { label: 'WARNING', color: 'text-warning', bg: 'bg-warning' };
    return { label: 'CRITICAL', color: 'text-error', bg: 'bg-error' };
  };

  const status = getStatus(percentage);

  const getCircleColor = (pct: number) => {
    if (pct >= 100) return '#8B0000';
    if (pct >= 80) return '#FF3333';
    if (pct > 50) return '#FFA500';
    return '#00FF88';
  };

  const getGlowConfig = (pct: number) => {
    if (pct < 80) return null;
    if (pct >= 100) return { base: 28, duration: 0.3, color: '#8B0000' };
    if (pct >= 96) return { base: 20, duration: 0.6, color: '#FF3333' };
    if (pct >= 91) return { base: 14, duration: 1.0, color: '#FF3333' };
    if (pct >= 86) return { base: 8, duration: 1.5, color: '#FF3333' };
    return { base: 4, duration: 2.0, color: '#FF3333' };
  };

  const circleColor = getCircleColor(percentage);
  const glowConfig = getGlowConfig(percentage);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-glass-border bg-bg-card p-5 transition-all duration-300 hover:border-border-color group shadow-lg">
      
      {/* Enhanced Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      <div className="absolute top-0 right-0 w-32 h-32 bg-bg-primary blur-[50px] rounded-full pointer-events-none opacity-50" />

      {/* Header */}
      <div className="mb-6 flex items-start justify-between relative z-10">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-bg-primary text-text-primary shadow-[0_0_10px_var(--shadow-color)]">
            <Brain size={18} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-text-primary antialiased tracking-wide">Context Window</h2>
          </div>
        </div>
        <div className={`flex items-center gap-2 rounded-full border border-glass-border bg-bg-primary px-2.5 py-1 ${status.color}`}>
          <div className={`h-1.5 w-1.5 rounded-full ${status.bg} shadow-[0_0_8px_currentColor]`} />
          <span className="text-[10px] font-bold tracking-wide antialiased uppercase">{status.label}</span>
        </div>
      </div>

      <div className="grid grid-cols-[140px_1fr] gap-6 relative z-10">
        {/* Circular Progress */}
        <div className="relative flex h-[140px] w-[140px] items-center justify-center shrink-0">
          <style>{`
            @keyframes circleGlow {
              0% { filter: drop-shadow(0 0 var(--glow-base) var(--glow-color)); }
              50% { filter: drop-shadow(0 0 calc(var(--glow-base) * 2) var(--glow-color)); }
              100% { filter: drop-shadow(0 0 var(--glow-base) var(--glow-color)); }
            }
          `}</style>
          <svg className="h-full w-full -rotate-90 transform">
            <circle cx="70" cy="70" r={radius} stroke="var(--border-color)" strokeWidth="6" fill="transparent" />
            <circle
              cx="70" cy="70" r={radius}
              stroke={circleColor}
              strokeWidth="6"
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="transition-all ease-out"
              style={{
                transition: 'stroke 0.8s ease, stroke-dashoffset 1.5s cubic-bezier(0.4,0,0.2,1)',
                ...(glowConfig ? {
                    '--glow-base': `${glowConfig.base}px`,
                    '--glow-color': glowConfig.color,
                    animation: `circleGlow ${glowConfig.duration}s infinite ease-in-out`
                } : {})
              } as React.CSSProperties}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span 
              className="text-2xl font-bold antialiased tabular-nums"
              style={{ color: circleColor, transition: 'color 0.8s ease' }}
            >
              {percentage.toFixed(1)}<span className="text-sm text-text-muted">%</span>
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider text-text-muted">Used</span>
          </div>
        </div>

        {/* Stats Rows */}
        <div className="flex flex-col gap-3 max-h-[160px] overflow-y-auto pr-2 scroll-smooth [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:bg-white/10 [&::-webkit-scrollbar-thumb]:rounded-full hover:[&::-webkit-scrollbar-thumb]:bg-white/20" style={{ WebkitOverflowScrolling: 'touch' }}>
          <StatRow 
            label="Total Tokens" 
            value={stats.total.toLocaleString()} 
            icon={Activity} 
            color="bg-gray-400" 
            iconColor="text-text-secondary"
            percent={100} 
          />
          <StatRow 
            label="Last Message Tokens" 
            value={stats.lastMessage.toLocaleString()} 
            icon={MessageSquare} 
            color="bg-gray-500" 
            percent={(stats.lastMessage / 2000) * 100} 
          />
          <StatRow 
            label="Remaining Today" 
            value={remainingToday.toLocaleString()} 
            icon={Hourglass} 
            color="bg-success" 
            percent={(remainingToday / stats.total) * 100} 
          />
          <StatRow 
            label="Today Used" 
            value={stats.today.toLocaleString()} 
            icon={Calendar} 
            color="bg-accent-primary" 
            percent={(stats.today / 10000) * 100} 
          />
          <StatRow 
            label="Weekly Used" 
            value={stats.weekly.toLocaleString()} 
            icon={BarChart2} 
            color="bg-accent-secondary" 
            percent={(stats.weekly / 100000) * 100} 
          />
          <StatRow 
            label="Monthly Used" 
            value={stats.monthly.toLocaleString()} 
            icon={PieChart} 
            color="bg-warning" 
            percent={(stats.monthly / 500000) * 100} 
          />
          
          {showWarning && (
            <div className="flex items-center gap-2 p-2 rounded-lg bg-warning/10 border border-warning/20 text-warning mt-1">
              <AlertTriangle size={12} />
              <span className="text-[10px] font-bold uppercase tracking-wider">⚠️ 80% daily quota used — switch API key soon</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const StatRow = ({ label, value, icon: Icon, color, iconColor, percent }: any) => (
  <div className="group">
    <div className="mb-1 flex items-center justify-between">
      <div className="flex items-center gap-2 text-text-secondary group-hover:text-text-primary transition-colors">
        <Icon size={11} className={iconColor || "text-text-secondary"} />
        <span className="text-[10px] font-medium antialiased">{label}</span>
      </div>
      <span className="text-[10px] font-semibold text-text-primary antialiased tabular-nums">{value}</span>
    </div>
    <div className="h-0.5 w-full overflow-hidden rounded-full bg-bg-card">
      <div 
        className={`h-full rounded-full ${color} transition-all duration-1000 ease-out shadow-[0_0_5px_currentColor] opacity-80 group-hover:opacity-100`} 
        style={{ width: `${Math.min(percent, 100)}%` }} 
      />
    </div>
  </div>
);
