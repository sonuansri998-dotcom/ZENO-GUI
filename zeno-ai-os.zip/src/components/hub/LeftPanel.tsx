import React from 'react';
import { GlassCard } from '@/components/shared/GlassCard';
import { useSystemMetrics } from '@/hooks/useSystemMetrics';
import { Activity, Zap, Ghost, ShieldCheck, Brain, Database, Mic, Server, Cpu, Globe, Layers, FileCode, Terminal, Wifi } from 'lucide-react';
import { motion } from 'motion/react';

const StatRow = ({ label, value, icon: Icon, color, percent }: any) => (
  <div className="group">
    <div className="mb-1 flex items-center justify-between">
      <div className="flex items-center gap-2 text-text-secondary">
        <Icon size={11} />
        <span className="text-[10px] font-medium antialiased">{label}</span>
      </div>
      <span className="text-[10px] font-semibold text-text-primary antialiased tabular-nums">{value}</span>
    </div>
    <div className="h-0.5 w-full overflow-hidden rounded-full bg-bg-card">
      <div 
        className={`h-full rounded-full ${color} transition-all duration-1000 ease-out`} 
        style={{ width: `${Math.min(percent, 100)}%` }} 
      />
    </div>
  </div>
);

const InfoBlock = ({ icon: Icon, label, children }: any) => (
  <div className="rounded-lg border border-glass-border bg-bg-card p-2.5 transition-colors hover:bg-bg-card-hover h-full flex flex-col justify-between">
    <div className="mb-2 flex items-center gap-1.5 text-text-muted">
      <Icon size={11} />
      <span className="text-[9px] font-bold uppercase tracking-wider">{label}</span>
    </div>
    <div className="space-y-1.5 flex-1">
      {children}
    </div>
  </div>
);

const HistoryCard = ({ title, value, status, icon: Icon, barClass, textClass = "text-text-primary" }: { title: string, value: string, status: string, icon: any, barClass: string, textClass?: string }) => (
  <div className="group relative overflow-hidden rounded-xl bg-bg-card border border-glass-border p-2.5 transition-all duration-300 hover:bg-bg-card-hover hover:border-border-color">
    <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
    <div className="relative z-10 flex flex-col gap-1.5">
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-2">
          <div className={`p-1 rounded-md bg-bg-card text-text-secondary group-hover:text-text-primary group-hover:bg-bg-card-hover transition-colors`}>
            <Icon size={10} />
          </div>
          <span className={`text-[9px] font-bold uppercase tracking-wider ${textClass}`}>{title}</span>
        </div>
        <span className="text-[9px] font-mono text-text-muted group-hover:text-accent-primary transition-colors">{value}</span>
      </div>
      <div className="h-1 bg-bg-card rounded-full overflow-hidden w-full relative">
        <motion.div 
          className={`h-full ${barClass} rounded-full relative`}
          initial={{ width: 0 }}
          animate={{ width: value }}
          transition={{ duration: 1.2, ease: "easeOut" }}
        >
          <div className="absolute right-0 top-0 bottom-0 w-1 bg-bg-card0 shadow-[0_0_5px_white]" />
        </motion.div>
      </div>
      <div className="flex justify-between items-center">
        <span className="text-[8px] text-gray-600 font-medium uppercase tracking-wider group-hover:text-text-secondary transition-colors">{status}</span>
        <div className="flex gap-0.5">
           <div className="w-0.5 h-0.5 rounded-full bg-text-muted group-hover:bg-accent-primary transition-colors" />
           <div className="w-0.5 h-0.5 rounded-full bg-text-muted group-hover:bg-accent-primary transition-colors delay-75" />
           <div className="w-0.5 h-0.5 rounded-full bg-text-muted group-hover:bg-accent-primary transition-colors delay-150" />
        </div>
      </div>
    </div>
  </div>
);

export const LeftPanel = () => {
  const { cpu, ram, ping } = useSystemMetrics();
  
  // Stability Calculation
  const stability = 92;
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (stability / 100) * circumference;

  return (
    <div className="flex flex-col h-full gap-3">
      {/* Neural Vitals - Enhanced */}
      <div className="relative overflow-hidden rounded-2xl border border-glass-border bg-bg-card p-5 transition-all duration-300 hover:border-border-color group">
        
        {/* Header */}
        <div className="mb-4 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-success/10 text-success">
              <Activity size={18} />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-text-primary antialiased">Neural Vitals</h2>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-glass-border bg-bg-primary px-2 py-0.5 text-success">
            <div className="h-1.5 w-1.5 rounded-full bg-success shadow-[0_0_8px_currentColor] animate-pulse" />
            <span className="text-[9px] font-medium tracking-wide antialiased">ONLINE</span>
          </div>
        </div>

        {/* Top Section: Stability & Resources */}
        <div className="grid grid-cols-[120px_1fr] gap-4 mb-4">
          {/* Circular Progress */}
          <div className="relative flex h-[120px] w-[120px] items-center justify-center">
            <svg className="h-full w-full -rotate-90 transform">
              <circle cx="60" cy="60" r={radius} stroke="rgba(255,255,255,0.05)" strokeWidth="6" fill="transparent" />
              <circle
                cx="60" cy="60" r={radius}
                stroke="currentColor" strokeWidth="6"
                fill="transparent"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                className="text-success transition-all duration-[1500ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-text-primary antialiased tabular-nums">
                {stability}<span className="text-sm text-text-muted">%</span>
              </span>
              <span className="text-[10px] font-medium uppercase tracking-wider text-text-muted">Stability</span>
            </div>
          </div>

          {/* Stats Rows */}
          <div className="flex flex-col justify-center gap-3 w-full">
            <StatRow 
              label="CPU Core" 
              value={`${Math.round(cpu)}%`} 
              icon={Cpu} 
              color="bg-accent-primary" 
              percent={cpu} 
            />
            <StatRow 
              label="Memory" 
              value={`${ram.toFixed(1)} GB`} 
              icon={Database} 
              color="bg-accent-secondary" 
              percent={(ram / 8) * 100} 
            />
            <StatRow 
              label="Network" 
              value={`${Math.round(ping)} ms`} 
              icon={Wifi} 
              color="bg-success" 
              percent={(ping / 200) * 100} 
            />
          </div>
        </div>

        {/* Bottom Section: Detailed Grids */}
        <div className="grid grid-cols-2 gap-2">
           {/* AI Core */}
           <InfoBlock icon={Brain} label="AI Core">
              <div className="flex justify-between items-center text-[9px]">
                <span className="text-text-secondary font-medium">Model</span>
                <span className="text-text-primary font-bold bg-white/10 px-1.5 py-0.5 rounded text-[8px]">Gemini 1.5</span>
              </div>
              <div className="flex justify-between items-center text-[9px]">
                <span className="text-text-secondary font-medium">Speed</span>
                <span className="text-accent-primary font-mono font-bold">0.8s</span>
              </div>
              <div className="flex justify-between items-center text-[9px]">
                <span className="text-text-secondary font-medium">Mode</span>
                <span className="text-success font-bold">Chat Active</span>
              </div>
           </InfoBlock>

            {/* API Health */}
           <InfoBlock icon={Server} label="API Health">
              <div className="flex justify-between items-center text-[9px]">
                <span className="text-text-secondary font-medium uppercase">Gemini</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-success shadow-[0_0_5px_var(--color-success)]" />
                  <span className="text-success font-bold tracking-wider">OPTIMAL</span>
                </div>
              </div>
              <div className="flex justify-between items-center text-[9px]">
                <span className="text-text-secondary font-medium uppercase">Groq</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-success shadow-[0_0_5px_var(--color-success)]" />
                  <span className="text-success font-bold tracking-wider">OPTIMAL</span>
                </div>
              </div>
              <div className="flex justify-between items-center text-[9px]">
                <span className="text-text-secondary font-medium uppercase">OpenRouter</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-warning shadow-[0_0_5px_var(--color-warning)]" />
                  <span className="text-warning font-bold tracking-wider">SLOW</span>
                </div>
              </div>
           </InfoBlock>

           {/* Voice Engine */}
           <InfoBlock icon={Mic} label="Voice Engine">
              <div className="flex flex-col justify-end h-full gap-2">
                 <div className="flex items-end justify-between">
                    <div className="flex items-end gap-1 h-5">
                      <div className="w-1 bg-accent-primary rounded-full animate-[music-bar_1s_ease-in-out_infinite]" style={{ height: '40%' }} />
                      <div className="w-1 bg-accent-primary rounded-full animate-[music-bar_1.2s_ease-in-out_infinite_0.1s]" style={{ height: '80%' }} />
                      <div className="w-1 bg-accent-primary rounded-full animate-[music-bar_0.8s_ease-in-out_infinite_0.2s]" style={{ height: '60%' }} />
                      <div className="w-1 bg-accent-primary rounded-full animate-[music-bar_1.1s_ease-in-out_infinite_0.3s]" style={{ height: '90%' }} />
                    </div>
                    <span className="text-[9px] text-accent-primary font-bold uppercase tracking-wider">Listening</span>
                 </div>
              </div>
           </InfoBlock>

           {/* Memory */}
           <InfoBlock icon={Database} label="Memory">
              <div className="flex flex-col justify-end h-full gap-1">
                <motion.div 
                  key="memory-count"
                  initial={{ y: 10, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className="text-xl font-bold text-text-primary tabular-nums tracking-tight"
                >
                  8,432
                </motion.div>
                <div className="flex justify-between items-center">
                  <span className="text-[9px] text-text-muted font-medium">Total Stored</span>
                  <span className="text-[9px] text-success font-medium">+12 Today</span>
                </div>
              </div>
           </InfoBlock>
        </div>
      </div>

      {/* Action Logs - Compact & Clean */}
      <div className="flex-1 min-h-0 overflow-hidden flex flex-col relative rounded-2xl border border-glass-border bg-bg-card p-5 transition-all duration-300 hover:border-border-color group">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-50" />
        
        <h2 className="text-xs font-bold text-text-muted mb-4 tracking-widest uppercase shrink-0 flex items-center gap-2 relative z-10">
          <Cpu size={14} /> Action History
        </h2>
        <div className="flex-1 overflow-y-auto pb-2 scrollbar-hide smooth-scroll relative z-10">
          <div className="grid grid-cols-2 gap-2 pb-2">
            <HistoryCard title="System Init" value="100%" status="Completed" icon={Terminal} barClass="bg-accent-primary" textClass="text-accent-primary" />
            <HistoryCard title="Neural Link" value="100%" status="Stable" icon={Zap} barClass="bg-accent-primary" textClass="text-accent-primary" />
            <HistoryCard title="Security" value="98%" status="Scanning" icon={ShieldCheck} barClass="bg-success" textClass="text-success" />
            <HistoryCard title="Memory Opt" value="45%" status="Optimizing" icon={Layers} barClass="bg-accent-secondary" textClass="text-accent-secondary" />
            <HistoryCard title="Data Index" value="67%" status="Indexing" icon={FileCode} barClass="bg-accent-secondary" textClass="text-accent-secondary" />
            <HistoryCard title="Net Scan" value="32%" status="Active" icon={Globe} barClass="bg-warning" textClass="text-warning" />
          </div>
        </div>
        
        {/* Bottom Fade */}
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-[#03060F] to-transparent pointer-events-none rounded-b-xl" />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-3 gap-2 h-14 shrink-0">
        <div className="rounded-2xl border border-glass-border bg-bg-card transition-all duration-300 hover:border-border-color group flex flex-col items-center justify-center gap-1 cursor-pointer p-1">
          <Zap size={14} className="text-warning group-hover:text-warning/80 transition-colors" />
          <span className="text-[8px] font-bold font-mono text-center text-text-muted group-hover:text-text-primary transition-colors">BOOST</span>
        </div>
        <div className="rounded-2xl border border-glass-border bg-bg-card transition-all duration-300 hover:border-border-color group flex flex-col items-center justify-center gap-1 cursor-pointer p-1">
          <Ghost size={14} className="text-accent-secondary group-hover:text-accent-secondary/80 transition-colors" />
          <span className="text-[8px] font-bold font-mono text-center text-text-muted group-hover:text-text-primary transition-colors">GHOST</span>
        </div>
        <div className="rounded-2xl border border-glass-border bg-bg-card transition-all duration-300 hover:border-border-color group flex flex-col items-center justify-center gap-1 cursor-pointer p-1">
          <ShieldCheck size={14} className="text-success group-hover:text-success/80 transition-colors" />
          <span className="text-[8px] font-bold font-mono text-center text-text-muted group-hover:text-text-primary transition-colors">SECURE</span>
        </div>
      </div>
    </div>
  );
};
