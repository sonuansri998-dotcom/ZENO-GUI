import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Send, Volume2, VolumeX } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ZenoLogo } from '@/components/shared/ZenoLogo';

interface Message {
  id: string;
  role: 'user' | 'ai';
  content: string;
  timestamp: string;
}

const SiriWave = () => {
  const [heights] = React.useState(() => [...Array(12)].map(() => Math.random() * 24 + 8));
  
  return (
    <div className="flex items-center justify-center gap-0.5 h-12 w-full max-w-[200px]">
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="w-1 bg-accent-primary/80 rounded-full shadow-[0_0_10px_var(--glow-primary)]"
          animate={{
            height: [4, heights[i], 4],
            opacity: [0.3, 1, 0.3],
          }}
          transition={{
            duration: 0.5,
            repeat: Infinity,
            delay: i * 0.05,
            ease: "easeInOut",
            repeatType: "reverse"
          }}
        />
      ))}
    </div>
  );
};

export const CenterPanel: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'ai', content: "System initialized. How can I assist you today?", timestamp: '00:00:01' }
  ]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSoundOn, setIsSoundOn] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  };

  useEffect(() => {
    // Small delay to ensure DOM is updated before scrolling
    const timeoutId = setTimeout(scrollToBottom, 50);
    return () => clearTimeout(timeoutId);
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date().toLocaleTimeString()
    };
    
    setMessages(prev => [...prev, newMessage]);
    setInput('');
    
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'ai',
        content: "Processing request...",
        timestamp: new Date().toLocaleTimeString()
      }]);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full relative">
      {/* Central Radar / Visualization */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
        <div className="relative w-[500px] h-[500px] will-change-transform">
          <div className="absolute inset-0 border border-accent-primary/20 rounded-full animate-[spin_10s_linear_infinite] will-change-transform" />
          <div className="absolute inset-12 border border-accent-secondary/20 rounded-full animate-[spin_15s_linear_infinite_reverse] will-change-transform" />
          <div className="absolute inset-24 border border-accent-primary/20 rounded-full" />
          <div className="absolute inset-0 flex items-center justify-center">
             <ZenoLogo size="xl" className="opacity-20" showText={false} />
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide smooth-scroll z-10 relative">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} will-change-transform`}
            >
              <div className={`max-w-[65%] px-5 py-3 rounded-2xl shadow-sm border transition-all duration-300 ${
                msg.role === 'user' 
                  ? 'bg-accent-primary/20 border-accent-primary/30 text-text-primary rounded-br-none' 
                  : 'bg-bg-card border-border-color text-text-primary rounded-bl-none'
              }`}>
                <p className="text-xs font-medium leading-relaxed tracking-wide">{msg.content}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {/* Siri Wave Animation */}
        <AnimatePresence>
          {isListening && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-4 left-0 right-0 flex justify-center pointer-events-none"
            >
              <div className="bg-bg-card px-6 py-2 rounded-full border border-border-color shadow-2xl">
                <SiriWave />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        <div ref={messagesEndRef} />
      </div>

      {/* Floating Input Bar */}
      <div className="p-4 z-20 w-full flex justify-center">
        <div className="relative w-full max-w-xl group">
           <div className="relative w-full bg-bg-card rounded-full p-1.5 pl-6 flex items-center gap-4 border border-border-color shadow-lg transition-colors duration-300">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type a command or ask a question..."
              className="flex-1 bg-transparent border-none outline-none text-text-primary placeholder-text-muted font-medium text-xs tracking-wide selection:bg-accent-primary/30 focus:outline-none focus:ring-0 focus:border-none focus-visible:outline-none focus-visible:ring-0 focus-visible:border-none shadow-none !outline-none !ring-0 !border-none"
            />
            
            <div className="flex items-center gap-2 pr-1">
              <button 
                onClick={() => setIsListening(!isListening)}
                className={`p-2 rounded-full transition-all duration-300 ${isListening ? 'text-error bg-error/10 shadow-[0_0_10px_rgba(248,113,113,0.3)]' : 'text-text-primary hover:text-text-primary hover:bg-bg-card-hover'}`}
              >
                {isListening ? <Mic size={16} className="animate-pulse" /> : <MicOff size={16} />}
              </button>
              <button 
                onClick={() => setIsSoundOn(!isSoundOn)}
                className={`p-2 rounded-full transition-colors hover:bg-bg-card-hover ${isSoundOn ? 'text-text-primary' : 'text-text-secondary'}`}
              >
                {isSoundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}
              </button>
              
              {/* Premium Send Button */}
              <button 
                onClick={handleSend}
                className="group/btn relative flex items-center justify-center w-9 h-9 rounded-full bg-white text-black overflow-hidden transition-all duration-300 hover:scale-105 hover:shadow-[0_0_15px_rgba(255,255,255,0.5)]"
              >
                <div className="absolute inset-0 bg-gradient-to-tr from-gray-200 to-white opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300" />
                <Send size={14} className="relative z-10 transition-transform duration-300 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" fill="currentColor" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
