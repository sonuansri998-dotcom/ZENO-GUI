import React, { useState, useRef } from 'react';
import { Camera, Search, MapPin, Power, Share2, Maximize2, Code } from 'lucide-react';
import { motion } from 'motion/react';
import { ContextWindow } from './ContextWindow';

export const RightPanel = () => {
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const toggleCamera = async () => {
    setCameraError(null);
    if (cameraActive) {
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
      if (videoRef.current) videoRef.current.srcObject = null;
      setCameraActive(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setCameraActive(true);
        }
      } catch (err: any) {
        console.error("Camera access denied:", err);
        setCameraError(err.message || "Permission denied");
      }
    }
  };

  return (
    <div className="flex flex-col h-full gap-4">
      {/* Top: Context Window */}
      <ContextWindow />

      {/* Middle: Action Box - Enhanced List Style */}
      <div className="flex-1 min-h-0 bg-bg-card rounded-2xl border border-glass-border p-5 flex flex-col relative overflow-hidden group hover:border-border-color transition-colors duration-300">
        {/* Beveled Top Edge */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-50" />
        
        <div className="flex justify-between items-center mb-4 relative z-10 shrink-0">
          <h3 className="text-xs font-bold text-text-muted tracking-widest uppercase flex items-center gap-2">
            <Share2 size={12} /> Action Box
          </h3>
          <button className="text-text-muted hover:text-text-primary transition-colors p-1 hover:bg-bg-card-hover rounded-lg">
            <Maximize2 size={12} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 scrollbar-hide smooth-scroll relative z-10">
          {/* Enhanced Search Result */}
          <motion.div 
            layout
            className="p-3.5 rounded-xl bg-bg-primary border border-glass-border hover:border-border-color hover:bg-bg-card-hover transition-all duration-300 group/item cursor-pointer relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-bg-card translate-x-[-100%] group-hover/item:translate-x-0 transition-transform duration-700 ease-out" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-1.5">
                <Search size={12} className="text-text-secondary" />
                <span className="text-[9px] font-bold uppercase tracking-wider text-text-primary group-hover/item:text-text-primary transition-colors">Deep Space Exploration</span>
              </div>
              <p className="text-[9px] font-mono text-text-muted line-clamp-2 group-hover/item:text-text-secondary transition-colors leading-relaxed">
                Recent data from James Webb Telescope suggests new exoplanet formations in the Orion Nebula...
              </p>
            </div>
          </motion.div>

          {/* Enhanced Map Result */}
          <motion.div 
            layout
            className="p-3.5 rounded-xl bg-bg-primary border border-glass-border hover:border-accent-secondary/30 hover:bg-bg-card-hover transition-all duration-300 group/item cursor-pointer relative overflow-hidden"
          >
             <div className="absolute inset-0 bg-accent-secondary/5 translate-x-[-100%] group-hover/item:translate-x-0 transition-transform duration-700 ease-out" />
             <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2.5">
                <MapPin size={12} className="text-accent-secondary/80" />
                <span className="text-[9px] font-bold uppercase tracking-wider text-text-primary group-hover/item:text-text-primary transition-colors">Sector 7G Coordinates</span>
              </div>
              <div className="h-24 bg-black rounded-lg overflow-hidden relative border border-glass-border group-hover/item:border-border-color transition-colors">
                <div className="absolute inset-0 opacity-40 bg-[url('https://api.mapbox.com/styles/v1/mapbox/dark-v10/static/0,0,2,0,0/300x200?access_token=pk.eyJ1IjoiZXhhbXBsZSIsImEiOiJja2xlbm53b3gwMG5wMnBzNHZ5djZ2a25pIn0.7b5S3Y2Z3Z3Z3Z3Z3Z3Z3Q')] bg-cover bg-center grayscale group-hover/item:grayscale-0 transition-all duration-700" />
              </div>
            </div>
          </motion.div>

          {/* Enhanced Code Preview */}
          <motion.div 
            layout
            className="p-3.5 rounded-xl bg-bg-primary border border-glass-border hover:border-success/30 hover:bg-bg-card-hover transition-all duration-300 group/item cursor-pointer relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-success/5 translate-x-[-100%] group-hover/item:translate-x-0 transition-transform duration-700 ease-out" />
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-1.5">
                <Code size={12} className="text-success/80" />
                <span className="text-[9px] font-bold uppercase tracking-wider text-text-primary group-hover/item:text-text-primary transition-colors">Quantum Algorithm.py</span>
              </div>
              <pre className="text-[9px] font-mono text-text-muted bg-black/30 p-2.5 rounded-lg overflow-x-auto border border-glass-border group-hover/item:border-border-color transition-colors group-hover/item:text-text-secondary">
                def entangle_qubits(q1, q2):{'\n'}
                &nbsp;&nbsp;h(q1){'\n'}
                &nbsp;&nbsp;cx(q1, q2){'\n'}
                &nbsp;&nbsp;return measure(q1, q2)
              </pre>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom: Vision Portal (AI Vision style) */}
      <div className="bg-bg-card rounded-2xl border border-glass-border p-5 relative overflow-hidden group hover:border-border-color transition-colors duration-300">
        {/* Beveled Top Edge */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-50" />

        <div className="flex justify-between items-center mb-4 relative z-10">
          <div className="flex items-center gap-2">
            <Camera size={14} className="text-text-secondary" />
            <h3 className="text-xs font-bold text-text-primary uppercase tracking-wider flex items-center gap-2">
              AI Vision <span className="text-[9px] text-gray-600 font-mono">v2.4</span>
            </h3>
          </div>
          <button 
            onClick={toggleCamera}
            className={`p-1.5 rounded-lg transition-all duration-300 ${cameraActive ? 'text-error bg-error/10 shadow-[0_0_10px_rgba(248,113,113,0.2)]' : 'text-text-muted hover:text-text-primary hover:bg-bg-card-hover'}`}
          >
            <Power size={14} />
          </button>
        </div>
        
        <div className="aspect-video bg-bg-primary rounded-xl overflow-hidden relative border border-border-color shadow-inner group/vision">
          {!cameraActive && !cameraError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-text-muted z-20">
              <div className="relative">
                <div className="absolute inset-0 bg-accent-primary/20 blur-xl rounded-full animate-pulse" />
                <Camera size={24} className="mb-2 opacity-50 relative z-10" />
              </div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-accent-primary/40">System Offline</span>
            </div>
          )}

          {cameraError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-error/80 z-20 bg-black/50 backdrop-blur-sm p-4 text-center">
              <div className="relative mb-2">
                <div className="absolute inset-0 bg-error/20 blur-xl rounded-full animate-pulse" />
                <Camera size={24} className="opacity-80 relative z-10" />
              </div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-error mb-1">Camera access denied</span>
              <span className="text-[9px] text-error/60 max-w-[80%]">{cameraError}</span>
            </div>
          )}
          
          {/* Video Feed */}
          <video 
            ref={videoRef} 
            autoPlay 
            muted 
            style={{ transform: 'scaleX(-1)' }}
            className={`w-full h-full object-cover transition-opacity duration-700 ${cameraActive ? 'opacity-100' : 'opacity-0'}`} 
          />
        </div>
      </div>
    </div>
  );
};
