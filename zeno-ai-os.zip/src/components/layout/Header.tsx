/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Bell, Star, BrainCircuit, Settings, Box } from 'lucide-react';
import { ZenoLogo } from '@/components/shared/ZenoLogo';
import RunInBackground from '../RunInBackground';
import { HeaderClock as Clock } from './HeaderClock';

interface HeaderProps {
  onViewChange: (view: 'hub' | 'dashboard', tab?: string) => void;
  currentView: 'hub' | 'dashboard';
}

interface HeaderDockIconProps {
  id: string;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  isHovered: boolean;
  isNeighborLeft: boolean;
  isNeighborRight: boolean;
  onHover: () => void;
  onLeave: () => void;
}

const HeaderDockIcon: React.FC<HeaderDockIconProps> = ({ 
  id,
  icon, 
  label,
  onClick,
  isHovered,
  isNeighborLeft,
  isNeighborRight,
  onHover,
  onLeave
}) => {
  const xValue = isNeighborLeft ? -5 : isNeighborRight ? 5 : 0;
  const scaleValue = isHovered ? 1.2 : isNeighborLeft || isNeighborRight ? 1.1 : 1;

  return (
    <motion.div
      className="relative flex flex-col items-center justify-center cursor-pointer group w-10 h-10 will-change-transform"
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      onClick={onClick}
      animate={{ 
        scale: scaleValue,
        x: xValue
      }}
      transition={{ 
        type: "spring",
        stiffness: 400,
        damping: 30
      }}
    >
       <div className={`w-full h-full rounded-full flex items-center justify-center transition-all duration-300 will-change-[background-color,box-shadow] ${isHovered ? 'bg-white/10 text-white shadow-[0_0_15px_rgba(255,255,255,0.2)]' : 'text-gray-400 hover:text-white'}`}>
         {icon}
       </div>

       <motion.span
         className="absolute -bottom-2 text-[9px] font-medium text-gray-400 whitespace-nowrap pointer-events-none will-change-opacity"
         initial={false}
         animate={{ 
           opacity: isHovered ? 1 : 0,
           y: isHovered ? 0 : -2
         }}
         transition={{ duration: 0.2 }}
       >
         {label}
       </motion.span>
    </motion.div>
  );
};

export const Header: React.FC<HeaderProps> = ({ onViewChange, currentView }) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [hoveredRightIndex, setHoveredRightIndex] = useState<number | null>(null);
  const [isAutomationOn, setIsAutomationOn] = useState(true);

  const dockItems = [
    { id: 'automation', label: 'Automation', icon: (
      <div className="relative">
        <Box 
          size={20} 
          strokeWidth={1.5}
          className={`transition-all duration-500 ${isAutomationOn ? "text-accent-primary scale-110" : "text-gray-600 opacity-50"}`} 
        />
        <div className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border-2 border-[#050505] transition-all duration-500 ${
          isAutomationOn 
            ? "bg-accent-primary shadow-[0_0_10px_var(--glow-primary)] animate-pulse" 
            : "bg-gray-700"
        }`} />
        {isAutomationOn && (
          <div className="absolute inset-0 bg-accent-primary/20 blur-md rounded-full animate-pulse -z-10" />
        )}
      </div>
    )},
    { id: 'run', label: 'Run in Background', icon: <div className="scale-[0.6] origin-center"><RunInBackground /></div> },
    { id: 'notif', label: 'Notifications', icon: (
      <div className="relative">
        <Bell size={20} strokeWidth={1.5} />
        <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-red-500 rounded-full border border-[#050505]" />
      </div>
    )}
  ];

  return (
    <div className="w-full h-24 relative z-50 shrink-0">
      {/* Deep Glass Background with Dynamic Gradient */}
      <div className="absolute inset-0 bg-[#050505]/90 backdrop-blur-xl border-b border-white/5 shadow-2xl z-0" />
      
      {/* Animated Nebula Effect */}
      <div className="absolute inset-0 opacity-20 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-50%] left-[-20%] w-[80%] h-[200%] bg-cyan-900/20 blur-[120px] animate-[pulse_8s_ease-in-out_infinite]" />
        <div className="absolute bottom-[-50%] right-[-20%] w-[80%] h-[200%] bg-purple-900/20 blur-[120px] animate-[pulse_10s_ease-in-out_infinite_reverse]" />
      </div>
      
      <div className="relative h-full flex items-center justify-between px-8 z-10">
        {/* Left: Branding */}
        <div className="flex items-center gap-6">
          {/* Static Sliced Logo with Enhanced Finish */}
          <div className="relative cursor-pointer">
             <div className="absolute inset-0 bg-white/5 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
             <ZenoLogo size="lg" className="drop-shadow-[0_0_10px_rgba(255,255,255,0.1)]" />
          </div>
        </div>

        {/* Center: Live Clock */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 hidden md:block">
           <Clock />
        </div>

        {/* Right: Controls & Profile */}
        <div className="flex items-center gap-6">
          {/* Dashboard Button */}
          <button 
            onClick={() => onViewChange('dashboard', 'overview')}
            className="relative flex items-center gap-2.5 px-5 py-2.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 hover:border-cyan-500/30 transition-all duration-300 group overflow-hidden shadow-sm hover:scale-105"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/0 via-cyan-500/10 to-cyan-500/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 ease-in-out" />
            <BrainCircuit size={16} className="text-gray-400 group-hover:text-cyan-400 transition-colors duration-300 relative z-10" />
            <span className="text-xs font-bold uppercase tracking-widest text-gray-400 group-hover:text-white transition-colors duration-300 relative z-10">Dashboard</span>
          </button>

          <div className="h-8 w-[1px] bg-white/10" />

          <div className="flex items-center gap-4">
            {dockItems.map((item, index) => (
              <HeaderDockIcon 
                key={item.id}
                id={item.id}
                icon={item.icon}
                label={item.label}
                onClick={() => {
                  if (item.id === 'automation') {
                    setIsAutomationOn(!isAutomationOn);
                    // Add a small haptic-like feedback or sound if needed, 
                    // but here we just toggle state visually.
                  }
                }}
                isHovered={hoveredIndex === index}
                isNeighborLeft={hoveredIndex === index + 1}
                isNeighborRight={hoveredIndex === index - 1}
                onHover={() => setHoveredIndex(index)}
                onLeave={() => setHoveredIndex(null)}
              />
            ))}
          </div>

          <div className="h-8 w-[1px] bg-white/10" />

          <div className="flex items-center gap-4">
            <div className="hidden lg:flex flex-col items-end justify-center">
              <span className="text-[12px] font-bold text-text-primary tracking-wide">Arnold A.</span>
            </div>
            
            <div className="flex items-center gap-4">
              <HeaderDockIcon 
                id="profile"
                icon={
                  <div className="w-full h-full rounded-full overflow-hidden border border-border-color relative">
                    <img src="https://picsum.photos/seed/zeno_user/200/200" alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-success border-2 border-bg-primary rounded-full"></div>
                  </div>
                }
                label="Profile"
                onClick={() => onViewChange('dashboard', 'profile')}
                isHovered={hoveredRightIndex === 0}
                isNeighborLeft={hoveredRightIndex === 1}
                isNeighborRight={false}
                onHover={() => setHoveredRightIndex(0)}
                onLeave={() => setHoveredRightIndex(null)}
              />
              <HeaderDockIcon 
                id="settings"
                icon={<Settings size={20} strokeWidth={1.5} />}
                label="Settings"
                onClick={() => onViewChange('dashboard', 'settings')}
                isHovered={hoveredRightIndex === 1}
                isNeighborLeft={false}
                isNeighborRight={hoveredRightIndex === 0}
                onHover={() => setHoveredRightIndex(1)}
                onLeave={() => setHoveredRightIndex(null)}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
