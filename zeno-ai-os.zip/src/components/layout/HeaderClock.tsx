import React, { useState, useEffect } from 'react';
import { MapPin, Cloud, Sun, CloudRain } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Global cache to prevent reloading when navigating
let cachedLocation = 'Locating...';
let cachedWeather: { temp: number; code: number } | null = null;
let isFetching = false;

export const HeaderClock = () => {
  const [time, setTime] = useState(new Date());
  const [location, setLocation] = useState<string>(cachedLocation);
  const [weather, setWeather] = useState<{ temp: number; code: number } | null>(cachedWeather);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let watchId: number;

    const fetchWeatherAndLocation = async (lat: number, lon: number) => {
      if (isFetching) return;
      isFetching = true;
      try {
        const locRes = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`);
        const locData = await locRes.json();
        const city = locData.address.city || locData.address.town || locData.address.village || locData.address.county || 'Unknown';
        cachedLocation = city;
        setLocation(city);

        const weatherRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
        const weatherData = await weatherRes.json();
        cachedWeather = {
          temp: Math.round(weatherData.current_weather.temperature),
          code: weatherData.current_weather.weathercode,
        };
        setWeather(cachedWeather);
      } catch (error) {
        console.error("Error fetching location/weather:", error);
        if (cachedLocation === 'Locating...') {
          cachedLocation = 'Offline';
          setLocation('Offline');
        }
      } finally {
        isFetching = false;
      }
    };

    if ('geolocation' in navigator && cachedLocation === 'Locating...') {
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          fetchWeatherAndLocation(position.coords.latitude, position.coords.longitude);
        },
        (error) => {
          console.error("Geolocation error:", error);
          cachedLocation = 'Location Disabled';
          setLocation(cachedLocation);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
      );
    }

    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, []);

  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  const dayName = days[time.getDay()];
  const monthName = months[time.getMonth()];
  const date = time.getDate();
  
  let hours = time.getHours();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  
  const hoursStr = hours.toString().padStart(2, '0');
  const minutes = time.getMinutes().toString().padStart(2, '0');
  const seconds = time.getSeconds().toString().padStart(2, '0');

  const getOrdinal = (n: number) => {
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    return s[(v - 20) % 10] || s[v] || s[0];
  };

  const getWeatherIcon = (code: number) => {
    if (code <= 3) return <Sun size={14} className="text-amber-400 drop-shadow-[0_0_4px_rgba(251,191,36,0.5)]" />;
    if (code <= 67) return <CloudRain size={14} className="text-blue-400 drop-shadow-[0_0_4px_rgba(96,165,250,0.5)]" />;
    return <Cloud size={14} className="text-gray-400 drop-shadow-[0_0_4px_rgba(156,163,175,0.5)]" />;
  };

  // Smooth animation variants for text changes
  const fadeVariants = {
    initial: { opacity: 0, y: -5 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: 5 },
  };

  return (
    <div className="flex items-center gap-4 text-text-primary font-mono text-sm tracking-wide select-none bg-black/40 backdrop-blur-2xl px-5 py-2.5 rounded-2xl border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.4)] relative overflow-hidden group hover:border-white/20 transition-colors duration-500">
      {/* Subtle Shine Effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.04] to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 pointer-events-none" />
      
      {/* Date Section */}
      <div className="flex items-center gap-2 relative z-10 pr-4 border-r border-white/10">
        <span className="text-accent-primary/90 font-bold uppercase tracking-wider text-[10px]">{dayName}</span>
        <div className="h-3 w-[1px] bg-white/20" />
        <span className="text-text-primary font-bold flex items-baseline text-[12px] tracking-wide">
          {date}
          <sup className="text-[8px] text-text-muted ml-0.5 font-medium -top-1">{getOrdinal(date)}</sup>
        </span>
        <span className="text-text-secondary font-medium text-[10px] uppercase tracking-widest">{monthName}</span>
      </div>
      
      {/* Time Section */}
      <div className="flex items-center gap-2 relative z-10 pr-4 border-r border-white/10">
         {/* Glow effect behind time */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-accent-primary/10 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        <span className="relative z-10 tabular-nums text-text-primary font-bold tracking-[0.15em] text-lg flex items-center drop-shadow-sm">
          {hoursStr}
          <span className="animate-pulse text-accent-primary mx-1 text-sm drop-shadow-[0_0_5px_var(--glow-primary)]">:</span>
          {minutes}
          <div className="relative w-[18px] h-[20px] ml-2 overflow-hidden flex items-center justify-center">
            <AnimatePresence mode="popLayout">
              <motion.span 
                key={seconds}
                variants={fadeVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                transition={{ duration: 0.2 }}
                className="absolute text-text-muted text-[10px] font-medium tabular-nums tracking-normal"
              >
                {seconds}
              </motion.span>
            </AnimatePresence>
          </div>
          <span className="ml-1 text-[9px] text-accent-primary/80 font-bold uppercase tracking-widest">{ampm}</span>
        </span>
      </div>

      {/* Location & Weather Section */}
      <div className="flex items-center gap-3 relative z-10 pl-1">
        <div className="flex items-center gap-1.5 text-text-secondary">
          <MapPin size={12} className="text-accent-primary/70" />
          <div className="relative overflow-hidden h-[16px] flex items-center">
            <AnimatePresence mode="popLayout">
              <motion.span 
                key={location}
                variants={fadeVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                transition={{ duration: 0.3 }}
                className="text-[10px] font-bold tracking-wider uppercase truncate max-w-[90px]"
              >
                {location}
              </motion.span>
            </AnimatePresence>
          </div>
        </div>
        {weather && (
          <div className="flex items-center gap-1.5 ml-1 bg-white/5 px-2 py-1 rounded-md border border-white/5">
            {getWeatherIcon(weather.code)}
            <div className="relative overflow-hidden h-[16px] flex items-center">
              <AnimatePresence mode="popLayout">
                <motion.span 
                  key={weather.temp}
                  variants={fadeVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  transition={{ duration: 0.3 }}
                  className="text-[11px] font-bold text-text-primary"
                >
                  {weather.temp}°C
                </motion.span>
              </AnimatePresence>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

