import React, { useState } from 'react';
import './RunInBackground.css';

interface RunInBackgroundProps {
  onToggle?: (isActive: boolean) => void;
  initialState?: boolean;
}

const RunInBackground: React.FC<RunInBackgroundProps> = ({ onToggle, initialState = false }) => {
  const [isActive, setIsActive] = useState(initialState);
  const [isPressed, setIsPressed] = useState(false);
  const [triggerRipple, setTriggerRipple] = useState(false);
  const [showFlash, setShowFlash] = useState(false);

  const handleClick = () => {
    // Toggle logic
    const newState = !isActive;
    setIsActive(newState);
    if (onToggle) {
      onToggle(newState);
    }

    // Animation Sequence
    setIsPressed(true);
    
    setTimeout(() => {
      setIsPressed(false);
      setTriggerRipple(true);
      setShowFlash(true);
      
      // Reset Ripple
      setTimeout(() => setTriggerRipple(false), 600);
      
      // Reset Flash (allow CSS transition to fade it out)
      setTimeout(() => setShowFlash(false), 50);

    }, 80);
  };

  return (
    <div className="run-in-background-container">
      <button
        onClick={handleClick}
        className={`
          run-in-background-btn
          ${isActive ? 'active' : ''}
        `}
        style={{
          transform: isPressed ? 'scale(0.88)' : (triggerRipple ? 'scale(1.08)' : 'scale(1)')
        }}
      >
        {/* Inner Glow Layer */}
        <div className={`inner-glow-layer ${showFlash ? 'inner-glow-flash' : ''}`} />
        
        {/* Ripple Effect */}
        {triggerRipple && <div className="ripple-effect ripple-animate" />}
        
        {/* Orbit Dots */}
        <div className="orbit-dot dot-1" />
        <div className="orbit-dot dot-2" />
        <div className="orbit-dot dot-3" />

        <span className="font-bold text-base select-none relative z-10">R</span>
      </button>
    </div>
  );
};

export default RunInBackground;
