import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  LayoutDashboard, 
  CheckCircle, 
  Brain, 
  FolderOpen, 
  Settings, 
  Search, 
  Bell, 
  Zap,
  Box,
  ArrowLeft,
  Grid
} from 'lucide-react';

interface DockIconProps {
  item: any;
  isActive: boolean;
  onClick: () => void;
  isHovered: boolean;
  isNeighborLeft: boolean;
  isNeighborRight: boolean;
  onHover: () => void;
  onLeave: () => void;
}

const DockIcon: React.FC<DockIconProps> = ({ 
  item, 
  isActive, 
  onClick,
  isHovered,
  isNeighborLeft,
  isNeighborRight,
  onHover,
  onLeave
}) => {
  
  const xValue = isNeighborLeft ? -5 : isNeighborRight ? 5 : 0;
  const scaleValue = isHovered ? 1.2 : isNeighborLeft || isNeighborRight ? 1.1 : 1;

  return (
    <motion.div
      className="relative flex flex-col items-center justify-center cursor-pointer group w-10 h-10 will-change-transform"
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      onClick={onClick}
      animate={{ 
        scale: scaleValue,
        x: xValue
      }}
      transition={{ 
        type: "spring",
        stiffness: 400,
        damping: 30
      }}
    >
       <div className={`w-full h-full rounded-full flex items-center justify-center transition-all duration-300 will-change-[background-color,box-shadow] ${isActive ? 'bg-bg-card-hover text-text-primary shadow-[0_0_15px_rgba(255,255,255,0.15)]' : 'text-text-muted hover:text-text-primary'}`}>
        {item.id === 'profile' ? (
           <div className="w-full h-full rounded-full overflow-hidden border border-border-color relative">
             <img src="https://picsum.photos/seed/zeno_user/200/200" alt="User" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
             <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-success border-2 border-bg-primary rounded-full"></div>
           </div>
        ) : (
           <item.icon size={20} strokeWidth={1.5} />
        )}
       </div>

       <motion.span
         className="absolute -bottom-2 text-[9px] font-medium text-text-secondary whitespace-nowrap pointer-events-none will-change-opacity"
         initial={false}
         animate={{ 
           opacity: isHovered ? 1 : 0,
           y: isHovered ? 0 : -2
         }}
         transition={{ duration: 0.2 }}
       >
         {item.label}
       </motion.span>
    </motion.div>
  );
};

export const Navbar = ({ onBack, activeTab, setActiveTab }: { onBack: () => void, activeTab: string, setActiveTab: (tab: string) => void }) => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [hoveredRightIndex, setHoveredRightIndex] = useState<number | null>(null);

  const navIcons = [
    { id: 'overview', icon: LayoutDashboard, label: 'Overview' },
    { id: 'tasks', icon: CheckCircle, label: 'Tasks' },
    { id: 'memory', icon: Brain, label: 'Memory' },
    { id: 'files', icon: FolderOpen, label: 'Files' },
    { id: 'apps', icon: Grid, label: 'Apps' },
    { id: 'notifs', icon: Bell, label: 'Notifs' },
    { id: 'automation', icon: Box, label: 'Automation' },
  ];

  return (
    <div className="h-24 px-8 flex items-center justify-between bg-glass-bg backdrop-blur-lg sticky top-0 z-50 relative">
      {/* Left Side */}
      <div className="flex items-center gap-6 z-20 w-[300px]">
        <div className="cursor-pointer group relative" onClick={onBack} title="Back to Hub">
          <motion.div 
            whileHover={{ x: -4 }}
            whileTap={{ scale: 0.9 }}
            className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-white/5 transition-colors duration-300"
          >
             <ArrowLeft size={24} strokeWidth={2} className="text-white transition-colors duration-300" />
          </motion.div>
        </div>

        <motion.div 
          initial={false}
          animate={{ width: isSearchOpen ? 320 : 240 }}
          transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
          className={`h-10 rounded-full bg-bg-card border border-border-color flex items-center px-4 gap-3 transition-all duration-300 ease-out backdrop-blur-md will-change-[width] ${isSearchOpen ? 'border-white/30 bg-white/5' : 'hover:border-white/20'}`}
          onClick={() => setIsSearchOpen(true)}
          onBlur={() => setIsSearchOpen(false)}
        >
          <Search size={16} className="text-text-muted" />
          <input 
            type="text" 
            placeholder="Search..." 
            className="bg-transparent border-none outline-none text-sm text-text-primary w-full placeholder:text-text-muted"
            onBlur={() => setIsSearchOpen(false)}
          />
        </motion.div>
      </div>

      {/* Center Dock */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center gap-4 h-20 z-10">
        {navIcons.map((item, index) => (
          <DockIcon 
            key={item.id} 
            item={item} 
            isActive={activeTab === item.id} 
            onClick={() => setActiveTab(item.id)}
            isHovered={hoveredIndex === index}
            isNeighborLeft={hoveredIndex === index + 1}
            isNeighborRight={hoveredIndex === index - 1}
            onHover={() => setHoveredIndex(index)}
            onLeave={() => setHoveredIndex(null)}
          />
        ))}
      </div>

      {/* Right Side */}
      <div className="flex items-center justify-end gap-6 z-20 w-[300px]">
        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end justify-center h-full">
            <span className="text-[12px] font-bold text-text-primary tracking-wide">Arnold A.</span>
          </div>
          
          <div className="flex items-center gap-4 h-20">
            <DockIcon 
              item={{ id: 'profile', label: 'Profile' }} 
              isActive={activeTab === 'profile'} 
              onClick={() => setActiveTab('profile')} 
              isHovered={hoveredRightIndex === 0}
              isNeighborLeft={hoveredRightIndex === 1}
              isNeighborRight={false}
              onHover={() => setHoveredRightIndex(0)}
              onLeave={() => setHoveredRightIndex(null)}
            />
            <DockIcon 
              item={{ id: 'settings', icon: Settings, label: 'Settings' }} 
              isActive={activeTab === 'settings'} 
              onClick={() => setActiveTab('settings')} 
              isHovered={hoveredRightIndex === 1}
              isNeighborLeft={false}
              isNeighborRight={hoveredRightIndex === 0}
              onHover={() => setHoveredRightIndex(1)}
              onLeave={() => setHoveredRightIndex(null)}
            />
          </div>
        </div>
      </div>
      
      {/* Bottom Gradient Line */}
      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-50" />
    </div>
  );
};
