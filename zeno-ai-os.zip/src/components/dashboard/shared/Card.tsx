import React, { memo } from 'react';
import { motion } from 'motion/react';

export const Card = memo(({ children, className = "" }: { children: React.ReactNode, className?: string }) => (
  <div 
    className={`bg-bg-card rounded-2xl border border-glass-border relative overflow-hidden transition-all duration-300 hover:border-border-color ${className}`}
  >
    {children}
  </div>
));

Card.displayName = 'Card';
