export const COLORS = {
  bg: '#050505',
  card: '#0A0A0A',
  accent: '#06b6d4', // Cyan-500
  secondary: '#8b5cf6', // Violet-500
  text: '#ffffff',
  textSec: '#94a3b8',
  online: '#10b981', // Emerald-500
  warn: '#f59e0b', // Amber-500
  offline: '#f43f5e', // Rose-500
  grid: 'rgba(255,255,255,0.05)'
};

export const LOG_MESSAGES = [
  "Initializing neural pathways...",
  "Syncing context memory...",
  "Optimizing query parameters...",
  "Connecting to Gemini Pro...",
  "Analyzing user intent...",
  "Retrieving cached vectors...",
  "Processing natural language...",
  "Generating response tokens...",
  "Verifying safety constraints...",
  "System optimal. Ready."
];
