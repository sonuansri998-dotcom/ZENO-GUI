import React from 'react';

interface PageHeaderProps {
  title: string;
  subtitle: string;
}

export const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle }) => {
  return (
    <div className="mb-8">
      <h1 className="text-4xl font-bold text-text-primary font-space tracking-tight mb-2">
        {title}
      </h1>
      <div className="flex items-center gap-3">
        <div className="h-px w-8 bg-accent-primary/50" />
        <p className="text-sm font-mono text-accent-primary tracking-widest uppercase">
          {subtitle}
        </p>
      </div>
    </div>
  );
};
