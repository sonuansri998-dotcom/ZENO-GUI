import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { 
  Activity, 
  Server, 
  Database, 
  Play, 
  Trash2, 
  RefreshCw, 
  Power, 
  Zap,
  Terminal,
  Brain,
  Battery
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { Card } from '../shared/Card';
import { COLORS, LOG_MESSAGES } from '../shared/constants';

// --- Mock Data Generators ---
const generatePerfData = () => {
  return Array.from({ length: 30 }, (_, i) => ({
    time: i,
    cpu: 30 + Math.random() * 20,
    ram: 40 + Math.random() * 10,
    net: 10 + Math.random() * 30
  }));
};

const generateActivityData = () => {
  const currentHour = new Date().getHours();
  return Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    value: Math.floor(Math.random() * 100),
    isCurrent: i === currentHour
  }));
};

// --- Cards ---

const BatteryPowerCard = () => {
  const events = [
    { time: '10:42 AM', event: 'Optimized charging' },
    { time: '09:15 AM', event: 'Power spike detected' },
    { time: '08:30 AM', event: 'Battery saver off' },
    { time: '07:00 AM', event: 'Fully charged' },
    { time: '02:00 AM', event: 'Scheduled maintenance' },
  ];

  return (
    <Card className="p-5 flex flex-col h-full overflow-hidden">
      <div className="flex justify-between items-start mb-4 shrink-0">
        <span className="text-xs font-bold text-text-muted uppercase tracking-wider">Battery & Power</span>
        <Battery size={16} className="text-success" />
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 transform-gpu overscroll-contain">
        <div className="flex items-center gap-4 mb-4">
            <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="40" fill="none" stroke="var(--bg-secondary)" strokeWidth="8" />
                    <circle cx="50" cy="50" r="40" fill="none" stroke="var(--color-success)" strokeWidth="8" strokeDasharray="251" strokeDashoffset="38" strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                    <Zap size={20} className="text-success fill-success" />
                </div>
            </div>
            <div className="flex flex-col">
                <span className="text-3xl font-bold text-text-primary font-space">85%</span>
                <span className="text-[10px] text-text-secondary uppercase tracking-wider">4h 12m Remaining</span>
            </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-4">
            <div className="bg-bg-card rounded-lg p-2 border border-glass-border">
                <div className="text-[9px] text-text-muted uppercase mb-1">Status</div>
                <div className="text-xs font-bold text-text-primary">Discharging</div>
            </div>
            <div className="bg-bg-card rounded-lg p-2 border border-glass-border">
                <div className="text-[9px] text-text-muted uppercase mb-1">Mode</div>
                <div className="text-xs font-bold text-accent-primary">Balanced</div>
            </div>
        </div>

        <div className="space-y-2">
            <div className="text-[9px] font-bold text-text-muted uppercase tracking-wider py-1 border-b border-glass-border">Power Log</div>
            {events.map((e, i) => (
                <div key={i} className="flex justify-between items-center text-[10px] py-1 border-b border-glass-border last:border-0">
                    <span className="text-text-secondary">{e.event}</span>
                    <span className="text-text-muted font-mono">{e.time}</span>
                </div>
            ))}
        </div>
      </div>
    </Card>
  );
};

const ApiHealthCard = () => {
  return (
    <Card className="p-5 h-full flex flex-col">
      <div className="flex justify-between items-start mb-4">
        <span className="text-xs font-bold text-text-muted uppercase tracking-wider">API Health</span>
        <Activity size={16} className="text-success" />
      </div>
      
      <div className="flex-1 flex flex-col gap-3 overflow-y-auto pr-1 custom-scrollbar transform-gpu overscroll-contain">
        {[
          { name: 'Gemini', status: 'Online', lat: '120ms', req: '1.2k', err: '0.4%', score: 98, color: 'var(--color-success)' },
          { name: 'Groq', status: 'Online', lat: '45ms', req: '3.4k', err: '0.1%', score: 99, color: 'var(--color-success)' },
          { name: 'OpenRouter', status: 'Slow', lat: '850ms', req: '850', err: '2.1%', score: 76, color: 'var(--color-warning)' },
          { name: 'Claude', status: 'Online', lat: '180ms', req: '2.1k', err: '0.0%', score: 100, color: 'var(--color-success)' },
          { name: 'Mistral', status: 'Offline', lat: '---', req: '0', err: '100%', score: 0, color: 'var(--color-error)' }
        ].map((api, i) => (
          <div key={i} className="bg-bg-card rounded-xl p-3 border border-glass-border hover:border-border-color transition-colors">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: api.color, color: api.color }} />
                <span className="text-xs font-bold text-text-primary">{api.name}</span>
              </div>
              <span className="text-[10px] text-text-secondary font-mono">{api.lat}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[10px] text-text-muted">
              <div>Req: <span className="text-text-primary">{api.req}</span></div>
              <div>Err: <span className="text-text-primary">{api.err}</span></div>
            </div>
            <div className="mt-2 flex items-center gap-2">
              <div className="flex-1 h-1 bg-bg-secondary rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${api.score}%`, backgroundColor: api.color, color: api.color }} />
              </div>
              <span className="text-[9px] font-mono text-text-secondary">{api.score}%</span>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

const SystemPerfCard = () => {
  const [data, setData] = useState(generatePerfData());

  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => {
        const lastTime = prev[prev.length - 1].time;
        const newData = [...prev.slice(1), {
          time: lastTime + 1,
          cpu: 30 + Math.random() * 20,
          ram: 40 + Math.random() * 10,
          net: 10 + Math.random() * 30
        }];
        return newData;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const currentStats = data[data.length - 1];

  return (
    <Card className="p-6 h-full flex flex-col">
      <div className="flex justify-between items-center mb-6 z-10">
        <div>
          <h3 className="text-lg font-bold text-text-primary font-space">System Performance</h3>
          <p className="text-xs text-text-muted">Real-time metrics (30s window)</p>
        </div>
        <div className="flex gap-4 text-xs font-bold font-mono">
          <span className="flex items-center gap-1.5 text-error">
            <div className="w-2 h-2 rounded-full bg-error" /> 
            CPU {Math.round(currentStats.cpu)}%
          </span>
          <span className="flex items-center gap-1.5 text-accent-primary">
            <div className="w-2 h-2 rounded-full bg-accent-primary" /> 
            RAM {Math.round(currentStats.ram)}%
          </span>
          <span className="flex items-center gap-1.5 text-success">
            <div className="w-2 h-2 rounded-full bg-success" /> 
            NET {Math.round(currentStats.net)}%
          </span>
        </div>
      </div>
      
      <div className="w-full h-[200px] z-10 relative">
        <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke={COLORS.grid} vertical={false} />
            <XAxis 
              dataKey="time" 
              tick={{ fill: '#64748b', fontSize: 10 }} 
              tickFormatter={(val) => `${val}s`}
              interval={4}
            />
            <YAxis hide domain={[0, 100]} />
            <Tooltip 
              contentStyle={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)', borderRadius: '8px', boxShadow: 'var(--shadow-color)' }}
              itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
              labelStyle={{ color: '#94a3b8', fontSize: '10px', marginBottom: '4px' }}
              labelFormatter={(label) => `Time: ${label}s`}
            />
            <Line type="monotone" dataKey="cpu" stroke="var(--color-error)" strokeWidth={2} dot={false} isAnimationActive={false} />
            <Line type="monotone" dataKey="ram" stroke="var(--accent-primary)" strokeWidth={2} dot={false} isAnimationActive={false} />
            <Line type="monotone" dataKey="net" stroke="var(--color-success)" strokeWidth={2} dot={false} isAnimationActive={false} />
            <defs>
              <filter id="glow-rose" height="300%" width="300%" x="-75%" y="-75%">
                <feGaussianBlur stdDeviation="2" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="glow-cyan" height="300%" width="300%" x="-75%" y="-75%">
                <feGaussianBlur stdDeviation="2" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="glow-emerald" height="300%" width="300%" x="-75%" y="-75%">
                <feGaussianBlur stdDeviation="2" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-white/5 to-transparent pointer-events-none" />
    </Card>
  );
};

const ZenoStatusCard = () => {
  const logs = [
    { time: '15:04', msg: 'System check complete' },
    { time: '14:55', msg: 'Voice module reloaded' },
    { time: '14:30', msg: 'Network optimized' },
    { time: '14:15', msg: 'Cache cleared' },
    { time: '13:45', msg: 'Security scan finished' },
  ];

  return (
    <Card className="p-5 flex flex-col h-full overflow-hidden">
      <div className="flex justify-between items-center mb-4 shrink-0">
        <span className="text-[10px] font-bold text-text-muted uppercase tracking-wider leading-tight">ZENO Status</span>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-success/10 border border-success/20">
            <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
            <span className="text-[9px] font-bold text-success uppercase">Online</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 transform-gpu overscroll-contain">
         <div className="grid grid-cols-3 gap-2 mb-4">
            <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-bg-card border border-glass-border hover:bg-bg-card-hover transition-colors group">
                <div className="w-2 h-2 rounded-full bg-success mb-1.5 group-hover:scale-110 transition-transform" />
                <span className="text-[9px] text-text-secondary font-medium">Voice</span>
            </div>
            <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-bg-card border border-glass-border hover:bg-bg-card-hover transition-colors group">
                <div className="w-2 h-2 rounded-full bg-error mb-1.5 group-hover:scale-110 transition-transform" />
                <span className="text-[9px] text-text-secondary font-medium">Camera</span>
            </div>
            <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-bg-card border border-glass-border hover:bg-bg-card-hover transition-colors group">
                <div className="w-2 h-2 rounded-full bg-success mb-1.5 group-hover:scale-110 transition-transform" />
                <span className="text-[9px] text-text-secondary font-medium">Net</span>
            </div>
         </div>

         <div className="mb-4">
            <div className="flex justify-between items-end mb-1.5">
                <span className="text-[9px] text-text-muted uppercase tracking-wider">Last Command</span>
                <span className="text-[9px] text-text-muted font-mono">15:04</span>
            </div>
            <div className="bg-bg-primary p-2.5 rounded-lg border border-border-color font-mono text-[10px] text-success flex items-center gap-2 overflow-hidden">
                <span className="text-text-muted shrink-0">$</span>
                <span className="truncate">Analyze system logs --verbose</span>
            </div>
         </div>

         <div className="space-y-2">
            <div className="text-[9px] font-bold text-text-muted uppercase tracking-wider py-1 border-b border-glass-border">Recent Logs</div>
            {logs.map((l, i) => (
                <div key={i} className="flex gap-2 text-[10px] py-1 border-b border-glass-border last:border-0">
                    <span className="text-text-muted font-mono shrink-0">{l.time}</span>
                    <span className="text-text-secondary truncate">{l.msg}</span>
                </div>
            ))}
         </div>
      </div>
    </Card>
  );
};

const MemoryStatsCard = () => {
  return (
    <Card className="p-5 flex flex-col justify-between h-full">
      <div className="flex justify-between items-start">
        <span className="text-xs font-bold text-text-muted uppercase tracking-wider">Memory</span>
        <Brain size={18} className="text-accent-secondary" />
      </div>
      
      <div className="mt-4 flex flex-col h-full overflow-hidden">
        <div className="flex justify-between items-end mb-4">
          <span className="text-3xl font-space font-bold text-text-primary">1,247</span>
          <span className="text-[10px] text-text-secondary">Total Memories</span>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar pr-1 space-y-2 transform-gpu overscroll-contain">
          <div className="mb-3">
            <div className="flex justify-between text-[10px] text-text-secondary mb-1">
              <span>Capacity</span>
              <span>234MB / 512MB</span>
            </div>
            <div className="w-full h-2 bg-bg-secondary rounded-full overflow-hidden">
              <div className="h-full w-[45%] bg-gradient-to-r from-accent-secondary to-pink-500 rounded-full" />
            </div>
          </div>
          
          {[1, 2, 3, 4, 5].map((_, i) => (
            <div key={i} className="flex items-center gap-2 bg-bg-card p-2 rounded-lg border border-glass-border hover:border-accent-secondary/30 transition-colors">
              <div className="w-1.5 h-1.5 rounded-full bg-accent-secondary" />
              <span className="text-[10px] text-text-primary">New memory synced: Context #{1024 + i}</span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};

const TodaysSummaryCard = () => {
  const stats = [
    { label: 'Tasks Completed', value: '12', progress: 65, change: '20% more than yesterday 📈', color: 'bg-success', shadow: '' },
    { label: 'Voice Commands', value: '48', progress: 80, change: '15% more than yesterday 📈', color: 'bg-accent-primary', shadow: '' },
    { label: 'Files Analyzed', value: '5', progress: 30, change: '5% less than yesterday 📉', color: 'bg-accent-secondary', shadow: '' },
    { label: 'Reminders Set', value: '3', progress: 45, change: 'Same as yesterday', color: 'bg-warning', shadow: '' },
    { label: 'System Alerts', value: '0', progress: 0, change: 'No alerts today', color: 'bg-gray-500', shadow: 'none' },
    { label: 'API Calls', value: '1.2k', progress: 90, change: 'High usage', color: 'bg-accent-primary', shadow: '' }
  ];

  return (
    <Card className="p-5 flex flex-col h-full overflow-hidden">
      <div className="flex justify-between items-start mb-4 shrink-0">
        <h3 className="text-lg font-bold text-text-primary font-space">Today's Summary</h3>
        <div className="bg-bg-card px-3 py-1 rounded-full text-xs text-text-secondary border border-glass-border">
            {new Date().toLocaleDateString()}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-3 transform-gpu overscroll-contain">
        {stats.map((stat, i) => (
            <div key={i} className="flex flex-col gap-1.5 p-3 rounded-xl bg-bg-card border border-glass-border hover:bg-bg-card-hover transition-colors">
                <div className="flex justify-between items-end">
                    <span className="text-text-secondary text-xs font-medium">{stat.label}</span>
                    <span className="text-lg font-bold text-text-primary">{stat.value}</span>
                </div>
                <div className="w-full h-1.5 bg-bg-secondary rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${stat.color} ${stat.shadow}`} style={{ width: `${stat.progress}%` }} />
                </div>
                <span className="text-[10px] text-text-muted">{stat.change}</span>
            </div>
        ))}
      </div>
    </Card>
  );
};

const TokenUsageCard = () => {
  return (
    <Card className="p-6 flex flex-col h-full">
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-xs font-bold text-text-muted uppercase tracking-wider">Token Usage</h3>
        <Database size={16} className="text-accent-primary" />
      </div>

      <div className="flex items-center gap-4 mb-4">
        {/* Circular Chart */}
        <div className="relative w-20 h-20 flex-shrink-0 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="42" fill="none" stroke="var(--bg-secondary)" strokeWidth="8" />
            <circle cx="50" cy="50" r="42" fill="none" stroke="var(--accent-primary)" strokeWidth="8" strokeDasharray="264" strokeDashoffset="92" strokeLinecap="round" />
            </svg>
            <div className="absolute text-center">
            <div className="text-sm font-bold text-text-primary font-space">1.2M</div>
            <div className="text-[7px] text-text-muted uppercase">Used</div>
            </div>
        </div>

        {/* Stats */}
        <div className="flex-1 grid grid-cols-2 gap-y-2 gap-x-2 text-[10px]">
            <div>
                <div className="text-text-muted">Total</div>
                <div className="text-text-primary font-bold">1,245,890</div>
            </div>
            <div>
                <div className="text-text-muted">Remaining</div>
                <div className="text-text-primary font-bold">800K</div>
            </div>
            <div>
                <div className="text-text-muted">Input</div>
                <div className="text-accent-primary font-bold">845K</div>
            </div>
            <div>
                <div className="text-text-muted">Output</div>
                <div className="text-accent-secondary font-bold">400K</div>
            </div>
        </div>
      </div>

      {/* Provider Breakdown */}
      <div className="space-y-2 mt-auto">
        <div className="text-[9px] font-bold text-text-muted uppercase tracking-wider mb-1">Provider Breakdown</div>
        {[
          { name: 'Gemini', val: '65%', color: 'bg-accent-primary', width: '65%' },
          { name: 'Groq', val: '25%', color: 'bg-accent-secondary', width: '25%' },
          { name: 'OpenRouter', val: '10%', color: 'bg-slate-600', width: '10%' }
        ].map((item, i) => (
          <div key={i} className="space-y-1">
            <div className="flex justify-between text-[9px]">
                <span className="text-text-secondary">{item.name}</span>
                <span className="text-text-primary">{item.val}</span>
            </div>
            <div className="w-full h-1 bg-bg-secondary rounded-full overflow-hidden">
                <div className={`h-full rounded-full ${item.color}`} style={{ width: item.width }} />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

const QuickActionsCard = () => {
  const actions = [
    { icon: Play, label: 'Run Task', color: 'text-success', hover: 'hover:bg-success/10 hover:border-success/30' },
    { icon: Trash2, label: 'Clear Cache', color: 'text-error', hover: 'hover:bg-error/10 hover:border-error/30' },
    { icon: RefreshCw, label: 'Sync Memory', color: 'text-accent-secondary', hover: 'hover:bg-accent-secondary/10 hover:border-accent-secondary/30' },
    { icon: Power, label: 'Restart AI', color: 'text-warning', hover: 'hover:bg-warning/10 hover:border-warning/30' },
    { icon: Zap, label: 'Optimize', color: 'text-accent-primary', hover: 'hover:bg-accent-primary/10 hover:border-accent-primary/30' },
    { icon: Activity, label: 'Sys Scan', color: 'text-accent-secondary', hover: 'hover:bg-accent-secondary/10 hover:border-accent-secondary/30' },
  ];

  return (
    <Card className="p-4 flex flex-col h-full">
      <div className="flex justify-between items-start mb-3">
        <span className="text-[10px] font-bold text-text-muted uppercase tracking-wider">Quick Actions</span>
        <Zap size={14} className="text-warning" />
      </div>
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-1 transform-gpu overscroll-contain">
        <div className="grid grid-cols-3 gap-1.5">
          {actions.map((action, i) => (
            <button
              key={i}
              className={`flex flex-col items-center justify-center gap-1 p-1.5 rounded-md bg-bg-card border border-glass-border transition-all duration-200 ${action.hover} group`}
            >
              <action.icon size={12} className={`${action.color} opacity-80 group-hover:opacity-100`} />
              <span className="text-[8px] font-medium text-text-primary group-hover:text-text-primary">{action.label}</span>
            </button>
          ))}
        </div>
      </div>
    </Card>
  );
};

const AiThinkingCard = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, []);

  return (
    <Card className="p-5 flex flex-col h-full">
      <div className="flex justify-between items-start mb-4">
        <span className="text-xs font-bold text-text-muted uppercase tracking-wider">AI Activity Log</span>
        <Terminal size={16} className="text-text-muted" />
      </div>
      <div 
        ref={scrollRef}
        className="flex-1 overflow-hidden relative font-mono text-[10px] space-y-2"
      >
        <div className="absolute top-0 left-0 w-full h-8 bg-gradient-to-b from-bg-card to-transparent z-10 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-full h-8 bg-gradient-to-t from-bg-card to-transparent z-10 pointer-events-none" />
        
        <div 
          className="space-y-2"
        >
          {LOG_MESSAGES.map((log, i) => (
            <div key={i} className="flex gap-2 text-text-secondary border-l-2 border-border-color pl-2">
              <span className="text-text-muted">{new Date().toLocaleTimeString()}</span>
              <span className={log.includes("Error") ? "text-error" : "text-text-primary"}>{log}</span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};

export const Overview = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-[1600px] mx-auto grid grid-cols-12 gap-6 auto-rows-[180px] h-full overflow-y-auto custom-scrollbar pr-2 transform-gpu overscroll-contain"
    >
      {/* Row 1: Status & Quick Actions */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="col-span-12 md:col-span-3 row-span-1"
      >
        <ZenoStatusCard />
      </motion.div>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15 }}
        className="col-span-12 md:col-span-3 row-span-1"
      >
        <BatteryPowerCard />
      </motion.div>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="col-span-12 md:col-span-3 row-span-1"
      >
        <MemoryStatsCard />
      </motion.div>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.25 }}
        className="col-span-12 md:col-span-3 row-span-1"
      >
        <QuickActionsCard />
      </motion.div>

      {/* Row 2: Performance & Health */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="col-span-12 md:col-span-8 row-span-2"
      >
        <SystemPerfCard />
      </motion.div>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.35 }}
        className="col-span-12 md:col-span-4 row-span-2"
      >
        <ApiHealthCard />
      </motion.div>

      {/* Row 3: Activity & Tokens */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="col-span-12 md:col-span-4 row-span-2"
      >
        <TodaysSummaryCard />
      </motion.div>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.45 }}
        className="col-span-12 md:col-span-4 row-span-2"
      >
        <TokenUsageCard />
      </motion.div>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="col-span-12 md:col-span-4 row-span-2"
      >
        <AiThinkingCard />
      </motion.div>
    </motion.div>
  );
};
