import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from '../shared/Card';
import { PageHeader } from '@/components/dashboard/shared/PageHeader';
import { Search, Plus, Edit2, Trash2, Pin, Brain, Database, Cpu, Clock, Zap, Shield, Filter } from 'lucide-react';

const MemorySearch = () => {
  return (
    <div className="relative mb-6 group">
      <div className="relative">
        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted group-focus-within:text-white transition-colors duration-300" />
        <input 
          type="text" 
          placeholder="Search memory banks..." 
          className="w-full bg-glass-bg backdrop-blur-md border border-border-color rounded-xl py-4 pl-12 pr-4 text-text-primary placeholder:text-text-muted focus:border-white/30 focus:bg-white/5 outline-none transition-all duration-300 ease-out"
        />
      </div>
    </div>
  );
};

const MemoryCapacity = () => {
  return (
    <Card className="p-6 mb-6 relative overflow-hidden group">
      <div className="absolute top-0 right-0 w-32 h-32 bg-accent-secondary/10 rounded-full blur-3xl -mr-10 -mt-10 transition-transform group-hover:scale-150 duration-700" />
      
      <div className="flex justify-between items-center mb-6 relative z-10">
        <div className="flex items-center gap-2">
          <Database size={18} className="text-accent-secondary" />
          <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">Neural Storage</h3>
        </div>
        <span className="text-xs font-mono text-accent-secondary bg-accent-secondary/10 px-2 py-1 rounded-md border border-accent-secondary/20">Active</span>
      </div>
      
      <div className="flex justify-between items-end mb-3 relative z-10">
        <div className="flex flex-col">
          <span className="text-3xl font-bold text-text-primary tracking-tight">234<span className="text-lg text-text-muted font-normal">MB</span></span>
          <span className="text-xs text-text-muted mt-1">of 512MB Allocated</span>
        </div>
        <div className="text-right">
          <span className="text-lg font-bold text-accent-secondary">45%</span>
        </div>
      </div>
      
      <div className="w-full h-3 bg-bg-primary rounded-full overflow-hidden mb-6 relative z-10 border border-glass-border">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: '45%' }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="h-full bg-gradient-to-r from-accent-primary via-accent-secondary to-pink-500 rounded-full relative"
        >
          <div className="absolute inset-0 bg-white/20 animate-pulse" />
        </motion.div>
      </div>

      <div className="grid grid-cols-3 gap-3 relative z-10">
        <div className="flex flex-col gap-1 p-2 rounded-lg bg-bg-card border border-glass-border">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-accent-primary" />
            <span className="text-[10px] text-text-secondary font-medium uppercase tracking-wider">Vector DB</span>
          </div>
          <span className="text-sm font-bold text-text-primary pl-3.5">142MB</span>
        </div>
        <div className="flex flex-col gap-1 p-2 rounded-lg bg-bg-card border border-glass-border">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-accent-secondary" />
            <span className="text-[10px] text-text-secondary font-medium uppercase tracking-wider">Context</span>
          </div>
          <span className="text-sm font-bold text-text-primary pl-3.5">92MB</span>
        </div>
        <div className="flex flex-col gap-1 p-2 rounded-lg bg-bg-card border border-glass-border">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-text-muted" />
            <span className="text-[10px] text-text-secondary font-medium uppercase tracking-wider">Free</span>
          </div>
          <span className="text-sm font-bold text-text-muted pl-3.5">278MB</span>
        </div>
      </div>
    </Card>
  );
};

const MemoryControls = () => {
  const buttons = [
    { icon: Plus, label: "Add Memory", color: "text-success", bg: "bg-success/10", border: "border-success/20", hover: "hover:bg-success/20 hover:border-success/40" },
    { icon: Zap, label: "Optimize", color: "text-accent-primary", bg: "bg-accent-primary/10", border: "border-accent-primary/20", hover: "hover:bg-accent-primary/20 hover:border-accent-primary/40" },
    { icon: Pin, label: "Pinned", color: "text-warning", bg: "bg-warning/10", border: "border-warning/20", hover: "hover:bg-warning/20 hover:border-warning/40" },
    { icon: Trash2, label: "Clear Cache", color: "text-error", bg: "bg-error/10", border: "border-error/20", hover: "hover:bg-error/20 hover:border-error/40" },
  ];

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-[10px] font-bold text-text-secondary uppercase tracking-wider">Operations</h3>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {buttons.map((btn, i) => (
          <button 
            key={i}
            className={`flex flex-col items-center justify-center gap-1.5 p-2 rounded-lg bg-bg-card border border-glass-border transition-all duration-200 ${btn.hover} group`}
          >
            <div className={`p-1.5 rounded-md ${btn.bg} border ${btn.border}`}>
              <btn.icon size={14} className={`${btn.color} opacity-80 group-hover:opacity-100 transition-all`} />
            </div>
            <span className={`text-[9px] font-medium tracking-wider ${btn.color} opacity-80 group-hover:opacity-100`}>{btn.label}</span>
          </button>
        ))}
      </div>
    </Card>
  );
};

const MemoryEntries = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [expandedId, setExpandedId] = useState<number | null>(null);
  
  const memories = [
    { id: 1, type: "User Preference", content: "User prefers dark UI and compact data density. Always use metric system. This preference should be applied across all dashboard views and data visualizations to ensure a consistent experience.", date: "2h ago", icon: Brain, color: "text-accent-primary", category: 'preference', importance: 'high' },
    { id: 2, type: "Project Context", content: "ARIS AI assistant roadmap saved. Phase 2 focuses on autonomous agent capabilities including self-healing code, automated deployment pipelines, and advanced natural language reasoning.", date: "5h ago", icon: Cpu, color: "text-accent-secondary", category: 'project', importance: 'medium' },
    { id: 3, type: "Conversation", content: "Discussed Q3 goals: Increase user retention by 15% and launch mobile app beta. The marketing team will need the new assets by next Friday to prepare for the launch campaign.", date: "1d ago", icon: Database, color: "text-success", category: 'chat', importance: 'high' },
    { id: 4, type: "System Config", content: "Default code language set to TypeScript. Strict mode enabled. All new repositories must pass the updated ESLint rules before merging to main.", date: "2d ago", icon: Shield, color: "text-warning", category: 'system', importance: 'low' },
    { id: 5, type: "Project Context", content: "Design system colors updated. Primary brand color is now #06b6d4 (Cyan). Ensure all secondary and tertiary colors are updated in the Figma library to match the new contrast requirements.", date: "3d ago", icon: Cpu, color: "text-accent-secondary", category: 'project', importance: 'medium' },
  ];

  const filters = [
    { id: 'all', label: 'All Memories' },
    { id: 'preference', label: 'Preferences' },
    { id: 'project', label: 'Projects' },
    { id: 'chat', label: 'Conversations' },
  ];

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <Card className="p-6 h-full flex flex-col relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-accent-primary/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
      
      <div className="flex justify-between items-center mb-6 relative z-10">
        <div>
          <h3 className="text-lg font-bold text-text-primary font-space flex items-center gap-2">
            <Brain size={20} className="text-accent-primary" />
            Memory Bank
          </h3>
          <p className="text-xs text-text-muted mt-1">Long-term context and learned preferences</p>
        </div>
        
        <div className="flex items-center gap-2 bg-bg-primary p-1 rounded-lg border border-border-color">
          {filters.map(f => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`relative px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeFilter === f.id 
                  ? 'text-text-primary' 
                  : 'text-text-muted hover:text-text-primary hover:bg-bg-card'
              }`}
            >
              {activeFilter === f.id && (
                <motion.div 
                  layoutId="activeMemoryFilter" 
                  className="absolute inset-0 bg-white/10 rounded-md" 
                />
              )}
              <span className="relative z-10">{f.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 relative z-10 transform-gpu overscroll-contain">
        <div className="space-y-3 w-full">
          <AnimatePresence mode="popLayout">
            {memories.filter(m => activeFilter === 'all' || m.category === activeFilter).map((mem, i) => {
              const isExpanded = expandedId === mem.id;
              return (
                <motion.div 
                  layout
                  key={mem.id} 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                  onClick={() => toggleExpand(mem.id)}
                  className={`bg-glass-bg rounded-xl p-4 border border-glass-border cursor-pointer group relative overflow-hidden transition-all duration-300 hover:border-border-color`}
                >
                  {mem.importance === 'high' && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-accent-primary" />
                  )}
                  
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-md bg-bg-card ${mem.color}`}>
                        <mem.icon size={14} />
                      </div>
                      <span className={`text-[11px] font-bold uppercase tracking-wider ${mem.color}`}>{mem.type}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 text-[10px] text-text-muted font-mono bg-bg-card px-2 py-1 rounded-md">
                        <Clock size={10} />
                        {mem.date}
                      </span>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={(e) => e.stopPropagation()}
                          className="p-1 text-text-muted hover:text-accent-primary transition-colors"
                        >
                          <Edit2 size={12} />
                        </button>
                        <button 
                          onClick={(e) => e.stopPropagation()}
                          className="p-1 text-text-muted hover:text-error transition-colors"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                  <motion.div layout className="relative">
                    <p 
                      className={`text-sm text-text-primary group-hover:text-text-primary transition-colors leading-relaxed pl-1 ${isExpanded ? '' : 'line-clamp-1'}`}
                    >
                      {mem.content}
                    </p>
                  </motion.div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </Card>
  );
};

export const Memory = () => {
  return (
    <div className="max-w-[1600px] mx-auto h-full flex flex-col">
      <PageHeader title="MEMORY" subtitle="KNOWLEDGE BASE" />
      <div className="grid grid-cols-12 gap-6 flex-1 min-h-0 pb-6">
        <div className="col-span-12 md:col-span-4 flex flex-col gap-6 overflow-y-auto custom-scrollbar pr-2 transform-gpu overscroll-contain">
          <div className="animate-stagger-1 shrink-0"><MemorySearch /></div>
          <div className="animate-stagger-2 shrink-0"><MemoryCapacity /></div>
          <div className="animate-stagger-3 shrink-0"><MemoryControls /></div>
        </div>
        <div className="col-span-12 md:col-span-8 h-full animate-stagger-4">
          <MemoryEntries />
        </div>
      </div>
    </div>
  );
};
