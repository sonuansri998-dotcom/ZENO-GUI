import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from '../shared/Card';
import { PageHeader } from '@/components/dashboard/shared/PageHeader';
import { UploadCloud, FileText, Image, Code, MoreVertical, File, Download, Trash2, Edit2, Search, Zap, Filter, Grid, List, FolderOpen } from 'lucide-react';

const FileUpload = () => {
  return (
    <div className="relative border-2 border-dashed border-border-color rounded-2xl p-8 flex flex-col items-center justify-center text-center hover:border-accent-primary/30 hover:bg-accent-primary/5 transition-all cursor-pointer group mb-6 overflow-hidden shrink-0">
      <div className="absolute inset-0 bg-gradient-to-b from-accent-primary/0 to-accent-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="w-16 h-16 bg-bg-card rounded-full flex items-center justify-center mb-4 group-hover:scale-110 group-hover:bg-accent-primary/10 transition-all duration-300 relative z-10">
        <UploadCloud size={32} className="text-text-secondary group-hover:text-accent-primary transition-colors" />
      </div>
      <h3 className="text-lg font-bold text-text-primary mb-1 relative z-10">Drop files here</h3>
      <p className="text-sm text-text-muted mb-4 relative z-10">or click to browse</p>
      <div className="flex gap-2 text-[10px] text-text-muted uppercase font-bold tracking-wider relative z-10">
        <span className="bg-bg-card px-2 py-1 rounded">PDF</span>
        <span className="bg-bg-card px-2 py-1 rounded">Images</span>
        <span className="bg-bg-card px-2 py-1 rounded">Text</span>
        <span className="bg-bg-card px-2 py-1 rounded">Code</span>
      </div>
    </div>
  );
};

const RecentFiles = () => {
  const files = [
    { name: "report_q3.pdf", status: "analyzed", color: "text-error", bg: "bg-error/10" },
    { name: "meeting_notes.txt", status: "summarized", color: "text-accent-primary", bg: "bg-accent-primary/10" },
    { name: "user_data.csv", status: "processed", color: "text-success", bg: "bg-success/10" },
  ];

  return (
    <Card className="p-6 mb-6 shrink-0">
      <h3 className="text-sm font-bold text-text-secondary uppercase tracking-wider mb-4">Recent Activity</h3>
      <div className="space-y-2 max-h-[200px] overflow-y-auto custom-scrollbar pr-1">
        {files.map((file, i) => (
          <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-bg-card border border-glass-border hover:bg-bg-card-hover transition-colors group cursor-pointer">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${file.bg}`}>
                <FileText size={14} className={file.color} />
              </div>
              <span className="text-sm text-text-primary group-hover:text-text-primary transition-colors">{file.name}</span>
            </div>
            <span className={`text-[10px] font-bold uppercase tracking-wider ${file.color}`}>{file.status}</span>
          </div>
        ))}
      </div>
    </Card>
  );
};

const AiFileTools = () => {
  const tools = [
    { icon: Zap, label: "Summarize", color: "#ffaa44", bg: "rgba(255, 170, 68, 0.1)", border: "rgba(255, 170, 68, 0.2)" },
    { icon: Search, label: "Analyze", color: "#00f5ff", bg: "rgba(0, 245, 255, 0.1)", border: "rgba(0, 245, 255, 0.2)" },
    { icon: FileText, label: "Extract", color: "#44ffaa", bg: "rgba(68, 255, 170, 0.1)", border: "rgba(68, 255, 170, 0.2)" },
    { icon: File, label: "Report", color: "#aa88ff", bg: "rgba(170, 136, 255, 0.1)", border: "rgba(170, 136, 255, 0.2)" },
  ];

  return (
    <Card className="p-4 mb-6 shrink-0">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-[10px] font-bold text-text-secondary uppercase tracking-wider">AI TOOLS</h3>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {tools.map((tool, i) => (
          <button 
            key={i}
            className="flex flex-col items-center justify-center gap-1.5 p-2 rounded-lg bg-bg-card border border-glass-border transition-all duration-200 hover:bg-white/[0.02] hover:border-white/10 group"
          >
            <div 
              className="p-1.5 rounded-md border transition-transform duration-300 group-hover:scale-110"
              style={{ backgroundColor: tool.bg, borderColor: tool.border }}
            >
              <tool.icon size={14} style={{ color: tool.color }} className="opacity-80 group-hover:opacity-100 transition-all" />
            </div>
            <span 
              className="text-[9px] font-medium tracking-wider opacity-80 group-hover:opacity-100"
              style={{ color: tool.color }}
            >
              {tool.label}
            </span>
          </button>
        ))}
      </div>
    </Card>
  );
};

const FileExplorer = () => {
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [searchQuery, setSearchQuery] = useState('');

  const files = [
    { id: 1, name: "project_proposal_v2.pdf", size: "2.4 MB", date: "Today, 10:23 AM", type: "pdf", color: "text-error", bg: "bg-error/10" },
    { id: 2, name: "dashboard_mockup.png", size: "4.1 MB", date: "Yesterday, 4:15 PM", type: "image", color: "text-accent-secondary", bg: "bg-accent-secondary/10" },
    { id: 3, name: "auth_service.ts", size: "12 KB", date: "Mar 4, 2026", type: "code", color: "text-accent-primary", bg: "bg-accent-primary/10" },
    { id: 4, name: "meeting_notes_q1.txt", size: "4 KB", date: "Mar 3, 2026", type: "text", color: "text-success", bg: "bg-success/10" },
    { id: 5, name: "budget_2026_final.xlsx", size: "1.2 MB", date: "Mar 1, 2026", type: "sheet", color: "text-success", bg: "bg-success/10" },
    { id: 6, name: "user_research_data.pdf", size: "3.5 MB", date: "Feb 28, 2026", type: "pdf", color: "text-error", bg: "bg-error/10" },
  ];

  const getIcon = (type: string, className: string) => {
    switch(type) {
      case 'pdf': return <FileText size={20} className={className} />;
      case 'image': return <Image size={20} className={className} />;
      case 'code': return <Code size={20} className={className} />;
      default: return <File size={20} className={className} />;
    }
  };

  const filteredFiles = files.filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <Card className="p-6 h-full flex flex-col relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-accent-primary/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
      
      <div className="flex justify-between items-center mb-6 relative z-10">
        <div>
          <h3 className="text-lg font-bold text-text-primary font-space flex items-center gap-2">
            <FolderOpen size={20} className="text-accent-primary" />
            File Explorer
          </h3>
          <p className="text-xs text-text-muted mt-1">Manage and analyze your documents</p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="relative group">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted group-focus-within:text-white transition-colors duration-300" />
            <input 
              type="text" 
              placeholder="Search files..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-48 bg-bg-primary border border-border-color rounded-lg py-2 pl-9 pr-3 text-sm text-text-primary placeholder:text-text-muted focus:border-white/30 focus:bg-white/5 outline-none transition-all duration-300 ease-out"
            />
          </div>
          <div className="flex items-center bg-bg-primary rounded-lg border border-border-color p-1">
            <button 
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-md transition-colors ${viewMode === 'list' ? 'bg-white/10 text-text-primary' : 'text-text-muted hover:text-text-primary'}`}
            >
              <List size={16} />
            </button>
            <button 
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-white/10 text-text-primary' : 'text-text-muted hover:text-text-primary'}`}
            >
              <Grid size={16} />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 relative z-10 transform-gpu overscroll-contain">
        {filteredFiles.length === 0 ? (
          <div 
            className="h-full flex flex-col items-center justify-center text-text-muted space-y-4 w-full"
          >
            <div className="w-16 h-16 rounded-full bg-bg-card flex items-center justify-center">
              <Search size={24} className="opacity-50" />
            </div>
            <p className="text-sm">No files found matching "{searchQuery}"</p>
          </div>
        ) : viewMode === 'list' ? (
          <div 
            className="space-y-2 w-full"
          >
            {filteredFiles.map((file, i) => (
              <div 
                key={`list-${file.id}`} 
                className={`flex items-center justify-between p-4 rounded-xl bg-glass-bg border border-glass-border hover:border-border-color hover:bg-bg-card-hover transition-all group animate-stagger-${Math.min(i + 1, 9)}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg ${file.bg} flex items-center justify-center border border-glass-border`}>
                    {getIcon(file.type, file.color)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-text-primary group-hover:text-text-primary transition-colors">{file.name}</h4>
                    <div className="flex gap-2 text-[10px] text-text-muted font-mono mt-1">
                      <span>{file.size}</span>
                      <span>•</span>
                      <span>{file.date}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-2 hover:bg-accent-primary/10 rounded-lg text-text-secondary hover:text-accent-primary transition-colors" title="Analyze with AI">
                    <Zap size={16} />
                  </button>
                  <button className="p-2 hover:bg-bg-card-hover rounded-lg text-text-secondary hover:text-text-primary transition-colors" title="Download">
                    <Download size={16} />
                  </button>
                  <button className="p-2 hover:bg-error/10 rounded-lg text-text-secondary hover:text-error transition-colors" title="Delete">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div 
            className="grid grid-cols-3 gap-4 w-full"
          >
            {filteredFiles.map((file, i) => (
              <div 
                key={`grid-${file.id}`} 
                className={`flex flex-col p-4 rounded-xl bg-glass-bg border border-glass-border hover:border-border-color hover:bg-bg-card-hover transition-all group relative animate-stagger-${Math.min(i + 1, 9)}`}
              >
                <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1.5 bg-black/50 backdrop-blur-md rounded-md text-text-secondary hover:text-accent-primary transition-colors" title="Analyze">
                    <Zap size={14} />
                  </button>
                  <button className="p-1.5 bg-black/50 backdrop-blur-md rounded-md text-text-secondary hover:text-text-primary transition-colors" title="More">
                    <MoreVertical size={14} />
                  </button>
                </div>
                
                <div className={`w-12 h-12 rounded-xl ${file.bg} flex items-center justify-center border border-glass-border mb-4`}>
                  {getIcon(file.type, file.color)}
                </div>
                
                <h4 className="text-sm font-bold text-text-primary group-hover:text-text-primary transition-colors truncate mb-1" title={file.name}>{file.name}</h4>
                <div className="flex flex-col gap-1 text-[10px] text-text-muted font-mono">
                  <span>{file.size}</span>
                  <span>{file.date}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Card>
  );
};

export const Files = () => {
  return (
    <div className="max-w-[1600px] mx-auto h-full flex flex-col">
      <PageHeader title="FILES" subtitle="STORAGE & ASSETS" />
      <div className="grid grid-cols-12 gap-6 flex-1 min-h-0 pb-6">
        <div className="col-span-12 md:col-span-4 flex flex-col overflow-y-auto custom-scrollbar pr-2 transform-gpu overscroll-contain">
          <FileUpload />
          <RecentFiles />
          <AiFileTools />
        </div>
        <div className="col-span-12 md:col-span-8 h-full">
          <FileExplorer />
        </div>
      </div>
    </div>
  );
};
