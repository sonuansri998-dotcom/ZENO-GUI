import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Settings as SettingsIcon, 
  User, 
  Mic, 
  Shield, 
  Bell, 
  Database, 
  Cpu, 
  Key,
  Fingerprint
} from 'lucide-react';

// Import Section Components
import { General } from './settings/General';
import { Account } from './settings/Account';
import { MyIdentity } from './settings/MyIdentity';
import { Voices } from './settings/Voices';
import { PrivacySecurity } from './settings/PrivacySecurity';
import { Notifications } from './settings/Notifications';
import { DataStorage } from './settings/DataStorage';
import { Advanced } from './settings/Advanced';
import { ApiKeys } from './settings/ApiKeys';
import { SettingsProvider, useSettings } from './settings/SettingsContext';
import { ConfirmationDialog } from '../../shared/ConfirmationDialog';

const SettingsContent = () => {
  const [activeSection, setActiveSection] = useState('general');
  const { isDirty, setPendingSection, pendingSection, confirmNavigation, cancelNavigation } = useSettings();

  const menuItems = useMemo(() => [
    { id: 'general', label: 'General', icon: SettingsIcon },
    { id: 'account', label: 'Account', icon: User },
    { id: 'identity', label: 'My Identity', icon: Fingerprint },
    { id: 'voices', label: 'Voices', icon: Mic },
    { id: 'privacy', label: 'Privacy & Security', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'storage', label: 'Data & Storage', icon: Database },
    { id: 'advanced', label: 'Advanced', icon: Cpu },
    { id: 'apikeys', label: 'API Keys', icon: Key },
  ], []);

  const handleSectionChange = (sectionId: string) => {
    if (activeSection === sectionId) return;
    
    if (isDirty) {
      setPendingSection(sectionId);
    } else {
      setActiveSection(sectionId);
    }
  };

  const handleConfirmNavigation = () => {
    if (pendingSection) {
      setActiveSection(pendingSection);
      confirmNavigation();
    }
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'general': return <General />;
      case 'account': return <Account />;
      case 'identity': return <MyIdentity />;
      case 'voices': return <Voices />;
      case 'privacy': return <PrivacySecurity />;
      case 'notifications': return <Notifications />;
      case 'storage': return <DataStorage />;
      case 'advanced': return <Advanced />;
      case 'apikeys': return <ApiKeys />;
      default: return <General />;
    }
  };

  return (
    <>
      <div className="max-w-[1600px] mx-auto h-full flex gap-8 overflow-hidden">
        {/* Sidebar Navigation */}
        <div className="w-64 flex-shrink-0 h-full border-r border-white/5 flex flex-col">
          <div className="h-24 flex flex-col justify-center px-6 border-b border-white/5 bg-[#0A0A0A]">
            <div className="mb-0">
              <h1 className="text-2xl font-bold text-text-primary font-space tracking-wide">SETTINGS</h1>
              <p className="text-xs text-text-muted font-mono mt-1">SYSTEM CONFIGURATION</p>
            </div>
          </div>
            
          <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-1 mt-4 px-3 pb-4 transform-gpu overscroll-contain">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleSectionChange(item.id)}
                  className="relative w-full flex items-center gap-3 px-4 py-3 rounded-lg group overflow-hidden transition-colors"
                >
                  {activeSection === item.id && (
                    <motion.div
                      layoutId="activeBackground"
                      className="absolute inset-0 bg-bg-card rounded-lg border border-glass-border"
                      initial={false}
                      transition={{ 
                        type: "spring",
                        stiffness: 500,
                        damping: 30
                      }}
                    />
                  )}
                  
                  <div className={`relative z-10 flex items-center justify-center transition-colors duration-200 ${
                    activeSection === item.id ? 'text-text-primary' : 'text-text-muted group-hover:text-text-primary'
                  }`}>
                    <item.icon size={18} />
                  </div>
                  
                  <span className={`relative z-10 text-sm font-medium transition-colors duration-200 ${
                    activeSection === item.id ? 'text-text-primary' : 'text-text-muted group-hover:text-text-primary'
                  }`}>
                    {item.label}
                  </span>

                  {activeSection === item.id && (
                    <motion.div
                      layoutId="activeGlow"
                      className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-4 bg-text-primary rounded-r-full shadow-[0_0_8px_var(--text-primary)]"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.2 }}
                    />
                  )}
                </button>
              ))}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 min-w-0 h-full overflow-y-auto custom-scrollbar pr-2 scroll-smooth transform-gpu overscroll-contain">
          <div className="max-w-4xl mx-auto px-8 py-8 pb-20">
            <div key={activeSection} className="animate-fade-in">
              {renderContent()}
            </div>
          </div>
        </div>
      </div>

      <ConfirmationDialog
        isOpen={!!pendingSection}
        onClose={cancelNavigation}
        onConfirm={handleConfirmNavigation}
        title="Unsaved Changes"
        message="You have unsaved changes. Are you sure you want to leave this section? Your changes will be lost."
        confirmText="Leave Anyway"
        cancelText="Stay"
        isDanger={true}
      />
    </>
  );
};

export const Settings = () => {
  return (
    <SettingsProvider>
      <SettingsContent />
    </SettingsProvider>
  );
};
