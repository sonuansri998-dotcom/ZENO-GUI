import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from '../shared/Card';
import { PageHeader } from '@/components/dashboard/shared/PageHeader';
import { 
  Bell, 
  Info, 
  AlertTriangle, 
  CheckCircle, 
  X, 
  Check, 
  Trash2, 
  ShieldAlert,
  Cpu,
  Database
} from 'lucide-react';

type NotifType = 'system' | 'task' | 'security' | 'alert';

interface Notification {
  id: string;
  type: NotifType;
  title: string;
  message: string;
  time: string;
  isRead: boolean;
  icon: any;
  color: string;
  bgColor: string;
}

const initialNotifs: Notification[] = [
  { 
    id: '1', 
    type: 'alert', 
    title: 'High Memory Usage',
    message: 'System memory usage has exceeded 85%. Consider closing background tasks. This could impact the performance of currently running model training jobs. Please review the Active Queue and pause non-critical tasks.', 
    time: '10m ago', 
    isRead: false,
    icon: AlertTriangle, 
    color: 'text-warning',
    bgColor: 'bg-warning/10'
  },
  { 
    id: '2', 
    type: 'task', 
    title: 'Data Analysis Complete',
    message: 'The scheduled data analysis task "Q3_Report" finished successfully. The output file has been saved to your local storage and is ready for review.', 
    time: '1h ago', 
    isRead: false,
    icon: CheckCircle, 
    color: 'text-success',
    bgColor: 'bg-success/10'
  },
  { 
    id: '3', 
    type: 'system', 
    title: 'System Update Scheduled',
    message: 'A mandatory system update is scheduled for 02:00 AM UTC. The system will be offline for approximately 15 minutes.', 
    time: '3h ago', 
    isRead: true,
    icon: Cpu, 
    color: 'text-accent-primary',
    bgColor: 'bg-accent-primary/10'
  },
  { 
    id: '4', 
    type: 'security', 
    title: 'New Login Detected',
    message: 'A new login was detected from IP 192.168.1.45 (Singapore). If this was not you, please secure your account immediately.', 
    time: '5h ago', 
    isRead: true,
    icon: ShieldAlert, 
    color: 'text-accent-secondary',
    bgColor: 'bg-accent-secondary/10'
  },
  { 
    id: '5', 
    type: 'system', 
    title: 'Database Backup Complete',
    message: 'Daily automated backup of primary database completed. 1.2GB of data was successfully synced to the cloud storage.', 
    time: '1d ago', 
    isRead: true,
    icon: Database, 
    color: 'text-accent-primary',
    bgColor: 'bg-accent-primary/10'
  },
];

export const Notifs = () => {
  const [notifs, setNotifs] = useState<Notification[]>(initialNotifs);
  const [activeFilter, setActiveFilter] = useState<'all' | 'unread' | 'system' | 'task'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const markAsRead = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setNotifs(notifs.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllAsRead = () => {
    setNotifs(notifs.map(n => ({ ...n, isRead: true })));
  };

  const deleteNotif = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setNotifs(notifs.filter(n => n.id !== id));
    if (expandedId === id) setExpandedId(null);
  };

  const clearAll = () => {
    setNotifs([]);
    setExpandedId(null);
  };

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const filteredNotifs = notifs.filter(n => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'unread') return !n.isRead;
    return n.type === activeFilter;
  });

  const unreadCount = notifs.filter(n => !n.isRead).length;

  const filters = [
    { id: 'all', label: 'All' },
    { id: 'unread', label: `Unread (${unreadCount})` },
    { id: 'system', label: 'System' },
    { id: 'task', label: 'Tasks' },
  ];

  return (
    <div className="max-w-4xl mx-auto h-full flex flex-col pb-6">
      <PageHeader title="NOTIFICATIONS" subtitle="ALERTS & UPDATES" />
      
      <div className="flex-1 min-h-0 flex flex-col gap-6">
        {/* Controls Bar */}
        <div className="flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 bg-bg-card p-1 rounded-lg border border-glass-border">
            {filters.map(filter => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id as any)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeFilter === filter.id 
                    ? 'bg-white/10 text-text-primary' 
                    : 'text-text-secondary hover:text-text-primary hover:bg-bg-card'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button 
              onClick={markAllAsRead}
              disabled={unreadCount === 0}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-text-secondary hover:text-text-primary hover:bg-bg-card transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Check size={16} />
              Mark all read
            </button>
            <button 
              onClick={clearAll}
              disabled={notifs.length === 0}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-error hover:text-error/80 hover:bg-error/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Trash2 size={16} />
              Clear all
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <Card className="flex-1 min-h-0 overflow-hidden flex flex-col border-glass-border bg-bg-secondary/50 backdrop-blur-xl">
          <div className="flex-1 overflow-y-auto custom-scrollbar p-4 transform-gpu overscroll-contain">
            <AnimatePresence mode="popLayout">
              {filteredNotifs.length > 0 ? (
                <motion.div 
                  key={activeFilter}
                  layout
                  className="space-y-3 w-full"
                >
                  {filteredNotifs.map((notif, i) => {
                    const isExpanded = expandedId === notif.id;
                    return (
                      <motion.div 
                        key={notif.id} 
                        layout
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ 
                          duration: 0.4, 
                          delay: i * 0.05,
                          ease: [0.23, 1, 0.32, 1]
                        }}
                        onClick={() => toggleExpand(notif.id)}
                        whileHover={{ y: -2, transition: { duration: 0.2 } }}
                        className={`group relative flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all duration-300 ${
                          notif.isRead 
                            ? 'bg-bg-card border-transparent' 
                            : 'bg-white/[0.04] border-border-color'
                        }`}
                      >
                        {/* Unread Indicator */}
                        {!notif.isRead && (
                          <motion.div 
                            layoutId={`unread-${notif.id}`}
                            className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-accent-primary rounded-r-full" 
                          />
                        )}

                        {/* Icon */}
                        <div className={`p-3 rounded-xl shrink-0 ${notif.bgColor} ${notif.color} ring-1 ring-white/5 transition-transform duration-300 group-hover:scale-110`}>
                          <notif.icon size={20} strokeWidth={2} />
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0 pt-0.5">
                          <div className="flex items-center justify-between gap-4 mb-1">
                            <h4 className={`text-sm font-semibold truncate ${notif.isRead ? 'text-text-primary' : 'text-text-primary'}`}>
                              {notif.title}
                            </h4>
                            <span className="text-xs font-mono text-text-muted shrink-0">{notif.time}</span>
                          </div>
                          <motion.p 
                            layout
                            className={`text-sm leading-relaxed ${notif.isRead ? 'text-text-muted' : 'text-text-secondary'} ${isExpanded ? '' : 'line-clamp-1'}`}
                          >
                            {notif.message}
                          </motion.p>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                          {!notif.isRead && (
                            <motion.button 
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                              onClick={(e) => markAsRead(e, notif.id)}
                              className="p-2 rounded-lg text-text-secondary hover:text-accent-primary hover:bg-accent-primary/10 transition-colors"
                              title="Mark as read"
                            >
                              <Check size={16} />
                            </motion.button>
                          )}
                          <motion.button 
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={(e) => deleteNotif(e, notif.id)}
                            className="p-2 rounded-lg text-text-secondary hover:text-error hover:bg-error/10 transition-colors"
                            title="Delete"
                          >
                            <X size={16} />
                          </motion.button>
                        </div>
                      </motion.div>
                    );
                  })}
                </motion.div>
              ) : (
                <motion.div 
                  key="empty"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="h-full flex flex-col items-center justify-center text-text-muted space-y-4 w-full"
                >
                  <div className="w-16 h-16 rounded-full bg-bg-card flex items-center justify-center">
                    <Bell size={24} className="opacity-50" />
                  </div>
                  <p className="text-sm">No notifications found</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </Card>
      </div>
    </div>
  );
};
