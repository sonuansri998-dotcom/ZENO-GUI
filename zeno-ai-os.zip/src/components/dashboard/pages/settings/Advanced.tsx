import React, { useState } from 'react';
import { Card } from '../../shared/Card';
import { Cpu, Terminal, Box, RefreshCcw, AlertOctagon } from 'lucide-react';
import { ConfirmationDialog } from '@/components/shared/ConfirmationDialog';
import { SaveButton } from '@/components/shared/SaveButton';
import { PremiumToggle } from '@/components/shared/PremiumToggle';

export const Advanced = () => {
  const [showResetSettings, setShowResetSettings] = useState(false);
  const [showResetPersona, setShowResetPersona] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [debugMode, setDebugMode] = useState(false);
  const [experimentalFeatures, setExperimentalFeatures] = useState(false);

  const handleChange = () => {
    setIsDirty(true);
  };

  const handleSave = () => {
    setIsDirty(false);
  };

  return (
    <div className="space-y-6">
      <div className="mb-6 animate-stagger-1">
        <h2 className="text-2xl font-bold text-text-primary font-space">Advanced</h2>
        <p className="text-sm text-text-secondary">Developer tools and system diagnostics.</p>
      </div>

      <section className="animate-stagger-2">
        <h3 className="text-sm font-bold text-accent-primary uppercase tracking-wider mb-4 flex items-center gap-2">
          <Terminal size={16} /> Custom Instructions
        </h3>
        <Card className="p-6 border-accent-primary/20">
          <textarea 
            rows={6}
            placeholder="Tell ZENO how to behave in your own words..."
            className="w-full bg-black/20 border border-border-color rounded-lg p-4 text-sm text-text-primary focus:border-accent-primary/50 focus:outline-none transition-colors resize-none font-mono"
            onChange={handleChange}
          />
          <p className="text-xs text-text-muted mt-2">These instructions will guide ZENO's behavior across all interactions.</p>
        </Card>
      </section>

      <section className="animate-stagger-3">
        <h3 className="text-sm font-bold text-accent-secondary uppercase tracking-wider mb-4 flex items-center gap-2">
          <Cpu size={16} /> System
        </h3>
        <Card className="p-6 space-y-4 border-accent-secondary/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-text-primary">Debug Mode</div>
              <div className="text-xs text-text-muted">Show verbose logs and diagnostics</div>
            </div>
            <PremiumToggle 
              checked={debugMode} 
              onChange={(val) => { setDebugMode(val); setIsDirty(true); }} 
              colorClass="bg-accent-secondary" 
            />
          </div>

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div className="flex items-center gap-2">
              <Box size={18} className="text-warning" />
              <div>
                <div className="text-sm font-medium text-text-primary">Experimental Features</div>
                <div className="text-xs text-text-muted">Try new features before they are released</div>
              </div>
            </div>
            <PremiumToggle 
              checked={experimentalFeatures} 
              onChange={(val) => { setExperimentalFeatures(val); setIsDirty(true); }} 
              colorClass="bg-warning" 
            />
          </div>
        </Card>
      </section>

      <section className="animate-stagger-4">
        <h3 className="text-sm font-bold text-error uppercase tracking-wider mb-4 flex items-center gap-2">
          <AlertOctagon size={16} /> Danger Zone
        </h3>
        <Card className="p-6 space-y-4 border-error/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-text-primary">Reset All Settings</div>
              <div className="text-xs text-text-muted">Restore default configuration</div>
            </div>
            <button 
              onClick={() => setShowResetSettings(true)}
              className="px-4 py-2 bg-error/10 hover:bg-error/20 text-error text-xs font-bold rounded border border-error/20 transition-colors"
            >
              Reset Settings
            </button>
          </div>

          <ConfirmationDialog
            isOpen={showResetSettings}
            onClose={() => setShowResetSettings(false)}
            onConfirm={() => setShowResetSettings(false)}
            title="Reset All Settings"
            message="Are you sure? All your settings will be lost."
            confirmText="Confirm Reset"
            isDanger={true}
          />

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div>
              <div className="text-sm font-medium text-text-primary">Reset AI Personality</div>
              <div className="text-xs text-text-muted">Clear learned behaviors and memories</div>
            </div>
            <button 
              onClick={() => setShowResetPersona(true)}
              className="px-4 py-2 bg-error/10 hover:bg-error/20 text-error text-xs font-bold rounded border border-error/20 transition-colors"
            >
              Reset Personality
            </button>
          </div>

          <ConfirmationDialog
            isOpen={showResetPersona}
            onClose={() => setShowResetPersona(false)}
            onConfirm={() => setShowResetPersona(false)}
            title="Reset AI Personality"
            message="Are you sure? ZENO will forget everything about you."
            confirmText="Confirm Reset"
            isDanger={true}
          />
        </Card>
      </section>

      <SaveButton onSave={handleSave} isDirty={isDirty} />
    </div>
  );
};
