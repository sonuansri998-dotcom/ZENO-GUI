import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from '../../shared/Card';
import { Monitor, Globe, Power, Zap, Trash2, Moon } from 'lucide-react';
import { SaveButton } from '@/components/shared/SaveButton';
import { CustomSelect } from '@/components/shared/CustomSelect';
import { Switch } from '@/components/shared/Switch';

export const General = () => {
  const [responseSpeed, setResponseSpeed] = useState('Balanced');
  const [autoClear, setAutoClear] = useState('Never');
  const [dndEnabled, setDndEnabled] = useState(false);
  const [autoStart, setAutoStart] = useState(false);
  const [startMinimized, setStartMinimized] = useState(false);
  const [language, setLanguage] = useState('English (US)');
  const [isDirty, setIsDirty] = useState(false);

  const handleSave = () => {
    // Save logic here
    setIsDirty(false);
  };

  const handleChange = (setter: any, value: any) => {
    setter(value);
    setIsDirty(true);
  };

  const languages = [
    { value: "English (US)", label: "English (US)" },
    { value: "Spanish", label: "Spanish" },
    { value: "French", label: "French" },
    { value: "German", label: "German" },
    { value: "Japanese", label: "Japanese" },
    { value: "Hindi", label: "Hindi" },
    { value: "Arabic", label: "Arabic" },
    { value: "Urdu", label: "Urdu" },
    { value: "Bengali", label: "Bengali" },
    { value: "Chinese", label: "Chinese" },
    { value: "Russian", label: "Russian" },
    { value: "Portuguese", label: "Portuguese" },
    { value: "Turkish", label: "Turkish" },
    { value: "Korean", label: "Korean" },
    { value: "Italian", label: "Italian" },
    { value: "Dutch", label: "Dutch" },
    { value: "Polish", label: "Polish" },
    { value: "Thai", label: "Thai" },
    { value: "Vietnamese", label: "Vietnamese" },
    { value: "Indonesian", label: "Indonesian" }
  ];

  const autoClearOptions = [
    { value: "Daily", label: "Daily" },
    { value: "Weekly", label: "Weekly" },
    { value: "Monthly", label: "Monthly" },
    { value: "Never", label: "Never" }
  ];

  return (
    <div className="space-y-6">
      <div className="mb-6 animate-stagger-1">
        <h2 className="text-2xl font-bold text-white font-space">General Settings</h2>
        <p className="text-sm text-gray-400">Configure global application preferences.</p>
      </div>

      {/* Appearance */}
      <section className="animate-stagger-2 relative z-50">
        <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Monitor size={16} /> Appearance
        </h3>
        <Card className="p-6 space-y-4 border-cyan-500/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Globe size={18} className="text-gray-400" />
              <div>
                <div className="text-sm font-medium text-white">Language</div>
                <div className="text-xs text-gray-500">Select display language</div>
              </div>
            </div>
            <div className="w-40">
              <CustomSelect 
                options={languages}
                value={language}
                onChange={(val) => handleChange(setLanguage, val)}
                className="text-xs"
                buttonClassName="px-3 py-1.5 text-xs bg-black/20"
              />
            </div>
          </div>
        </Card>
      </section>

      {/* Startup */}
      <section className="animate-stagger-3 relative z-40">
        <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Power size={16} /> Startup
        </h3>
        <Card className="p-6 space-y-4 border-emerald-500/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-white">Auto Start with Windows</div>
              <div className="text-xs text-gray-500">Launch ZENO automatically on system boot</div>
            </div>
            <Switch 
              checked={autoStart} 
              onChange={(val) => handleChange(setAutoStart, val)} 
              activeColor="#10b981"
            />
          </div>

          <div className="flex items-center justify-between border-t border-white/5 pt-4">
            <div>
              <div className="text-sm font-medium text-white">Start Minimized</div>
              <div className="text-xs text-gray-500">Start in system tray without opening window</div>
            </div>
            <Switch 
              checked={startMinimized} 
              onChange={(val) => handleChange(setStartMinimized, val)} 
              activeColor="#10b981"
            />
          </div>
        </Card>
      </section>

      {/* Behavior */}
      <section className="animate-stagger-4 relative z-30">
        <h3 className="text-sm font-bold text-purple-400 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Zap size={16} /> Behavior
        </h3>
        <Card className="p-6 space-y-6 border-purple-500/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-white">Response Speed</div>
              <div className="text-xs text-gray-500">Adjust AI processing priority</div>
            </div>
            <div className="flex bg-black/20 rounded-lg p-1 border border-white/10">
              {['Fast', 'Balanced', 'Accurate'].map((s) => (
                <button
                  key={s}
                  onClick={() => handleChange(setResponseSpeed, s)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    responseSpeed === s 
                      ? 'bg-purple-500/20 text-purple-400 shadow-[0_0_10px_rgba(168,85,247,0.2)]' 
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-white/5 pt-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Trash2 size={16} className="text-gray-400" />
                <div>
                  <div className="text-sm font-medium text-white">Auto Clear Chat History</div>
                  <div className="text-xs text-gray-500">Only chat history is cleared. Memories and settings remain safe.</div>
                </div>
              </div>
              <div className="w-32">
                <CustomSelect 
                  options={autoClearOptions}
                  value={autoClear}
                  onChange={(val) => handleChange(setAutoClear, val)}
                  className="text-xs"
                  buttonClassName="px-3 py-1.5 text-xs bg-black/20"
                />
              </div>
            </div>
          </div>

          <div className="border-t border-white/5 pt-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Moon size={16} className="text-gray-400" />
                <div>
                  <div className="text-sm font-medium text-white">Do Not Disturb</div>
                  <div className="text-xs text-gray-500">Silence notifications during specific hours</div>
                </div>
              </div>
              <Switch 
                checked={dndEnabled} 
                onChange={(val) => handleChange(setDndEnabled, val)} 
                activeColor="#a855f7"
              />
            </div>
            
            {dndEnabled && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="flex items-center gap-4 pl-6"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-400">From</span>
                  <input type="time" defaultValue="22:00" onChange={() => setIsDirty(true)} className="bg-black/20 border border-white/10 rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-purple-500/50" />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-400">To</span>
                  <input type="time" defaultValue="07:00" onChange={() => setIsDirty(true)} className="bg-black/20 border border-white/10 rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-purple-500/50" />
                </div>
              </motion.div>
            )}
          </div>
        </Card>
      </section>

      <SaveButton onSave={handleSave} isDirty={isDirty} />
    </div>
  );
};
