import React, { useState } from 'react';
import { Card } from '../../shared/Card';
import { Database, Trash2, RefreshCw, Cloud, Save } from 'lucide-react';
import { ConfirmationDialog } from '@/components/shared/ConfirmationDialog';
import { SaveButton } from '@/components/shared/SaveButton';
import { CustomSelect } from '@/components/shared/CustomSelect';
import { PremiumToggle } from '@/components/shared/PremiumToggle';

export const DataStorage = () => {
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [backupFrequency, setBackupFrequency] = useState('daily');
  const [autoBackup, setAutoBackup] = useState(true);

  const handleFrequencyChange = (val: string) => {
    setBackupFrequency(val);
    setIsDirty(true);
  };

  const handleSave = () => {
    setIsDirty(false);
  };

  const frequencyOptions = [
    { value: 'daily', label: 'Daily' },
    { value: 'weekly', label: 'Weekly' },
    { value: 'monthly', label: 'Monthly' },
  ];

  return (
    <div className="space-y-6">
      <div className="mb-6 animate-stagger-1">
        <h2 className="text-2xl font-bold text-text-primary font-space">Data & Storage</h2>
        <p className="text-sm text-text-secondary">Manage local cache and cloud synchronization.</p>
      </div>

      <section className="animate-stagger-2 relative z-50">
        <h3 className="text-sm font-bold text-warning uppercase tracking-wider mb-4 flex items-center gap-2">
          <Database size={16} /> Storage
        </h3>
        <Card className="p-6 space-y-6 border-warning/20">
          <div>
            <div className="flex justify-between items-end mb-2">
              <span className="text-sm font-medium text-text-primary">Storage Usage</span>
              <span className="text-xs text-text-secondary">234MB / 512MB</span>
            </div>
            <div className="w-full h-2 bg-bg-secondary rounded-full overflow-hidden">
              <div className="h-full w-[45%] bg-warning rounded-full shadow-[0_0_10px_var(--color-warning)]" />
            </div>
          </div>

          <div className="flex gap-4">
            <button className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-bg-card hover:bg-bg-card-hover border border-border-color rounded-lg text-sm text-text-primary transition-colors">
              <Trash2 size={16} className="text-text-secondary" /> Clear Cache
            </button>
            <button 
              onClick={() => setShowClearConfirm(true)}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-error/10 hover:bg-error/20 border border-error/20 rounded-lg text-sm text-error transition-colors"
            >
              <Trash2 size={16} /> Clear All Data
            </button>
          </div>

          <ConfirmationDialog 
            isOpen={showClearConfirm}
            onClose={() => setShowClearConfirm(false)}
            onConfirm={() => setShowClearConfirm(false)}
            title="Clear All Data"
            message="Are you sure? This will delete all local data and cannot be undone."
            confirmText="Yes, Delete Everything"
            isDanger={true}
          />
        </Card>
      </section>

      <section className="animate-stagger-3 relative z-40">
        <h3 className="text-sm font-bold text-accent-primary uppercase tracking-wider mb-4 flex items-center gap-2">
          <Cloud size={16} /> Backup
        </h3>
        <Card className="p-6 space-y-4 border-accent-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-text-primary">Auto Backup</div>
              <div className="text-xs text-text-muted">Automatically back up settings and memories</div>
            </div>
            <PremiumToggle 
              checked={autoBackup} 
              onChange={(val) => { setAutoBackup(val); setIsDirty(true); }} 
              colorClass="bg-accent-primary" 
            />
          </div>

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div>
              <div className="text-sm font-medium text-text-primary">Backup Frequency</div>
              <div className="text-xs text-text-muted">How often to save data</div>
            </div>
            <div className="w-32">
              <CustomSelect 
                options={frequencyOptions}
                value={backupFrequency}
                onChange={handleFrequencyChange}
                className="text-xs"
                buttonClassName="px-3 py-1.5 text-xs bg-black/20"
              />
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div>
              <div className="text-sm font-medium text-text-primary">Last Backup</div>
              <div className="text-xs text-text-muted">Oct 24, 2023 at 10:30 AM</div>
            </div>
            <button className="flex items-center gap-2 px-3 py-1.5 bg-accent-primary/10 hover:bg-accent-primary/20 text-accent-primary text-xs font-bold rounded border border-accent-primary/20 transition-colors">
              <RefreshCw size={14} /> Restore Backup
            </button>
          </div>
        </Card>
      </section>

      <SaveButton onSave={handleSave} isDirty={isDirty} />
    </div>
  );
};
