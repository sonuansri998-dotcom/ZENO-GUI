import React, { useState } from 'react';
import { Card } from '../../shared/Card';
import { Key, Eye, EyeOff, Edit2, Trash2, Plus, Zap, Server, Globe, CheckCircle, XCircle, Save } from 'lucide-react';
import { Modal } from '@/components/shared/Modal';
import { SaveButton } from '@/components/shared/SaveButton';
import { ProviderLogo } from '@/components/shared/ProviderLogo';
import { ConfirmationDialog } from '@/components/shared/ConfirmationDialog';

interface ApiKey {
  id: string;
  nickname: string;
  key: string;
  description?: string;
  status?: 'working' | 'error' | null;
}

interface Provider {
  id: string;
  name: string;
  color: string;
  border: string;
  bg: string;
  keys: ApiKey[];
  isCustom?: boolean;
  modelName?: string;
  baseUrl?: string;
}

export const ApiKeys = () => {
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});
  const [providers, setProviders] = useState<Provider[]>([
    { 
      id: 'gemini', 
      name: 'Gemini API', 
      color: 'text-accent-primary', 
      border: 'border-accent-primary/20', 
      bg: 'bg-accent-primary/10',
      keys: [
        { id: 'gemini-1', nickname: 'My Gemini Key 1', key: 'sk-prod-8374837483748374' }
      ]
    },
    { 
      id: 'groq', 
      name: 'Groq API', 
      color: 'text-warning', 
      border: 'border-warning/20', 
      bg: 'bg-warning/10',
      keys: []
    },
    { 
      id: 'mistral', 
      name: 'Mistral API', 
      color: 'text-accent-secondary', 
      border: 'border-accent-secondary/20', 
      bg: 'bg-accent-secondary/10',
      keys: []
    },
    { 
      id: 'openrouter', 
      name: 'OpenRouter API', 
      color: 'text-success', 
      border: 'border-success/20', 
      bg: 'bg-success/10',
      keys: []
    },
  ]);

  // Modal States
  const [showAddKeyModal, setShowAddKeyModal] = useState(false);
  const [showAddProviderModal, setShowAddProviderModal] = useState(false);
  const [currentProviderId, setCurrentProviderId] = useState<string | null>(null);
  const [providerToDelete, setProviderToDelete] = useState<string | null>(null);

  // Form States
  const [newKeyForm, setNewKeyForm] = useState({ nickname: '', key: '', description: '' });
  const [newProviderForm, setNewProviderForm] = useState({ name: '', model: '', key: '', baseUrl: '', intendedUse: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isTesting, setIsTesting] = useState(false);

  const toggleVisibility = (id: string) => {
    setVisibleKeys(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const validateKeyForm = () => {
    const newErrors: Record<string, string> = {};
    if (!newKeyForm.nickname.trim()) newErrors.nickname = 'Nickname is required';
    if (!newKeyForm.key.trim()) newErrors.key = 'API Key is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateProviderForm = () => {
    const newErrors: Record<string, string> = {};
    if (!newProviderForm.name.trim()) newErrors.name = 'Provider Name is required';
    if (!newProviderForm.model.trim()) newErrors.model = 'Model Name is required';
    if (!newProviderForm.key.trim()) newErrors.key = 'API Key is required';
    if (!newProviderForm.intendedUse.trim()) newErrors.intendedUse = 'Intended Use Case is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddKey = () => {
    if (!validateKeyForm() || !currentProviderId) return;

    setProviders(prev => prev.map(p => {
      if (p.id === currentProviderId) {
        return {
          ...p,
          keys: [...p.keys, { 
            id: `${p.id}-${Date.now()}`, 
            nickname: newKeyForm.nickname, 
            key: newKeyForm.key,
            description: newKeyForm.description
          }]
        };
      }
      return p;
    }));

    setShowAddKeyModal(false);
    setNewKeyForm({ nickname: '', key: '', description: '' });
    setErrors({});
  };

  const handleAddProvider = () => {
    if (!validateProviderForm()) return;

    const newProvider: Provider = {
      id: `custom-${Date.now()}`,
      name: newProviderForm.name,
      modelName: newProviderForm.model,
      baseUrl: newProviderForm.baseUrl,
      isCustom: true,
      color: 'text-text-secondary',
      border: 'border-border-color',
      bg: 'bg-bg-card',
      keys: [{
        id: `custom-${Date.now()}-key`,
        nickname: 'Default Key',
        key: newProviderForm.key,
        description: newProviderForm.intendedUse
      }]
    };

    setProviders(prev => [...prev, newProvider]);
    setShowAddProviderModal(false);
    setNewProviderForm({ name: '', model: '', key: '', baseUrl: '', intendedUse: '' });
    setErrors({});
  };

  const handleDeleteProvider = () => {
    if (providerToDelete) {
      setProviders(prev => prev.filter(p => p.id !== providerToDelete));
      setProviderToDelete(null);
    }
  };

  const handleSaveKey = (providerId: string, keyId: string, newNickname: string, newKey: string) => {
     setProviders(prev => prev.map(p => {
      if (p.id === providerId) {
        return {
          ...p,
          keys: p.keys.map(k => k.id === keyId ? { ...k, nickname: newNickname, key: newKey } : k)
        };
      }
      return p;
    }));
  };

  const handleDeleteKey = (providerId: string, keyId: string) => {
    setProviders(prev => prev.map(p => {
      if (p.id === providerId) {
        return {
          ...p,
          keys: p.keys.filter(k => k.id !== keyId)
        };
      }
      return p;
    }));
  };

  const testAllKeys = async () => {
    setIsTesting(true);
    
    // Simulate testing
    const updatedProviders = [...providers];
    for (const provider of updatedProviders) {
      for (const key of provider.keys) {
        // Mock check: 80% chance of success
        await new Promise(resolve => setTimeout(resolve, 300)); // Simulate network delay
        key.status = Math.random() > 0.2 ? 'working' : 'error';
      }
    }
    
    setProviders(updatedProviders);
    setIsTesting(false);
  };

  const saveAllKeys = () => {
    // In a real app, this would persist to backend/storage
    // For now, we just show the success animation on the button
  };

  return (
    <div className="space-y-6">
      <div className="mb-6 animate-stagger-1">
        <h2 className="text-2xl font-bold text-text-primary font-space">API Keys</h2>
        <p className="text-sm text-text-secondary">Manage access tokens for external services.</p>
      </div>

      {providers.map((provider, i) => (
        <Card key={provider.id} className={`p-6 ${provider.border} animate-stagger-${Math.min(i + 2, 9)}`}>
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-md ${provider.bg} w-10 h-10 flex items-center justify-center overflow-hidden`}>
                <ProviderLogo 
                  providerName={provider.name} 
                  modelName={provider.modelName} 
                  className="w-full h-full"
                  fallbackColor={provider.color}
                />
              </div>
              <div>
                <h3 className="text-sm font-bold text-text-primary uppercase tracking-wider">{provider.name}</h3>
                {provider.isCustom && <span className="text-[10px] text-text-muted">{provider.modelName}</span>}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => { setCurrentProviderId(provider.id); setShowAddKeyModal(true); }}
                className="flex items-center gap-2 px-3 py-1.5 bg-bg-card hover:bg-bg-card-hover text-text-primary hover:text-text-primary text-xs font-bold rounded border border-border-color transition-colors"
              >
                <Plus size={14} /> Add New Key
              </button>
              <button 
                onClick={() => setProviderToDelete(provider.id)}
                className="p-1.5 bg-bg-card hover:bg-error/10 text-text-secondary hover:text-error rounded border border-border-color hover:border-error/20 transition-colors"
                title="Delete Provider"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {provider.keys.length === 0 && (
              <div className="text-center py-4 text-text-muted text-xs italic">No keys added yet.</div>
            )}
            {provider.keys.map((key) => (
              <ApiKeyRow 
                key={key.id} 
                apiKey={key} 
                visible={visibleKeys[key.id]} 
                onToggleVisibility={() => toggleVisibility(key.id)}
                onSave={(nick, k) => handleSaveKey(provider.id, key.id, nick, k)}
                onDelete={() => handleDeleteKey(provider.id, key.id)}
              />
            ))}
          </div>
        </Card>
      ))}

      <section>
        <h3 className="text-sm font-bold text-text-secondary uppercase tracking-wider mb-4 flex items-center gap-2">
          <Server size={16} /> New Model
        </h3>
        <Card className="p-6 border-border-color group hover:border-white/20 transition-colors">
          <button 
            onClick={() => setShowAddProviderModal(true)}
            className="w-full py-4 border border-dashed border-border-color rounded-xl text-text-secondary hover:text-text-primary hover:border-white/30 hover:bg-bg-card transition-colors flex items-center justify-center gap-3 group-hover:scale-[1.01]"
          >
            <div className="w-8 h-8 rounded-full bg-bg-card flex items-center justify-center group-hover:bg-bg-card-hover transition-colors">
              <Plus size={16} />
            </div>
            <span className="font-medium">Add New Model</span>
          </button>
        </Card>
      </section>

      <div className="flex justify-end pt-6 border-t border-glass-border mt-6 gap-4">
        <button 
          onClick={testAllKeys}
          disabled={isTesting}
          className="px-4 py-2 bg-success hover:bg-success/80 text-bg-primary text-xs font-bold rounded-lg border border-success/50 transition-colors shadow-[0_0_20px_var(--color-success)] flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isTesting ? <div className="animate-spin rounded-full h-3 w-3 border-2 border-bg-primary border-t-transparent" /> : <Zap size={14} />}
          {isTesting ? 'Testing...' : 'Test All Keys'}
        </button>
        
        <SaveButton onSave={saveAllKeys} isDirty={true} noWrapper={true} />
      </div>

      {/* Add Key Modal */}
      <Modal 
        isOpen={showAddKeyModal} 
        onClose={() => setShowAddKeyModal(false)} 
        title="Add New API Key"
      >
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs text-text-muted uppercase font-bold">Key Nickname</label>
            <input 
              type="text" 
              value={newKeyForm.nickname}
              onChange={(e) => setNewKeyForm({...newKeyForm, nickname: e.target.value})}
              placeholder="e.g. My Production Key" 
              className={`w-full bg-bg-card border ${errors.nickname ? 'border-error' : 'border-border-color'} rounded-lg p-3 text-sm text-text-primary focus:border-accent-primary/50 outline-none transition-colors`} 
            />
            {errors.nickname && <p className="text-xs text-error">{errors.nickname}</p>}
          </div>
          <div className="space-y-1">
            <label className="text-xs text-text-muted uppercase font-bold">API Key</label>
            <input 
              type="text" 
              value={newKeyForm.key}
              onChange={(e) => setNewKeyForm({...newKeyForm, key: e.target.value})}
              placeholder="sk-..." 
              className={`w-full bg-bg-card border ${errors.key ? 'border-error' : 'border-border-color'} rounded-lg p-3 text-sm text-text-primary focus:border-accent-primary/50 outline-none transition-colors`} 
            />
            {errors.key && <p className="text-xs text-error">{errors.key}</p>}
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button 
              onClick={() => setShowAddKeyModal(false)}
              className="px-4 py-2 text-sm font-medium text-text-secondary hover:text-text-primary transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleAddKey}
              className="px-4 py-2 bg-accent-primary hover:bg-accent-primary/80 text-bg-primary font-bold rounded-lg transition-colors"
            >
              Save Key
            </button>
          </div>
        </div>
      </Modal>

      {/* Add Provider Modal */}
      <Modal 
        isOpen={showAddProviderModal} 
        onClose={() => setShowAddProviderModal(false)} 
        title="Add New Model"
      >
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs text-text-muted uppercase font-bold">Provider Name</label>
            <input 
              type="text" 
              value={newProviderForm.name}
              onChange={(e) => setNewProviderForm({...newProviderForm, name: e.target.value})}
              placeholder="e.g. Local LLM" 
              className={`w-full bg-bg-card border ${errors.name ? 'border-error' : 'border-border-color'} rounded-lg p-3 text-sm text-text-primary focus:border-accent-primary/50 outline-none transition-colors`} 
            />
            {errors.name && <p className="text-xs text-error">{errors.name}</p>}
          </div>
          <div className="space-y-1">
            <label className="text-xs text-text-muted uppercase font-bold">Model Name</label>
            <input 
              type="text" 
              value={newProviderForm.model}
              onChange={(e) => setNewProviderForm({...newProviderForm, model: e.target.value})}
              placeholder="e.g. llama-3-70b" 
              className={`w-full bg-bg-card border ${errors.model ? 'border-error' : 'border-border-color'} rounded-lg p-3 text-sm text-text-primary focus:border-accent-primary/50 outline-none transition-colors`} 
            />
            {errors.model && <p className="text-xs text-error">{errors.model}</p>}
          </div>
          <div className="space-y-1">
            <label className="text-xs text-text-muted uppercase font-bold">Base URL (Optional)</label>
            <input 
              type="text" 
              value={newProviderForm.baseUrl}
              onChange={(e) => setNewProviderForm({...newProviderForm, baseUrl: e.target.value})}
              placeholder="e.g. http://localhost:11434/v1" 
              className="w-full bg-bg-card border border-border-color rounded-lg p-3 text-sm text-text-primary focus:border-accent-primary/50 outline-none transition-colors" 
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-text-muted uppercase font-bold">API Key</label>
            <input 
              type="text" 
              value={newProviderForm.key}
              onChange={(e) => setNewProviderForm({...newProviderForm, key: e.target.value})}
              placeholder="sk-..." 
              className={`w-full bg-bg-card border ${errors.key ? 'border-error' : 'border-border-color'} rounded-lg p-3 text-sm text-text-primary focus:border-accent-primary/50 outline-none transition-colors`} 
            />
            {errors.key && <p className="text-xs text-error">{errors.key}</p>}
          </div>
          <div className="space-y-1">
            <label className="text-xs text-text-muted uppercase font-bold">Intended Use Case</label>
            <textarea 
              value={newProviderForm.intendedUse}
              onChange={(e) => setNewProviderForm({...newProviderForm, intendedUse: e.target.value})}
              placeholder="What will the AI assistant use this model for?" 
              className={`w-full bg-bg-card border ${errors.intendedUse ? 'border-error' : 'border-border-color'} rounded-lg p-3 text-sm text-text-primary focus:border-accent-primary/50 outline-none transition-colors resize-none h-20`} 
            />
            {errors.intendedUse && <p className="text-xs text-error">{errors.intendedUse}</p>}
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button 
              onClick={() => setShowAddProviderModal(false)}
              className="px-4 py-2 text-sm font-medium text-text-secondary hover:text-text-primary transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleAddProvider}
              className="px-4 py-2 bg-accent-primary hover:bg-accent-primary/80 text-bg-primary font-bold rounded-lg transition-colors"
            >
              Confirm
            </button>
          </div>
        </div>
      </Modal>

      <ConfirmationDialog
        isOpen={!!providerToDelete}
        onClose={() => setProviderToDelete(null)}
        onConfirm={handleDeleteProvider}
        title="Delete Provider"
        message="Are you sure you want to delete this provider? All associated API keys will be lost."
        confirmText="Delete"
        isDanger={true}
      />
    </div>
  );
};

interface ApiKeyRowProps {
  apiKey: ApiKey;
  visible: boolean;
  onToggleVisibility: () => void;
  onSave: (nick: string, key: string) => void;
  onDelete: () => void;
}

const ApiKeyRow: React.FC<ApiKeyRowProps> = ({ apiKey, visible, onToggleVisibility, onSave, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editNick, setEditNick] = useState(apiKey.nickname);
  const [editKey, setEditKey] = useState(apiKey.key);
  const [isDirty, setIsDirty] = useState(false);

  const handleSave = () => {
    onSave(editNick, editKey);
    setIsEditing(false);
    setIsDirty(false);
  };

  return (
    <div className="flex items-center justify-between p-4 rounded-xl bg-bg-card border border-glass-border hover:border-border-color transition-colors group">
      <div className="flex-1 mr-4">
        <div className="flex items-center gap-2 mb-1">
          {isEditing ? (
            <input 
              type="text" 
              value={editNick}
              onChange={(e) => { setEditNick(e.target.value); setIsDirty(true); }}
              className="bg-black/40 border border-white/20 rounded px-2 py-0.5 text-sm font-bold text-text-primary outline-none focus:border-accent-primary"
            />
          ) : (
            <span className="text-sm font-bold text-text-primary">{apiKey.nickname}</span>
          )}
          
          {!isEditing && (
            <button 
              onClick={() => setIsEditing(true)}
              className="text-text-muted hover:text-text-primary transition-colors opacity-0 group-hover:opacity-100"
            >
              <Edit2 size={12} />
            </button>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          {isEditing ? (
            <input 
              type="text" 
              value={editKey}
              onChange={(e) => { setEditKey(e.target.value); setIsDirty(true); }}
              className="font-mono text-xs text-text-primary bg-black/40 border border-white/20 rounded px-2 py-1 w-full max-w-[300px] outline-none focus:border-accent-primary"
            />
          ) : (
            <div className="font-mono text-xs text-text-muted bg-black/20 px-2 py-1 rounded inline-block">
              {visible ? apiKey.key : '●●●●●●●●●●●●●●●●'}
            </div>
          )}
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        {apiKey.status === 'working' && <div className="flex items-center gap-1 text-success text-xs font-bold mr-2"><CheckCircle size={14} /> Working</div>}
        {apiKey.status === 'error' && <div className="flex items-center gap-1 text-error text-xs font-bold mr-2"><XCircle size={14} /> Error</div>}

        {isEditing ? (
          <div className="flex gap-2">
             <button 
              onClick={() => { setIsEditing(false); setEditNick(apiKey.nickname); setEditKey(apiKey.key); setIsDirty(false); }}
              className="px-3 py-1.5 text-xs font-medium text-text-secondary hover:text-text-primary transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleSave}
              disabled={!isDirty}
              className={`px-3 py-1.5 text-xs font-bold rounded transition-colors flex items-center gap-1 ${isDirty ? 'bg-accent-primary text-bg-primary hover:bg-accent-primary/80' : 'bg-white/10 text-text-muted cursor-not-allowed'}`}
            >
              <Save size={12} /> Save
            </button>
          </div>
        ) : (
          <>
            <button 
              onClick={onToggleVisibility}
              className="p-2 hover:bg-bg-card-hover rounded-lg text-text-secondary hover:text-text-primary transition-colors"
            >
              {visible ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
            <button 
              onClick={onDelete}
              className="p-2 hover:bg-error/10 rounded-lg text-text-secondary hover:text-error transition-colors"
            >
              <Trash2 size={16} />
            </button>
          </>
        )}
      </div>
    </div>
  );
};
