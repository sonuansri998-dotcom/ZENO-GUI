import React, { useState } from 'react';
import { Card } from '../../shared/Card';
import { Bell, AlertTriangle, Zap, Volume2, Moon } from 'lucide-react';
import { SaveButton } from '@/components/shared/SaveButton';
import { CustomSelect } from '@/components/shared/CustomSelect';
import { Switch } from '@/components/shared/Switch';

export const Notifications = () => {
  const [isDirty, setIsDirty] = useState(false);
  const [alertSound, setAlertSound] = useState('default');
  const [settings, setSettings] = useState({
    taskComplete: true,
    reminderAlert: true,
    apiError: true,
    lowToken: true,
    highRam: true,
    batteryLow: true,
    internetDisconnect: true,
    soundEnabled: true,
    dndOverride: false
  });

  const handleChange = (key: keyof typeof settings, val: boolean) => {
    setSettings(prev => ({ ...prev, [key]: val }));
    setIsDirty(true);
  };

  const handleSoundChange = (val: string) => {
    setAlertSound(val);
    setIsDirty(true);
  };

  const handleSave = () => {
    setIsDirty(false);
  };

  const soundOptions = [
    { value: 'default', label: 'Default' },
    { value: 'soft', label: 'Soft' },
    { value: 'silent', label: 'Silent' },
  ];

  return (
    <div className="space-y-6">
      <div className="mb-6 animate-stagger-1">
        <h2 className="text-2xl font-bold text-text-primary font-space">Notifications</h2>
        <p className="text-sm text-text-secondary">Manage alerts and communication preferences.</p>
      </div>

      <section className="animate-stagger-2 relative z-50">
        <h3 className="text-sm font-bold text-accent-primary uppercase tracking-wider mb-4 flex items-center gap-2">
          <Bell size={16} /> ZENO Alerts
        </h3>
        <Card className="p-6 space-y-4 border-accent-primary/20">
          {[
            { id: 'taskComplete', label: 'Task Complete', desc: 'Notify when a background task finishes' },
            { id: 'reminderAlert', label: 'Reminder Alert', desc: 'Show popups for scheduled reminders' },
            { id: 'apiError', label: 'API Error Alert', desc: 'Warn when connection issues occur' },
            { id: 'lowToken', label: 'Low Token Warning', desc: 'Alert when API usage is high' },
          ].map((item, i) => (
            <div key={i} className={`flex items-center justify-between ${i !== 0 ? 'border-t border-glass-border pt-4' : ''}`}>
              <div>
                <div className="text-sm font-medium text-text-primary">{item.label}</div>
                <div className="text-xs text-text-muted">{item.desc}</div>
              </div>
              <Switch 
                checked={settings[item.id as keyof typeof settings]} 
                onChange={(val) => handleChange(item.id as keyof typeof settings, val)} 
                activeColor="var(--accent-primary)"
              />
            </div>
          ))}
        </Card>
      </section>

      <section className="animate-stagger-3 relative z-40">
        <h3 className="text-sm font-bold text-error uppercase tracking-wider mb-4 flex items-center gap-2">
          <AlertTriangle size={16} /> System Alerts
        </h3>
        <Card className="p-6 space-y-4 border-error/20">
          {[
            { id: 'highRam', label: 'High RAM Usage', desc: 'Warn when memory usage exceeds 80%' },
            { id: 'batteryLow', label: 'Battery Low', desc: 'Alert when battery drops below 20%' },
            { id: 'internetDisconnect', label: 'Internet Disconnect', desc: 'Notify when network connection is lost' },
          ].map((item, i) => (
            <div key={i} className={`flex items-center justify-between ${i !== 0 ? 'border-t border-glass-border pt-4' : ''}`}>
              <div>
                <div className="text-sm font-medium text-text-primary">{item.label}</div>
                <div className="text-xs text-text-muted">{item.desc}</div>
              </div>
              <Switch 
                checked={settings[item.id as keyof typeof settings]} 
                onChange={(val) => handleChange(item.id as keyof typeof settings, val)} 
                activeColor="var(--color-error)"
              />
            </div>
          ))}
        </Card>
      </section>

      <section className="animate-stagger-4 relative z-30">
        <h3 className="text-sm font-bold text-accent-secondary uppercase tracking-wider mb-4 flex items-center gap-2">
          <Volume2 size={16} /> Alert Style
        </h3>
        <Card className="p-6 space-y-4 border-accent-secondary/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-text-primary">Sound</div>
              <div className="text-xs text-text-muted">Play audio for notifications</div>
            </div>
            <Switch 
              checked={settings.soundEnabled} 
              onChange={(val) => handleChange('soundEnabled', val)} 
              activeColor="var(--accent-secondary)"
            />
          </div>

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div>
              <div className="text-sm font-medium text-text-primary">Alert Sound Type</div>
              <div className="text-xs text-text-muted">Select notification tone</div>
            </div>
            <div className="w-32">
              <CustomSelect 
                options={soundOptions}
                value={alertSound}
                onChange={handleSoundChange}
                className="text-xs"
                buttonClassName="px-3 py-1.5 text-xs bg-black/20"
              />
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div className="flex items-center gap-3">
              <Moon size={18} className="text-text-secondary" />
              <div>
                <div className="text-sm font-medium text-text-primary">Do Not Disturb Override</div>
                <div className="text-xs text-text-muted">Allow urgent alerts even during Do Not Disturb.</div>
              </div>
            </div>
            <Switch 
              checked={settings.dndOverride} 
              onChange={(val) => handleChange('dndOverride', val)} 
              activeColor="var(--accent-secondary)"
            />
          </div>
        </Card>
      </section>

      <SaveButton onSave={handleSave} isDirty={isDirty} />
    </div>
  );
};
