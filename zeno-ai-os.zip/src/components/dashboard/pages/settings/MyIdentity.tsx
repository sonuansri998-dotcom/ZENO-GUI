import React, { useState } from 'react';
import { User, Heart, Clock } from 'lucide-react';
import { Card } from '../../shared/Card';
import { SaveButton } from '@/components/shared/SaveButton';
import { PremiumToggle } from '@/components/shared/PremiumToggle';

export const MyIdentity = () => {
  const [isDirty, setIsDirty] = useState(false);
  const [fastingMode, setFastingMode] = useState(false);

  const handleChange = () => {
    setIsDirty(true);
  };

  const handleSave = () => {
    setIsDirty(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="mb-6 animate-stagger-1">
        <h2 className="text-2xl font-bold text-text-primary font-space">My Identity</h2>
        <p className="text-sm text-text-secondary mt-1">Personalize ZENO with your details and preferences.</p>
      </div>

      {/* Basic Info */}
      <section className="animate-stagger-2">
        <h3 className="text-sm font-bold text-accent-primary uppercase tracking-wider mb-4 flex items-center gap-2">
          <User size={16} /> Basic Info
        </h3>
        <Card className="p-6 space-y-6 border-accent-primary/20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary uppercase">Nickname</label>
              <input 
                type="text" 
                placeholder="What should ZENO call you?"
                onChange={handleChange}
                className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-primary/50 focus:outline-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary uppercase">Date of Birth</label>
              <input 
                type="date" 
                onChange={handleChange}
                className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-primary/50 focus:outline-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary uppercase">Occupation</label>
              <input 
                type="text" 
                placeholder="e.g. Software Engineer"
                onChange={handleChange}
                className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-primary/50 focus:outline-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary uppercase">Location / City</label>
              <input 
                type="text" 
                placeholder="e.g. New York, USA"
                onChange={handleChange}
                className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-primary/50 focus:outline-none transition-colors"
              />
              <p className="text-[10px] text-text-muted">Used for weather, prayer times and local news.</p>
            </div>
          </div>
        </Card>
      </section>

      {/* About Me */}
      <section className="animate-stagger-3">
        <h3 className="text-sm font-bold text-accent-secondary uppercase tracking-wider mb-4 flex items-center gap-2">
          <Heart size={16} /> About Me
        </h3>
        <Card className="p-6 space-y-6 border-accent-secondary/20">
          <div className="space-y-2">
            <label className="text-xs font-medium text-text-secondary uppercase">Interests</label>
            <input 
              type="text" 
              placeholder="e.g. AI, Space, Coding (comma separated)"
              onChange={handleChange}
              className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-secondary/50 focus:outline-none transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-text-secondary uppercase">Hobbies</label>
            <input 
              type="text" 
              placeholder="e.g. Reading, Gaming, Hiking"
              onChange={handleChange}
              className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-secondary/50 focus:outline-none transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-text-secondary uppercase">Ambitions / Goals</label>
            <textarea 
              rows={3}
              placeholder="What are you striving for?"
              onChange={handleChange}
              className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-secondary/50 focus:outline-none transition-colors resize-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-text-secondary uppercase">Values / Beliefs</label>
            <textarea 
              rows={3}
              placeholder="What matters most to you?"
              onChange={handleChange}
              className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-secondary/50 focus:outline-none transition-colors resize-none"
            />
          </div>
        </Card>
      </section>

      {/* Lifestyle */}
      <section className="animate-stagger-4">
        <h3 className="text-sm font-bold text-warning uppercase tracking-wider mb-4 flex items-center gap-2">
          <Clock size={16} /> Lifestyle
        </h3>
        <Card className="p-6 space-y-6 border-warning/20">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-medium text-text-primary block">Fasting Mode</span>
              <span className="text-xs text-text-muted">Adjusts schedule for fasting times</span>
            </div>
            <PremiumToggle 
              checked={fastingMode} 
              onChange={(val) => { setFastingMode(val); setIsDirty(true); }} 
              colorClass="bg-warning" 
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary uppercase">Wake Up Time</label>
              <input 
                type="time" 
                onChange={handleChange}
                className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-warning/50 focus:outline-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-text-secondary uppercase">Sleep Time</label>
              <input 
                type="time" 
                onChange={handleChange}
                className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-warning/50 focus:outline-none transition-colors"
              />
            </div>
          </div>
        </Card>
      </section>

      <SaveButton onSave={handleSave} isDirty={isDirty} />
    </div>
  );
};
