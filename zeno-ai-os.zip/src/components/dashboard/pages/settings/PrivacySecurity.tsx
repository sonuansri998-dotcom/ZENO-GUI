import React, { useState } from 'react';
import { Card } from '../../shared/Card';
import { Shield, Lock, Eye, Camera, Mic, EyeOff, Layout } from 'lucide-react';
import { SaveButton } from '@/components/shared/SaveButton';
import { Switch } from '@/components/shared/Switch';

export const PrivacySecurity = () => {
  const [isDirty, setIsDirty] = useState(false);
  const [settings, setSettings] = useState({
    saveConversations: true,
    incognitoMode: false,
    cameraAccess: true,
    micAccess: true,
    hideOnTaskbar: false
  });

  const handleChange = (key: keyof typeof settings, val: boolean) => {
    setSettings(prev => ({ ...prev, [key]: val }));
    setIsDirty(true);
  };

  const handleSave = () => {
    setIsDirty(false);
  };

  return (
    <div className="space-y-6">
      <div className="mb-6 animate-stagger-1">
        <h2 className="text-2xl font-bold text-text-primary font-space">Privacy & Security</h2>
        <p className="text-sm text-text-secondary">Control data sharing and security protocols.</p>
      </div>

      <section className="animate-stagger-2">
        <h3 className="text-sm font-bold text-success uppercase tracking-wider mb-4 flex items-center gap-2">
          <Shield size={16} /> Data Privacy
        </h3>
        <Card className="p-6 space-y-4 border-success/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-text-primary">Save Conversations</div>
              <div className="text-xs text-text-muted">Store chat history for future reference</div>
            </div>
            <Switch 
              checked={settings.saveConversations} 
              onChange={(val) => handleChange('saveConversations', val)} 
              activeColor="var(--color-success)"
            />
          </div>

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div>
              <div className="text-sm font-medium text-text-primary">Incognito Mode</div>
              <div className="text-xs text-text-muted">Nothing from this session will be saved.</div>
            </div>
            <Switch 
              checked={settings.incognitoMode} 
              onChange={(val) => handleChange('incognitoMode', val)} 
              activeColor="var(--color-success)"
            />
          </div>

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div className="flex items-center gap-3">
              <Camera size={18} className="text-text-secondary" />
              <div>
                <div className="text-sm font-medium text-text-primary">Camera Access</div>
                <div className="text-xs text-text-muted">Allow ZENO to use your camera</div>
              </div>
            </div>
            <Switch 
              checked={settings.cameraAccess} 
              onChange={(val) => handleChange('cameraAccess', val)} 
              activeColor="var(--color-success)"
            />
          </div>

          <div className="flex items-center justify-between border-t border-glass-border pt-4">
            <div className="flex items-center gap-3">
              <Mic size={18} className="text-text-secondary" />
              <div>
                <div className="text-sm font-medium text-text-primary">Microphone Access</div>
                <div className="text-xs text-text-muted">Allow ZENO to use your microphone</div>
              </div>
            </div>
            <Switch 
              checked={settings.micAccess} 
              onChange={(val) => handleChange('micAccess', val)} 
              activeColor="var(--color-success)"
            />
          </div>
        </Card>
      </section>

      <section className="animate-stagger-3">
        <h3 className="text-sm font-bold text-error uppercase tracking-wider mb-4 flex items-center gap-2">
          <Lock size={16} /> Security
        </h3>
        <Card className="p-6 space-y-4 border-error/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Layout size={18} className="text-text-secondary" />
              <div>
                <div className="text-sm font-medium text-text-primary">Hide on Taskbar</div>
                <div className="text-xs text-text-muted">Run ZENO in background only</div>
              </div>
            </div>
            <Switch 
              checked={settings.hideOnTaskbar} 
              onChange={(val) => handleChange('hideOnTaskbar', val)} 
              activeColor="var(--color-error)"
            />
          </div>
        </Card>
      </section>

      <SaveButton onSave={handleSave} isDirty={isDirty} />
    </div>
  );
};
