import React, { useState } from 'react';
import { Card } from '../../shared/Card';
import { User, Mail, Smartphone, Calendar, Camera } from 'lucide-react';
import { SaveButton } from '@/components/shared/SaveButton';

export const Account = () => {
  const [isDirty, setIsDirty] = useState(false);

  const handleChange = () => {
    setIsDirty(true);
  };

  const handleSave = () => {
    setIsDirty(false);
  };

  return (
    <div className="space-y-6">
      <div className="mb-6 animate-stagger-1">
        <h2 className="text-2xl font-bold text-text-primary font-space">Account</h2>
        <p className="text-sm text-text-secondary">Manage your profile and security.</p>
      </div>

      <Card className="p-6 border-accent-primary/20 animate-stagger-2">
        <div className="flex flex-col md:flex-row items-center gap-8 mb-8">
          <div className="relative group cursor-pointer">
            <div className="w-24 h-24 rounded-full border-2 border-accent-primary/50 overflow-hidden relative">
              <img src="https://picsum.photos/seed/zeno_user/200/200" alt="User" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera size={24} className="text-text-primary" />
              </div>
            </div>
            <div className="absolute bottom-0 right-0 w-5 h-5 bg-success border-2 border-bg-primary rounded-full"></div>
          </div>
          
          <div className="flex-1 space-y-4 w-full">
            <div className="space-y-1">
              <label className="text-xs text-text-muted uppercase font-bold">Display Name</label>
              <div className="flex items-center gap-3 bg-bg-card border border-border-color rounded-lg px-4 py-2.5 focus-within:border-accent-primary/50 transition-colors">
                <User size={16} className="text-accent-primary" />
                <input 
                  type="text" 
                  defaultValue="Arnold A." 
                  onChange={handleChange}
                  className="bg-transparent w-full text-sm text-text-primary outline-none placeholder-text-muted" 
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-text-muted uppercase font-bold">Connected Gmail</label>
              <div className="flex items-center gap-3 bg-bg-card border border-border-color rounded-lg px-4 py-2.5 opacity-75 cursor-not-allowed">
                <Mail size={16} className="text-text-secondary" />
                <input type="email" value="arnold@gmail.com" readOnly className="bg-transparent w-full text-sm text-text-secondary outline-none cursor-not-allowed" />
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-glass-border pt-6">
          <h3 className="text-sm font-bold text-text-secondary uppercase tracking-wider mb-4">Device Info</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-bg-card rounded-lg p-4 border border-glass-border flex items-center gap-4">
              <div className="p-2 bg-accent-primary/10 rounded-lg">
                <Smartphone size={20} className="text-accent-primary" />
              </div>
              <div>
                <div className="text-xs text-text-muted uppercase">Device Name</div>
                <div className="text-sm font-bold text-text-primary">ZENO-WORKSTATION</div>
              </div>
            </div>
            <div className="bg-bg-card rounded-lg p-4 border border-glass-border flex items-center gap-4">
              <div className="p-2 bg-accent-secondary/10 rounded-lg">
                <Calendar size={20} className="text-accent-secondary" />
              </div>
              <div>
                <div className="text-xs text-text-muted uppercase">Registered Date</div>
                <div className="text-sm font-bold text-text-primary">Oct 24, 2023</div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <SaveButton onSave={handleSave} isDirty={isDirty} />
    </div>
  );
};
