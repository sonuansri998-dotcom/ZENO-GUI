import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

interface SettingsContextType {
  isDirty: boolean;
  setIsDirty: (dirty: boolean) => void;
  pendingSection: string | null;
  setPendingSection: (section: string | null) => void;
  confirmNavigation: () => void;
  cancelNavigation: () => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDirty, setIsDirty] = useState(false);
  const [pendingSection, setPendingSection] = useState<string | null>(null);

  const confirmNavigation = useCallback(() => {
    setIsDirty(false);
    setPendingSection(null);
  }, []);

  const cancelNavigation = useCallback(() => {
    setPendingSection(null);
  }, []);

  return (
    <SettingsContext.Provider value={{ 
      isDirty, 
      setIsDirty, 
      pendingSection, 
      setPendingSection,
      confirmNavigation,
      cancelNavigation
    }}>
      {children}
    </SettingsContext.Provider>
  );
};

// eslint-disable-next-line react-refresh/only-export-components
export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
