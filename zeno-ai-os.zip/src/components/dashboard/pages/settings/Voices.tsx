import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from '../../shared/Card';
import { Mic, Volume2, Play, Pause, Globe, WifiOff, Ban, Settings2 } from 'lucide-react';
import { SaveButton } from '@/components/shared/SaveButton';

const VoiceCard = ({ voice, isSelected, isPlaying, onSelect, onTogglePlay, index }: any) => {
  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ 
        duration: 0.4, 
        delay: index * 0.05,
        ease: [0.23, 1, 0.32, 1]
      }}
      onClick={onSelect}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      whileTap={{ scale: 0.98 }}
      className={`relative p-4 rounded-xl border transition-all cursor-pointer group overflow-hidden ${
        isSelected 
          ? 'bg-accent-primary/10 border-accent-primary' 
          : 'bg-bg-card border-border-color hover:bg-bg-card-hover hover:border-white/20'
      }`}
    >
      <div className="flex justify-between items-start mb-3">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${isSelected ? 'bg-accent-primary text-black' : 'bg-white/10 text-text-secondary'}`}>
          <Mic size={16} />
        </div>
        <motion.button 
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={(e) => { e.stopPropagation(); onTogglePlay(voice.id); }}
          className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-text-primary transition-colors"
        >
          {isPlaying === voice.id ? <Pause size={14} /> : <Play size={14} />}
        </motion.button>
      </div>
      <div className="text-sm font-bold text-text-primary mb-1">{voice.name}</div>
      <div className="text-xs text-text-muted">{voice.gender}</div>
      
      {isSelected && (
        <motion.div 
          layoutId="selectedDot"
          className="absolute top-2 right-2 w-2 h-2 bg-accent-primary rounded-full shadow-[0_0_8px_currentColor]" 
        />
      )}
    </motion.div>
  );
};

export const Voices = () => {
  const [activeTab, setActiveTab] = useState<'online' | 'offline'>('online');
  const [filter, setFilter] = useState('All');
  const [selectedVoice, setSelectedVoice] = useState('Nova');
  const [isPlaying, setIsPlaying] = useState<string | null>(null);
  const [isDirty, setIsDirty] = useState(false);

  const handleChange = () => {
    setIsDirty(true);
  };

  const handleSave = () => {
    setIsDirty(false);
  };

  const onlineVoices = [
    { id: 'nova', name: 'Nova', gender: 'Female' },
    { id: 'echo', name: 'Echo', gender: 'Male' },
    { id: 'fable', name: 'Fable', gender: 'Male' },
    { id: 'onyx', name: 'Onyx', gender: 'Male' },
    { id: 'shimmer', name: 'Shimmer', gender: 'Female' },
    { id: 'alloy', name: 'Alloy', gender: 'Female' },
  ];

  const offlineVoices = [
    { id: 'david', name: 'David', gender: 'Male' },
    { id: 'zira', name: 'Zira', gender: 'Female' },
  ];

  const voices = activeTab === 'online' ? onlineVoices : offlineVoices;
  const filteredVoices = filter === 'All' 
    ? voices 
    : voices.filter(v => v.gender === filter);

  const togglePlay = (id: string) => {
    if (isPlaying === id) {
      setIsPlaying(null);
    } else {
      setIsPlaying(id);
      setTimeout(() => setIsPlaying(null), 3000); // Simulate playback
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
      className="space-y-6"
    >
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-text-primary font-space">Voice Settings</h2>
        <p className="text-sm text-text-secondary">Customize AI speech and audio feedback.</p>
      </div>

      <Card className="p-6 border-accent-primary/20">
        {/* Tabs */}
        <div className="flex gap-4 mb-6 border-b border-border-color pb-4">
          <button 
            onClick={() => setActiveTab('online')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-colors relative ${activeTab === 'online' ? 'text-accent-primary' : 'text-text-secondary hover:text-text-primary'}`}
          >
            <Globe size={16} /> Online
            {activeTab === 'online' && (
              <motion.div layoutId="activeTab" className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-accent-primary" />
            )}
          </button>
          <button 
            onClick={() => setActiveTab('offline')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-colors relative ${activeTab === 'offline' ? 'text-accent-primary' : 'text-text-secondary hover:text-text-primary'}`}
          >
            <WifiOff size={16} /> Offline
            {activeTab === 'offline' && (
              <motion.div layoutId="activeTab" className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-accent-primary" />
            )}
          </button>
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-6">
          {['All', 'Male', 'Female'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${filter === f ? 'bg-white text-black border-white' : 'bg-transparent text-text-secondary border-border-color hover:border-white/30'}`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Voice Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6"
        >
          <AnimatePresence mode="wait">
            {filteredVoices.map((voice, index) => (
              <VoiceCard
                key={voice.id}
                voice={voice}
                index={index}
                isSelected={selectedVoice === voice.name}
                isPlaying={isPlaying}
                onSelect={() => { setSelectedVoice(voice.name); handleChange(); }}
                onTogglePlay={togglePlay}
              />
            ))}

            {/* None Option */}
            <motion.div 
              key="none-option"
              layout
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4, delay: filteredVoices.length * 0.05, ease: [0.23, 1, 0.32, 1] }}
              onClick={() => { setSelectedVoice('None'); handleChange(); }}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
              whileTap={{ scale: 0.98 }}
              className={`relative p-4 rounded-xl border transition-all cursor-pointer group flex flex-col items-center justify-center gap-2 min-h-[100px] overflow-hidden ${
                selectedVoice === 'None' 
                  ? 'bg-error/10 border-error' 
                  : 'bg-bg-card border-border-color hover:bg-bg-card-hover hover:border-white/20'
              }`}
            >
              <Ban size={24} className={selectedVoice === 'None' ? 'text-error' : 'text-text-muted'} />
              <div className={`text-sm font-bold ${selectedVoice === 'None' ? 'text-error' : 'text-text-secondary'}`}>None</div>
            </motion.div>
          </AnimatePresence>
        </motion.div>

        {selectedVoice === 'None' && (
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-xs text-text-muted text-center italic"
          >
            If None is selected, the same voice is used for both online and offline modes.
          </motion.p>
        )}
      </Card>

      {/* Voice Settings */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="p-6 border-accent-secondary/20">
          <h3 className="text-sm font-bold text-accent-secondary uppercase tracking-wider mb-6 flex items-center gap-2">
            <Settings2 size={16} /> Voice Settings
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-xs font-medium text-text-secondary mb-2">
                  <span>Speech Speed</span>
                </div>
                <div className="flex bg-black/20 rounded-lg p-1 border border-border-color">
                  {['Slow', 'Normal', 'Fast'].map((s) => (
                    <button key={s} onClick={handleChange} className="flex-1 py-1.5 text-xs font-medium rounded text-text-secondary hover:text-text-primary hover:bg-bg-card transition-colors focus:bg-accent-secondary/20 focus:text-accent-secondary">
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium text-text-secondary mb-2">
                  <span>Pitch</span>
                </div>
                <div className="flex bg-black/20 rounded-lg p-1 border border-border-color">
                  {['Low', 'Normal', 'High'].map((s) => (
                    <button key={s} onClick={handleChange} className="flex-1 py-1.5 text-xs font-medium rounded text-text-secondary hover:text-text-primary hover:bg-bg-card transition-colors focus:bg-accent-secondary/20 focus:text-accent-secondary">
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium text-text-secondary mb-2">
                  <span>Volume</span>
                  <span className="text-text-primary">80%</span>
                </div>
                <input type="range" onChange={handleChange} className="w-full h-1 bg-bg-secondary rounded-lg appearance-none cursor-pointer accent-accent-secondary" />
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-text-primary">Noise Cancellation</div>
                  <div className="text-xs text-text-muted">Reduce background noise</div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" onChange={handleChange} />
                  <div className="w-11 h-6 bg-bg-secondary peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-border-color after:border after:rounded-full after:h-5 after:w-5 after:transition-all transition-colors duration-300 peer-checked:bg-accent-secondary"></div>
                </label>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium text-text-secondary uppercase">Wake Word</label>
                <input 
                  type="text" 
                  defaultValue="Hey ZENO"
                  onChange={handleChange}
                  className="w-full bg-black/20 border border-border-color rounded-lg px-4 py-2.5 text-text-primary text-sm focus:border-accent-secondary/50 focus:outline-none transition-colors"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium text-text-secondary mb-2">
                  <span>Wake Word Sensitivity</span>
                </div>
                <div className="flex bg-black/20 rounded-lg p-1 border border-border-color">
                  {['Low', 'Medium', 'High'].map((s) => (
                    <button key={s} onClick={handleChange} className="flex-1 py-1.5 text-xs font-medium rounded text-text-secondary hover:text-text-primary hover:bg-bg-card transition-colors focus:bg-accent-secondary/20 focus:text-accent-secondary">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      <SaveButton onSave={handleSave} isDirty={isDirty} />
    </motion.div>
  );
};
