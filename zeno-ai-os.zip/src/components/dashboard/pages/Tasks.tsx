import React, { useState } from 'react';
import { Card } from '../shared/Card';
import { PageHeader } from '@/components/dashboard/shared/PageHeader';
import { Play, Clock, CheckCircle, AlertCircle, Loader, Plus, Calendar, Activity, Zap, Server, ArrowRight, MoreHorizontal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { CustomSelect } from '@/components/shared/CustomSelect';
import { CustomDatePicker } from '@/components/shared/CustomDatePicker';

const TaskCreator = () => {
  const [priority, setPriority] = useState('low');
  const [scheduleDate, setScheduleDate] = useState<Date | null>(null);

  const priorityOptions = [
    { value: 'low', label: 'Low Priority' },
    { value: 'medium', label: 'Medium Priority' },
    { value: 'high', label: 'High Priority' },
    { value: 'critical', label: 'Critical' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
      className="h-full"
    >
      <Card className="p-6 h-full flex flex-col relative group overflow-hidden">
        <div className="absolute inset-0 overflow-hidden rounded-2xl pointer-events-none">
          <div className="absolute top-0 right-0 w-64 h-64 bg-accent-primary/5 rounded-full blur-3xl -mr-20 -mt-20" />
        </div>
        
        <div className="flex justify-between items-center mb-6 relative z-10">
          <div>
            <h3 className="text-lg font-bold text-text-primary font-space flex items-center gap-2">
              <Zap size={20} className="text-accent-primary" />
              New Task
            </h3>
            <p className="text-xs text-text-muted mt-1">Configure and deploy automated jobs</p>
          </div>
        </div>
        
        <div className="flex-1 space-y-5 relative z-10">
          <div className="space-y-1.5">
            <label className="text-[10px] text-text-secondary uppercase font-bold tracking-wider">Task Title</label>
            <input type="text" placeholder="e.g. Analyze market trends" className="w-full bg-bg-primary border border-border-color rounded-xl p-3.5 text-sm text-text-primary focus:border-accent-primary/50 focus:ring-1 focus:ring-accent-primary/50 outline-none transition-all" />
          </div>
          
          <div className="space-y-1.5">
            <label className="text-[10px] text-text-secondary uppercase font-bold tracking-wider">Description</label>
            <textarea placeholder="Describe the task parameters and expected output..." className="w-full bg-bg-primary border border-border-color rounded-xl p-3.5 text-sm text-text-primary h-28 resize-none focus:border-accent-primary/50 focus:ring-1 focus:ring-accent-primary/50 outline-none transition-all custom-scrollbar" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[10px] text-text-secondary uppercase font-bold tracking-wider">Priority</label>
              <CustomSelect 
                options={priorityOptions}
                value={priority}
                onChange={setPriority}
              />
            </div>
            <div className="space-y-1.5">
               <label className="text-[10px] text-text-secondary uppercase font-bold tracking-wider">Schedule</label>
               <CustomDatePicker 
                 value={scheduleDate}
                 onChange={setScheduleDate}
               />
            </div>
          </div>
        </div>

        <div className="mt-8 flex gap-3 relative z-10">
          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="flex-1 bg-gradient-to-r from-accent-primary to-accent-secondary text-black font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all"
          >
            <Play size={16} className="fill-black" /> Deploy Task
          </motion.button>
          <motion.button 
            whileHover={{ scale: 1.02, backgroundColor: 'rgba(255,255,255,0.05)' }}
            whileTap={{ scale: 0.98 }}
            className="flex-1 bg-bg-card text-text-primary font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all border border-border-color hover:border-white/20"
          >
            <Clock size={16} /> Schedule
          </motion.button>
        </div>
      </Card>
    </motion.div>
  );
};

const RunningTasks = () => {
  const [filter, setFilter] = useState('active');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const tasks = [
    { id: 1, title: "Generating Q3 summary report", status: "running", progress: 65, type: "Data Processing", time: "00:12:45", color: "cyan", details: "Processing 45,000 rows of sales data. Generating charts and compiling PDF report. Estimated time remaining: 2 minutes." },
    { id: 2, title: "Image analysis: 'design_v2.png'", status: "queued", progress: 0, type: "Computer Vision", time: "Pending", color: "amber", details: "Waiting for GPU resources. Will perform object detection, color palette extraction, and OCR." },
    { id: 3, title: "Model fine-tuning (Epoch 4/10)", status: "running", progress: 40, type: "Machine Learning", time: "01:45:22", color: "purple", details: "Training on dataset 'customer_support_logs_2023'. Current loss: 0.24. Validation accuracy: 94.2%." },
    { id: 4, title: "Database index optimization", status: "running", progress: 82, type: "System", time: "00:05:12", color: "emerald", details: "Rebuilding indexes on 'users' and 'transactions' tables to improve query performance. No downtime expected." },
    { id: 5, title: "Syncing user data to cloud", status: "queued", progress: 0, type: "Network", time: "Pending", color: "blue", details: "Scheduled to sync 2.4GB of user preferences and session logs to the primary backup server." },
    { id: 6, title: "Generating invoice PDFs", status: "running", progress: 15, type: "Document", time: "00:02:30", color: "rose", details: "Batch processing 150 monthly invoices. Generating PDFs and preparing for email dispatch." },
  ];

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1, ease: [0.23, 1, 0.32, 1] }}
      className="h-full"
    >
      <Card className="p-6 h-full flex flex-col">
        <div className="flex justify-between items-center mb-6 shrink-0">
          <div>
            <h3 className="text-lg font-bold text-text-primary font-space flex items-center gap-2">
              <Activity size={20} className="text-success" />
              Active Queue
            </h3>
            <p className="text-xs text-text-muted mt-1">Real-time task execution monitoring</p>
          </div>
          <div className="flex gap-2 bg-bg-primary p-1 rounded-lg border border-border-color">
            <button onClick={() => setFilter('active')} className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${filter === 'active' ? 'bg-white/10 text-text-primary' : 'text-text-muted hover:text-text-primary'}`}>Active (4)</button>
            <button onClick={() => setFilter('queued')} className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${filter === 'queued' ? 'bg-white/10 text-text-primary' : 'text-text-muted hover:text-text-primary'}`}>Queued (2)</button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 min-h-0 transform-gpu overscroll-contain">
          <div className="space-y-3 w-full">
            <AnimatePresence mode="popLayout">
              {tasks.filter(t => filter === 'active' ? t.status === 'running' : t.status === 'queued').map((task, i) => {
                const isExpanded = expandedId === task.id;
                return (
                  <motion.div 
                    layout
                    key={task.id} 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.3, delay: i * 0.05 }}
                    onClick={() => toggleExpand(task.id)}
                    className={`bg-bg-card rounded-xl p-5 border border-border-color cursor-pointer group relative overflow-hidden transition-all duration-200 hover:border-white/20 hover:bg-white/[0.05]`}
                  >
                      {task.status === 'running' && (
                        <div className={`absolute left-0 top-0 bottom-0 w-1 bg-${task.color}-500`} />
                      )}
                      
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg bg-bg-primary border border-border-color`}>
                            {task.status === 'running' ? (
                              <Loader size={16} className={`text-${task.color}-400 animate-spin`} />
                            ) : (
                              <Clock size={16} className="text-warning" />
                            )}
                          </div>
                          <div>
                            <h4 className="text-sm font-bold text-text-primary group-hover:text-accent-primary transition-colors">{task.title}</h4>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-[10px] text-text-secondary uppercase tracking-wider font-medium">{task.type}</span>
                              <span className="text-text-muted">•</span>
                              <span className="text-[10px] text-text-muted font-mono">{task.time}</span>
                            </div>
                          </div>
                        </div>
                        <button 
                          onClick={(e) => e.stopPropagation()}
                          className="p-1.5 text-text-muted hover:text-text-primary hover:bg-bg-card-hover rounded-md transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <MoreHorizontal size={16} />
                        </button>
                      </div>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div 
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="mb-4 text-sm text-text-secondary leading-relaxed pt-2 border-t border-white/5 mt-2">
                              {task.details}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {task.status === 'running' ? (
                        <div>
                          <div className="flex justify-between items-end mb-1.5">
                            <span className="text-[10px] text-text-muted font-medium uppercase tracking-wider">Progress</span>
                            <span className={`text-xs font-mono font-bold text-${task.color}-400`}>{task.progress}%</span>
                          </div>
                          <div className="w-full h-2 bg-bg-primary rounded-full overflow-hidden border border-border-color relative">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${task.progress}%` }}
                              transition={{ duration: 1, ease: "easeOut" }}
                              className={`h-full bg-${task.color}-500 rounded-full relative`}
                            >
                              <div className="absolute inset-0 bg-white/20 animate-pulse" />
                            </motion.div>
                          </div>
                        </div>
                      ) : (
                        <div className="w-full h-2 bg-bg-primary rounded-full overflow-hidden border border-border-color flex items-center">
                          <div className="w-full h-full bg-warning/20 rounded-full relative overflow-hidden">
                            <motion.div 
                              animate={{ x: ['-100%', '300%'] }}
                              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                              className="absolute inset-0 bg-warning/40 w-1/3" 
                            />
                          </div>
                        </div>
                      )}
                    </motion.div>
                  );
                })}
            </AnimatePresence>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

const TaskHistory = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2, ease: [0.23, 1, 0.32, 1] }}
      className="h-full"
    >
      <Card className="p-6 h-full flex flex-col relative overflow-hidden">
        <div className="absolute bottom-0 right-0 w-48 h-48 bg-success/5 rounded-full blur-3xl -mr-10 -mb-10 pointer-events-none" />
        
        <div className="flex justify-between items-center mb-6 relative z-10">
          <div>
            <h3 className="text-lg font-bold text-text-primary font-space flex items-center gap-2">
              <Server size={20} className="text-success" />
              Metrics
            </h3>
            <p className="text-xs text-text-muted mt-1">System performance</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6 relative z-10 shrink-0">
          {[
            { label: 'Completed', value: '24', color: 'text-text-primary', accent: 'group-hover:text-accent-primary' },
            { label: 'Failed', value: '2', color: 'text-error', accent: 'group-hover:text-error/80' },
            { label: 'Avg Time', value: '1.2s', color: 'text-success', accent: 'group-hover:text-success/80' },
            { label: 'Success', value: '98%', color: 'text-warning', accent: 'group-hover:text-warning/80' },
          ].map((metric, i) => (
            <motion.div 
              key={metric.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + (i * 0.05) }}
              className="bg-bg-primary p-4 rounded-xl border border-border-color hover:border-white/20 transition-colors group cursor-default"
            >
              <div className={`text-2xl font-bold ${metric.color} mb-1 ${metric.accent} transition-colors`}>{metric.value}</div>
              <div className="text-[10px] text-text-muted uppercase tracking-wider font-bold">{metric.label}</div>
            </motion.div>
          ))}
        </div>

        <div className="flex items-center justify-between mb-3 relative z-10 shrink-0">
          <h4 className="text-xs font-bold text-text-secondary uppercase tracking-wider">Recent Log</h4>
          <button className="text-[10px] text-accent-primary hover:text-accent-primary/80 flex items-center gap-1 transition-colors">View All <ArrowRight size={10} /></button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-2 relative z-10 min-h-0 transform-gpu overscroll-contain">
          <AnimatePresence mode="popLayout">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
              <motion.div 
                layout
                key={i} 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + (i * 0.03) }}
                className="flex justify-between items-center p-3 bg-bg-card border border-border-color rounded-xl transition-all group cursor-pointer hover:bg-bg-card-hover hover:border-white/20"
              >
                <div className="flex items-center gap-3">
                  <div className="p-1.5 rounded-md bg-success/10 text-success group-hover:scale-110 transition-transform">
                    <CheckCircle size={12} />
                  </div>
                  <div>
                    <div className="text-xs text-text-primary group-hover:text-text-primary transition-colors font-medium">Data extraction #{1020 + i}</div>
                    <div className="text-[10px] text-text-muted">Success</div>
                  </div>
                </div>
                <div className="text-[10px] text-text-muted font-mono bg-bg-primary px-2 py-1 rounded-md border border-border-color">14:3{i}</div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </Card>
    </motion.div>
  );
};

export const Tasks = () => {
  return (
    <div className="max-w-[1600px] mx-auto h-full flex flex-col">
      <PageHeader title="TASKS" subtitle="MANAGE & EXECUTE" />
      <div className="grid grid-cols-12 gap-6 flex-1 min-h-0 pb-6">
        <div className="col-span-12 md:col-span-4 h-full min-h-0 relative z-50">
          <TaskCreator />
        </div>
        <div className="col-span-12 md:col-span-5 h-full min-h-0 relative z-40">
          <RunningTasks />
        </div>
        <div className="col-span-12 md:col-span-3 h-full min-h-0 relative z-30">
          <TaskHistory />
        </div>
      </div>
    </div>
  );
};
