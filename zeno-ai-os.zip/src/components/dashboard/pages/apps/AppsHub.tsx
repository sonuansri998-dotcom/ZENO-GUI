import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { NotepadApp } from './NotepadApp';
import { Box } from 'lucide-react';

export const AppsHub = () => {
  const [activeApp, setActiveApp] = useState<string | null>(null);

  const apps = [
    {
      id: 'notepad',
      name: 'Notepad',
      iconUrl: 'https://static.vecteezy.com/system/resources/previews/022/451/232/original/notepad-with-pencil-icon-3d-illustration-png.png'
    }
  ];

  const handleAppClick = (e: React.MouseEvent, appId: string) => {
    setActiveApp(appId);
  };

  return (
    <div className="h-full w-full relative overflow-hidden bg-transparent">
      {/* The Hub (Always rendered) */}
      <div className="relative z-10 h-full flex flex-col">
        <div className="px-12 pt-16 pb-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.05)]">
              <Box size={24} className="text-white/80" />
            </div>
            <div>
              <h1 className="text-4xl font-light tracking-tight text-white">Apps</h1>
            </div>
          </motion.div>
        </div>

        <div className="px-12 flex-1 overflow-y-auto pb-12 pt-16 flex justify-center items-start">
          <div className="flex flex-wrap justify-center gap-16 max-w-5xl mx-auto">
            {apps.map((app, index) => (
              <motion.div
                key={app.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: index * 0.05 }}
                onClick={(e) => handleAppClick(e, app.id)}
                className="group relative flex flex-col items-center gap-5 cursor-pointer will-change-[opacity,transform]"
              >
                {/* Pure White Circle App Icon */}
                <div 
                  className="w-32 h-32 rounded-[2.5rem] bg-white flex items-center justify-center shadow-2xl transition-[transform,box-shadow] duration-500 group-hover:scale-105 group-hover:shadow-[0_0_30px_rgba(255,255,255,0.15)]"
                >
                  <img 
                    src={app.iconUrl} 
                    alt={app.name} 
                    className="w-24 h-24 object-contain transition-transform duration-500 group-hover:scale-110" 
                  />
                </div>
                
                {/* Plain Text Name */}
                <div className="text-base font-medium text-white/80 tracking-wide transition-colors group-hover:text-white">
                  {app.name}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* The App Overlay */}
      <AnimatePresence>
        {activeApp === 'notepad' && (
          <motion.div 
            key="notepad-app-wrapper"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="absolute inset-0 z-50 overflow-hidden bg-white will-change-[opacity,transform] shadow-2xl"
          >
            <NotepadApp onBack={() => setActiveApp(null)} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
