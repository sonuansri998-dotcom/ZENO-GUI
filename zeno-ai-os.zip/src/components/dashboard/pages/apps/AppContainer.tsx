import React, { useRef, useState, useEffect } from 'react';
import { Maximize2, Minimize2, ArrowLeft, Box } from 'lucide-react';
import { motion } from 'motion/react';

interface AppContainerProps {
  title: React.ReactNode;
  onBack: () => void;
  children: React.ReactNode;
  headerActions?: React.ReactNode;
  theme?: 'light' | 'dark';
  icon?: React.ReactNode;
}

export const AppContainer: React.FC<AppContainerProps> = ({ title, onBack, children, headerActions, theme = 'dark', icon }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen().catch(err => console.log(err));
    } else {
      document.exitFullscreen();
    }
  };

  const isLight = theme === 'light';

  return (
    <div 
      ref={containerRef} 
      className={`h-full w-full flex flex-col relative overflow-hidden rounded-3xl border shadow-2xl will-change-transform ${isLight ? 'bg-[#FAFAFA] text-gray-900 border-gray-200/50' : 'bg-[#050505] text-white border-white/10'}`}
    >
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {isLight ? (
          <>
            <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-50/40 blur-[100px] rounded-full" />
            <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-gray-100/40 blur-[100px] rounded-full" />
          </>
        ) : (
          <>
            <div className="absolute top-[-50%] left-[-20%] w-[150%] h-[100%] bg-gradient-to-b from-white/5 via-transparent to-transparent -rotate-45 blur-3xl mix-blend-screen" />
            <div className="absolute top-[-50%] right-[-20%] w-[150%] h-[100%] bg-gradient-to-b from-white/5 via-transparent to-transparent rotate-45 blur-3xl mix-blend-screen" />
          </>
        )}
      </div>
      
      {/* Header */}
      <div className={`relative z-20 px-6 py-4 border-b flex items-center justify-between backdrop-blur-xl ${isLight ? 'border-gray-200/50 bg-white/60' : 'border-white/10 bg-black/40'}`}>
         <div className="flex items-center gap-4">
            <button onClick={onBack} className={`p-2 rounded-full transition-colors ${isLight ? 'hover:bg-gray-200/50 text-gray-500 hover:text-gray-900' : 'hover:bg-white/10 text-gray-400 hover:text-white'}`}>
              <ArrowLeft size={20}/>
            </button>
            <div className="flex items-center gap-3">
               <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isLight ? 'bg-gray-100 text-gray-700' : 'bg-white/10 text-white'}`}>
                 {icon || <Box size={18} strokeWidth={2} />}
               </div>
               <div className="font-bold text-lg">{title}</div>
            </div>
         </div>
         <div className="flex items-center gap-2">
            {headerActions}
            <div className={`w-px h-6 mx-2 ${isLight ? 'bg-gray-300' : 'bg-white/10'}`} />
            <button onClick={toggleFullscreen} className={`p-2 rounded-full transition-colors ${isLight ? 'hover:bg-gray-200/50 text-gray-500 hover:text-gray-900' : 'hover:bg-white/10 text-gray-400 hover:text-white'}`} title="Toggle Fullscreen">
              {isFullscreen ? <Minimize2 size={18}/> : <Maximize2 size={18}/>}
            </button>
         </div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 flex-1 overflow-hidden">
         {children}
      </div>
    </div>
  );
};
