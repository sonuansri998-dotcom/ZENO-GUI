import React, { useState, useRef, useEffect } from 'react';
import { Save, Download, MoreVertical, CheckCircle2, Bold, Italic, Underline, Heading1, Heading2, AlignLeft, AlignCenter, List, Type, Box, Pencil, Plus, Trash2, Settings2, Minus } from 'lucide-react';
import { AppContainer } from './AppContainer';
import { motion, AnimatePresence } from 'motion/react';

interface NotepadAppProps {
  onBack: () => void;
}

export const NotepadApp: React.FC<NotepadAppProps> = ({ onBack }) => {
  const [pages, setPages] = useState([{ id: '1', title: 'Untitled Document', content: '' }]);
  const [activePageId, setActivePageId] = useState('1');
  const [isSaved, setIsSaved] = useState(true);
  const [showFormatMenu, setShowFormatMenu] = useState(false);
  const [showFontMenu, setShowFontMenu] = useState(false);
  const [fontSize, setFontSize] = useState(18);
  const [fontFamily, setFontFamily] = useState('font-inter');
  
  const editorRef = useRef<HTMLDivElement>(null);
  const activePage = pages.find(p => p.id === activePageId) || pages[0];

  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.innerHTML = activePage.content || '';
    }
  }, [activePageId, activePage.content]);

  const handleInput = () => {
    setIsSaved(false);
    if (editorRef.current) {
      const newContent = editorRef.current.innerHTML;
      setPages(prev => prev.map(p => p.id === activePageId ? { ...p, content: newContent } : p));
    }
  };

  const handleSave = () => {
    setIsSaved(true);
  };

  const handleDownload = () => {
    if (!editorRef.current) return;
    const content = editorRef.current.innerHTML;
    const blob = new Blob([content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${activePage.title || 'document'}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const execCmd = (cmd: string, value?: string) => {
    document.execCommand(cmd, false, value);
    editorRef.current?.focus();
    setIsSaved(false);
  };

  const addPage = () => {
    const newId = Date.now().toString();
    setPages(prev => [...prev, { id: newId, title: 'New Page', content: '' }]);
    setActivePageId(newId);
  };

  const removePage = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (pages.length === 1) return;
    const newPages = pages.filter(p => p.id !== id);
    setPages(newPages);
    if (activePageId === id) {
      setActivePageId(newPages[0].id);
    }
  };

  const headerActions = (
    <>
      <div className="flex items-center gap-2 text-xs font-medium mr-4">
        {isSaved ? (
          <span className="flex items-center gap-1.5 text-gray-400"><CheckCircle2 size={14} /> Saved</span>
        ) : (
          <span className="flex items-center gap-1.5 text-amber-500">Unsaved</span>
        )}
      </div>
      <button onClick={handleSave} className="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors text-gray-600 hover:text-gray-900" title="Save">
        <Save size={16} />
      </button>
      <button onClick={handleDownload} className="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors text-gray-600 hover:text-gray-900" title="Download">
        <Download size={16} />
      </button>
      <button className="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors text-gray-600 hover:text-gray-900">
        <MoreVertical size={16} />
      </button>
    </>
  );

  return (
    <AppContainer 
      theme="light"
      icon={<img src="https://static.vecteezy.com/system/resources/previews/022/451/232/original/notepad-with-pencil-icon-3d-illustration-png.png" alt="Notepad" className="w-6 h-6 object-contain" />}
      title={
        <div className="flex items-center gap-2 group cursor-text">
          <input 
            type="text" 
            value={activePage.title}
            onChange={(e) => {
              const newTitle = e.target.value;
              setPages(prev => prev.map(p => p.id === activePageId ? { ...p, title: newTitle } : p));
              setIsSaved(false);
            }}
            className="bg-transparent border-none outline-none text-gray-900 font-semibold w-48 focus:ring-0 p-0 placeholder:text-gray-400 transition-colors hover:text-blue-600 focus:text-blue-600"
            placeholder="Document Title"
          />
          <Pencil size={16} className="text-gray-400 opacity-50 group-hover:opacity-100 group-hover:text-blue-600 transition-all" />
        </div>
      }
      onBack={onBack}
      headerActions={headerActions}
    >
      <div className="h-full flex relative bg-white">
        
        {/* Sidebar for Pages */}
        <div className="w-64 border-r border-gray-100 bg-gray-50/30 p-4 flex flex-col gap-2 z-10">
          <button onClick={addPage} className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 p-2 rounded-lg hover:bg-gray-200/50 transition-colors">
            <Plus size={16} /> New Page
          </button>
          <div className="flex-1 overflow-y-auto space-y-1 mt-4">
            {pages.map(page => (
              <div 
                key={page.id} 
                onClick={() => setActivePageId(page.id)}
                className={`group flex items-center justify-between p-2.5 rounded-lg cursor-pointer transition-colors ${activePageId === page.id ? 'bg-white shadow-sm border border-gray-200/50 text-blue-600' : 'hover:bg-gray-200/50 text-gray-600'}`}
              >
                <span className="truncate text-sm font-medium">{page.title || 'Untitled'}</span>
                {pages.length > 1 && (
                  <button onClick={(e) => removePage(page.id, e)} className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-red-50 text-red-500 rounded-md transition-all">
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Editor Area */}
        <div className="flex-1 relative flex flex-col">
          <div className="flex-1 overflow-y-auto px-8 py-12 md:px-12 md:py-16">
            <div 
              ref={editorRef}
              contentEditable
              onInput={handleInput}
              className={`w-full outline-none text-gray-800 leading-relaxed min-h-full pb-32 text-left ${fontFamily}`}
              style={{ fontSize: `${fontSize}px` }}
              data-placeholder="Start typing or ask AI to write something..."
            />
          </div>

          {/* Click outside overlay for menus */}
          {(showFormatMenu || showFontMenu) && (
            <div className="absolute inset-0 z-40" onClick={() => { setShowFormatMenu(false); setShowFontMenu(false); }} />
          )}

          {/* Floating Minimal Toolbar */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-50">
            <div className="bg-white/90 backdrop-blur-xl border border-gray-200 shadow-[0_8px_30px_rgba(0,0,0,0.08)] rounded-full px-4 py-2 flex items-center gap-2 transition-all duration-300">
              
              <button 
                onClick={() => { setShowFormatMenu(!showFormatMenu); setShowFontMenu(false); }}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${showFormatMenu ? 'bg-gray-900 text-white' : 'hover:bg-gray-100 text-gray-700'}`}
                title="Text Format"
              >
                <Type size={18} />
              </button>

              <button 
                onClick={() => { setShowFontMenu(!showFontMenu); setShowFormatMenu(false); }}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${showFontMenu ? 'bg-gray-900 text-white' : 'hover:bg-gray-100 text-gray-700'}`}
                title="Font Settings"
              >
                <Settings2 size={18} />
              </button>

              <div className="w-px h-6 bg-gray-200 mx-1" />

              <button className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-blue-50 text-blue-600 transition-colors" title="AI Tools">
                <Box size={18} />
              </button>

              {/* Expandable Format Menu */}
              <AnimatePresence>
                {showFormatMenu && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, y: 10 }}
                    className="absolute bottom-16 left-0 bg-white border border-gray-200 shadow-xl rounded-2xl p-2 flex items-center gap-1"
                  >
                    <button onClick={() => execCmd('formatBlock', 'H1')} className="w-9 h-9 rounded hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors" title="Heading 1"><Heading1 size={16}/></button>
                    <button onClick={() => execCmd('formatBlock', 'H2')} className="w-9 h-9 rounded hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors" title="Heading 2"><Heading2 size={16}/></button>
                    <div className="w-px h-5 bg-gray-200 mx-1" />
                    <button onClick={() => execCmd('bold')} className="w-9 h-9 rounded hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors" title="Bold"><Bold size={16}/></button>
                    <button onClick={() => execCmd('italic')} className="w-9 h-9 rounded hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors" title="Italic"><Italic size={16}/></button>
                    <button onClick={() => execCmd('underline')} className="w-9 h-9 rounded hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors" title="Underline"><Underline size={16}/></button>
                    <div className="w-px h-5 bg-gray-200 mx-1" />
                    <button onClick={() => execCmd('justifyLeft')} className="w-9 h-9 rounded hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors" title="Align Left"><AlignLeft size={16}/></button>
                    <button onClick={() => execCmd('justifyCenter')} className="w-9 h-9 rounded hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors" title="Align Center"><AlignCenter size={16}/></button>
                    <button onClick={() => execCmd('insertUnorderedList')} className="w-9 h-9 rounded hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors" title="Bullet List"><List size={16}/></button>
                  </motion.div>
                )}

                {showFontMenu && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, y: 10 }}
                    className="absolute bottom-16 left-12 bg-white border border-gray-200 shadow-xl rounded-2xl p-2 flex flex-col gap-2 min-w-[160px]"
                  >
                    <div className="flex items-center justify-between px-2 py-1">
                      <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Size</span>
                      <div className="flex items-center gap-2 bg-gray-50 rounded-lg p-1 border border-gray-100">
                        <button onClick={() => setFontSize(Math.max(12, fontSize - 2))} className="w-6 h-6 rounded flex items-center justify-center hover:bg-white hover:shadow-sm text-gray-700"><Minus size={14}/></button>
                        <span className="text-sm font-medium w-6 text-center">{fontSize}</span>
                        <button onClick={() => setFontSize(Math.min(48, fontSize + 2))} className="w-6 h-6 rounded flex items-center justify-center hover:bg-white hover:shadow-sm text-gray-700"><Plus size={14}/></button>
                      </div>
                    </div>
                    <div className="w-full h-px bg-gray-100" />
                    <div className="flex flex-col gap-1">
                      <button onClick={() => setFontFamily('font-inter')} className={`text-left px-3 py-2 rounded-lg text-sm transition-colors ${fontFamily === 'font-inter' ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-gray-50 text-gray-700'}`}>Inter (Sans)</button>
                      <button onClick={() => setFontFamily('font-serif')} className={`text-left px-3 py-2 rounded-lg text-sm transition-colors ${fontFamily === 'font-serif' ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-gray-50 text-gray-700'}`}>Georgia (Serif)</button>
                      <button onClick={() => setFontFamily('font-mono')} className={`text-left px-3 py-2 rounded-lg text-sm transition-colors ${fontFamily === 'font-mono' ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-gray-50 text-gray-700'}`}>Mono</button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </AppContainer>
  );
};
