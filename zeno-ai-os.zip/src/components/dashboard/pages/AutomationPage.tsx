import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Power, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  XCircle, 
  Clock, 
  Check, 
  Loader2, 
  History,
  Box,
  Cpu,
  Zap,
  Activity,
  Shield,
  BarChart3,
  Layers,
  Settings2,
  ChevronDown,
  ChevronUp,
  X,
  Calendar,
  Filter
} from 'lucide-react';

// Generate 3 months of mock data
const generateHistory = () => {
  const data = [];
  const now = new Date();
  for (let i = 0; i < 90; i++) {
    const date = new Date();
    date.setDate(now.getDate() - i);
    const created = Math.floor(Math.random() * 6);
    const failed = Math.random() > 0.8 ? Math.floor(Math.random() * 2) : 0;
    const uploaded = Math.max(0, created - failed);
    const views = created > 0 ? `${(Math.random() * 20 + 2).toFixed(1)}K` : '0';
    
    data.push({
      id: i,
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: i > 30 ? 'numeric' : undefined }),
      fullDate: date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
      created,
      uploaded,
      failed,
      views,
      efficiency: created > 0 ? Math.round((uploaded / created) * 100) : 100,
      details: [
        { time: '09:00 AM', task: 'Trend Analysis', status: 'Success' },
        { time: '11:30 AM', task: 'Video Generation', status: failed > 0 ? 'Failed' : 'Success' },
        { time: '02:15 PM', task: 'Voice Synthesis', status: 'Success' },
        { time: '06:00 PM', task: 'Social Upload', status: uploaded > 0 ? 'Success' : 'Skipped' }
      ]
    });
  }
  return data;
};

const ALL_HISTORY = generateHistory();

const AGENTS = [
  { id: 1, icon: '📅', name: 'Calendar Agent', desc: 'Plans your content for the entire week!', color: '#00f5ff', status: 'DONE', progress: 100 },
  { id: 2, icon: '🔍', name: 'Trend Scout', desc: 'Discovers trending topics for your niche!', color: '#00ffcc', status: 'DONE', progress: 100 },
  { id: 3, icon: '✍️', name: 'Script Writer', desc: 'Writes video scripts and optimizes SEO!', color: '#8888ff', status: 'DONE', progress: 100 },
  { id: 4, icon: '🎬', name: 'Video Prompter', desc: 'Prepares prompts for AI video generation!', color: '#ffaa44', status: 'ACTIVE', progress: 65 },
  { id: 5, icon: '🎙️', name: 'Voice Studio', desc: 'Converts scripts into high-quality voiceovers!', color: '#ff6688', status: 'WAITING', progress: 0 },
  { id: 6, icon: '🎵', name: 'Music Maestro', desc: 'Generates custom background music!', color: '#44ddaa', status: 'IDLE', progress: 0 },
  { id: 7, icon: '🎨', name: 'Thumbnail Artist', desc: 'Creates click-worthy thumbnails!', color: '#ff88cc', status: 'IDLE', progress: 0 },
  { id: 8, icon: '💬', name: 'Caption Master', desc: 'Generates automatic captions and subtitles!', color: '#aaffaa', status: 'IDLE', progress: 0 },
  { id: 9, icon: '🔗', name: 'Combiner', desc: 'Merges video, voice, and music tracks!', color: '#00f5ff', status: 'IDLE', progress: 0 },
  { id: 10, icon: '📐', name: 'Format Agent', desc: 'Resizes content for all social platforms!', color: '#ffcc44', status: 'IDLE', progress: 0 },
  { id: 11, icon: '🏷️', name: 'SEO Optimizer', desc: 'Adds optimized keywords and hashtags!', color: '#88ffcc', status: 'IDLE', progress: 0 },
  { id: 12, icon: '⏰', name: 'Scheduler', desc: 'Schedules uploads for peak engagement!', color: '#aa88ff', status: 'IDLE', progress: 0 },
  { id: 13, icon: '📤', name: 'Upload Manager', desc: 'Manages uploads across all platforms!', color: '#ff8844', status: 'IDLE', progress: 0 },
  { id: 14, icon: '💰', name: 'Affiliate Linker', desc: 'Automatically adds affiliate and earning links!', color: '#44ffdd', status: 'IDLE', progress: 0 },
  { id: 15, icon: '🛡️', name: 'Error Guard', desc: 'Monitors for errors 24/7!', color: '#ff4466', status: 'IDLE', progress: 0 },
  { id: 16, icon: '📊', name: 'Analytics Brain', desc: 'Tracks and analyzes content performance!', color: '#ffcc00', status: 'IDLE', progress: 0 },
];

const PIPELINE_STEPS = [
  { id: 'plan', label: 'Plan', status: 'done' },
  { id: 'trend', label: 'Trend', status: 'done' },
  { id: 'script', label: 'Script', status: 'done' },
  { id: 'prompt', label: 'Prompt', status: 'current' },
  { id: 'voice', label: 'Voice', status: 'manual' },
  { id: 'music', label: 'Music', status: 'pending' },
  { id: 'merge', label: 'Merge', status: 'pending' },
  { id: 'thumb', label: 'Thumb', status: 'pending' },
  { id: 'captions', label: 'Captions', status: 'pending' },
  { id: 'format', label: 'Format', status: 'pending' },
  { id: 'upload', label: 'Upload', status: 'pending' },
  { id: 'done', label: 'Done!', status: 'pending' },
];

const LOGS = [
  { id: 1, time: '10:00:01', type: 'INFO', msg: 'ZENO Engine started.' },
  { id: 2, time: '10:00:05', type: 'OK', msg: 'Calendar Agent: Content plan ready.' },
  { id: 3, time: '10:01:12', type: 'OK', msg: 'Trend Scout: Found 3 trending topics.' },
  { id: 4, time: '10:03:45', type: 'OK', msg: 'Script Writer: Script generated with SEO.' },
  { id: 5, time: '10:04:10', type: 'INFO', msg: 'Video Prompter: Generating prompts...' },
  { id: 6, time: '10:05:00', type: 'WARN', msg: 'Voice Studio: Waiting for manual voice clone approval.' },
];

const HistoryItem = React.memo(({ item, isModal = false }: { item: any, isModal?: boolean, key?: any }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div 
      className={`group cursor-pointer rounded-2xl border overflow-hidden transform-gpu will-change-[background-color,border-color] transition-colors duration-200 ${
        isExpanded ? 'bg-white/[0.08] border-white/30' : 'bg-white/[0.02] border-white/5 hover:border-white/10 hover:bg-white/[0.04]'
      }`}
      onClick={() => setIsExpanded(!isExpanded)}
    >
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${item.failed > 0 ? 'bg-error/10 text-error' : 'bg-success/10 text-success'}`}>
            {item.failed > 0 ? <AlertTriangle size={20} /> : <CheckCircle2 size={20} />}
          </div>
          <div>
            <h4 className="font-bold text-text-primary text-sm tracking-tight">{item.date}</h4>
            <div className="flex gap-3 text-[10px] font-bold uppercase tracking-widest text-text-muted">
              <span className="flex items-center gap-1"><Zap size={10} className="text-accent-primary" /> {item.views} Views</span>
              <span className={item.failed > 0 ? 'text-error' : 'text-success'}>{item.efficiency}% Efficiency</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="hidden sm:flex gap-4 text-[10px] font-bold uppercase tracking-widest text-text-muted">
            <div className="flex flex-col items-center">
              <span className="text-text-primary">{item.created}</span>
              <span>Created</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-success">{item.uploaded}</span>
              <span>Passed</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-error">{item.failed}</span>
              <span>Failed</span>
            </div>
          </div>
          <div
            className={`text-text-muted transition-transform duration-300 ${isExpanded ? 'rotate-180' : 'rotate-0'}`}
          >
            <ChevronDown size={16} />
          </div>
        </div>
      </div>

      <div 
        className={`grid transition-all duration-300 ease-out transform-gpu will-change-[grid-template-rows,opacity] ${isExpanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
      >
        <div className="overflow-hidden">
          <div className="px-4 pb-4 pt-2 border-t border-white/5 space-y-3">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {item.details.map((detail: any, idx: number) => (
                <div key={idx} className="p-2 rounded-lg bg-black/20 border border-white/5">
                  <div className="text-[8px] text-text-muted uppercase mb-1">{detail.time}</div>
                  <div className="text-[10px] font-bold text-text-primary mb-1">{detail.task}</div>
                  <div className={`text-[9px] font-bold uppercase ${detail.status === 'Success' ? 'text-success' : detail.status === 'Failed' ? 'text-error' : 'text-text-muted'}`}>
                    {detail.status}
                  </div>
                </div>
              ))}
            </div>
            {isModal && (
              <div className="text-[10px] text-text-muted italic">
                Full production logs available for this session.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
});

export const AutomationPage = () => {
  const [isEngineOn, setIsEngineOn] = useState(true);
  const [showManualStep, setShowManualStep] = useState(true);
  const [showFullHistory, setShowFullHistory] = useState(false);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'success' | 'error'>('all');
  const [visibleCount, setVisibleCount] = useState(20);
  const consoleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, []);

  const recentHistory = useMemo(() => ALL_HISTORY.slice(0, 5), []);

  const filteredHistory = useMemo(() => {
    let filtered = ALL_HISTORY;
    if (historyFilter === 'success') filtered = ALL_HISTORY.filter(h => h.failed === 0);
    if (historyFilter === 'error') filtered = ALL_HISTORY.filter(h => h.failed > 0);
    return filtered;
  }, [historyFilter]);

  const displayedHistory = useMemo(() => filteredHistory.slice(0, visibleCount), [filteredHistory, visibleCount]);

  const handleOpenFullHistory = () => {
    setVisibleCount(20);
    setShowFullHistory(true);
  };

  const handleFilterChange = (filter: 'all' | 'success' | 'error') => {
    setVisibleCount(20);
    setHistoryFilter(filter);
  };

  return (
    <div className="flex flex-col gap-6 pb-12 max-w-[1600px] mx-auto animate-fade-in h-full overflow-y-auto custom-scrollbar pr-2 transform-gpu overscroll-contain">
      
      {/* HEADER SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 bg-bg-card border border-glass-border rounded-[2.5rem] p-8 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-accent-primary/10 via-transparent to-transparent pointer-events-none" />
          
          <div className="flex flex-col md:flex-row items-center gap-10 relative z-10">
            <div className="relative group/engine">
              <div className={`absolute inset-0 blur-[60px] rounded-full transition-all duration-1000 ${isEngineOn ? 'bg-accent-primary/40 scale-150' : 'bg-error/20 scale-110'}`} />
              <div className={`w-40 h-40 rounded-[2.5rem] border-2 flex items-center justify-center relative transition-all duration-700 overflow-hidden ${
                isEngineOn ? 'border-accent-primary/50 bg-accent-primary/10' : 'border-error/30 bg-error/5'
              }`}>
                <div className={`absolute inset-0 bg-gradient-to-t from-black/40 to-transparent transition-opacity duration-500 ${isEngineOn ? 'opacity-100' : 'opacity-0'}`} />
                <Cpu size={80} className={`transition-all duration-1000 ease-out ${isEngineOn ? 'text-accent-primary rotate-0 scale-110' : 'text-error rotate-45 opacity-50 scale-90'}`} />
                {isEngineOn && (
                  <>
                    <div className="absolute inset-2 border border-accent-primary/20 rounded-[2rem] animate-[spin_10s_linear_infinite]" />
                    <div className="absolute inset-8 border border-accent-primary/10 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
                    <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-accent-primary animate-pulse" />
                  </>
                )}
              </div>
              <div className={`absolute -bottom-4 left-1/2 -translate-x-1/2 px-6 py-1.5 rounded-full text-[11px] font-black uppercase tracking-[0.3em] border transition-all duration-700 ${
                isEngineOn ? 'bg-accent-primary text-black border-accent-primary' : 'bg-error text-white border-error'
              }`}>
                {isEngineOn ? 'Active' : 'Offline'}
              </div>
            </div>

            <div className="flex-1 text-center md:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 mb-4">
                <div className={`w-1.5 h-1.5 rounded-full ${isEngineOn ? 'bg-success animate-pulse' : 'bg-error'}`} />
                <span className="text-[10px] font-bold text-text-muted uppercase tracking-widest">System Status: {isEngineOn ? 'Optimal' : 'Halted'}</span>
              </div>
              <div className="flex items-center justify-center md:justify-start gap-4 mb-3">
                <h1 className="text-5xl font-black text-text-primary tracking-tighter leading-none">ZENO<span className="text-accent-primary">.</span></h1>
                <div className="h-10 w-[1px] bg-white/10 hidden md:block" />
                <div className="flex flex-col items-start">
                  <span className="text-xs font-bold text-text-muted uppercase tracking-[0.2em]">Automation Engine</span>
                  <span className="text-[10px] font-mono text-accent-primary/70">Build v4.0.2-stable</span>
                </div>
              </div>
              <p className="text-text-secondary text-lg font-medium max-w-xl leading-relaxed opacity-80">
                Next-gen autonomous content generation. Orchestrating 16 specialized agents in real-time.
              </p>
            </div>

            <div className="shrink-0 flex flex-col items-center gap-4">
              <motion.button
                onClick={() => setIsEngineOn(!isEngineOn)}
                className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-700 relative group/btn overflow-hidden ${
                  isEngineOn ? 'bg-success text-bg-primary' : 'bg-error text-white'
                }`}
                whileHover={{ scale: 1.05, y: -5 }}
                whileTap={{ scale: 0.95 }}
              >
                <div className="absolute inset-0 bg-gradient-to-tr from-white/20 to-transparent opacity-0 group-hover/btn:opacity-100 transition-opacity" />
                <Power size={40} className="relative z-10" />
              </motion.button>
              <span className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Master Toggle</span>
            </div>
          </div>
        </div>

        <div className="bg-bg-card border border-glass-border rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden">
          <div className="space-y-6 relative z-10">
            <h3 className="text-[10px] font-bold text-text-muted uppercase tracking-[0.2em]">Real-time Metrics</h3>
            <div className="space-y-4">
              {[
                { label: 'Videos Today', value: '3', trend: '+20%' },
                { label: 'Active Agents', value: '4/16', trend: 'Stable' },
                { label: 'Pending Tasks', value: '1', trend: 'Action Required', alert: true },
              ].map((stat, i) => (
                <div key={i} className="flex justify-between items-end border-b border-white/5 pb-2">
                  <div>
                    <div className="text-[10px] text-text-muted uppercase mb-1">{stat.label}</div>
                    <div className={`text-2xl font-black ${stat.alert ? 'text-warning' : 'text-text-primary'}`}>{stat.value}</div>
                  </div>
                  <div className={`text-[9px] font-bold ${stat.alert ? 'text-warning' : 'text-success'}`}>{stat.trend}</div>
                </div>
              ))}
            </div>
          </div>
          <button className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-bold uppercase tracking-widest transition-colors mt-4">
            View Analytics
          </button>
        </div>
      </div>

      {/* MAIN CONTENT GRID */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <div className="xl:col-span-8 space-y-6">
          {/* LIVE PIPELINE */}
          <div className="bg-bg-card border border-glass-border rounded-3xl p-6 relative overflow-hidden">
            <h3 className="text-xs font-bold text-text-muted uppercase tracking-[0.2em] mb-8 flex items-center gap-2">
              <Layers size={14} /> Live Production Pipeline
            </h3>
            <div className="flex items-center justify-between gap-2 overflow-x-auto pb-4 scrollbar-hide">
              {PIPELINE_STEPS.map((step, index) => (
                <div key={step.id} className="flex items-center gap-2 shrink-0">
                  <div className="flex flex-col items-center gap-2">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border-2 transition-all duration-500 ${
                      step.status === 'done' ? 'bg-success/10 border-success text-success' :
                      step.status === 'current' ? 'bg-accent-primary/10 border-accent-primary text-accent-primary' :
                      step.status === 'manual' ? 'bg-warning/10 border-warning text-warning' :
                      'bg-white/[0.02] border-white/5 text-text-muted'
                    }`}>
                      {step.status === 'done' ? <Check size={20} /> :
                       step.status === 'current' ? <Loader2 size={20} className="animate-spin" /> :
                       step.status === 'manual' ? <AlertTriangle size={20} /> :
                       <Clock size={20} />}
                    </div>
                    <span className={`text-[9px] font-bold uppercase tracking-widest ${
                      step.status === 'done' ? 'text-success' :
                      step.status === 'current' ? 'text-accent-primary' :
                      step.status === 'manual' ? 'text-warning' :
                      'text-text-muted'
                    }`}>{step.label}</span>
                  </div>
                  {index < PIPELINE_STEPS.length - 1 && (
                    <div className={`w-6 h-[1px] mb-6 ${step.status === 'done' ? 'bg-success/50' : 'bg-white/5'}`} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* AGENT FLEET */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-text-muted uppercase tracking-[0.2em] flex items-center gap-2">
              <Box size={14} /> Agent Fleet <span className="text-accent-primary font-mono">(16)</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {AGENTS.map(agent => (
                <div key={agent.id} className="bg-gradient-to-br from-bg-card to-bg-card-hover border border-glass-border rounded-2xl p-5 hover:border-accent-primary/50 transition-all duration-300 group relative overflow-hidden">
                  <div className={`absolute top-0 left-0 w-1 h-full transition-all duration-500 ${
                    agent.status === 'DONE' ? 'bg-success' :
                    agent.status === 'ACTIVE' ? 'bg-accent-primary' :
                    agent.status === 'WAITING' ? 'bg-warning' :
                    'bg-white/5'
                  }`} />
                  <div className="flex flex-col h-full">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-xl group-hover:scale-110 transition-transform duration-500">{agent.icon}</div>
                        <div>
                          <h4 className="font-bold text-text-primary text-sm tracking-tight">{agent.name}</h4>
                          <div className={`text-[8px] font-bold uppercase tracking-widest ${
                            agent.status === 'DONE' ? 'text-success' :
                            agent.status === 'ACTIVE' ? 'text-accent-primary' :
                            agent.status === 'WAITING' ? 'text-warning' :
                            'text-text-muted'
                          }`}>{agent.status}</div>
                        </div>
                      </div>
                      <button className="p-1.5 rounded-lg bg-white/10 text-text-muted hover:text-text-primary transition-colors"><Settings2 size={12} /></button>
                    </div>
                    <p className="text-[11px] text-text-secondary mb-6 leading-relaxed line-clamp-2">{agent.desc}</p>
                    <div className="mt-auto space-y-2">
                      <div className="flex justify-between text-[9px] font-bold uppercase tracking-widest">
                        <span className="text-text-muted">Efficiency</span>
                        <span className="text-text-primary">{agent.progress}%</span>
                      </div>
                      <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${agent.progress}%` }}
                          transition={{ duration: 1.5, ease: "easeOut" }}
                          style={{ backgroundColor: agent.status === 'DONE' ? '#10b981' : agent.status === 'ACTIVE' ? agent.color : agent.status === 'WAITING' ? '#f59e0b' : '#3f3f46' }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="xl:col-span-4 space-y-6">
          {/* LIVE CONSOLE */}
          <div className="bg-[#050505] border border-glass-border rounded-3xl p-6 h-[400px] flex flex-col relative overflow-hidden">
            <h3 className="text-xs font-bold text-text-muted uppercase tracking-[0.2em] mb-6 flex items-center gap-2 relative z-10">
              <Terminal size={14} /> System Console
            </h3>
            <div 
              ref={consoleRef}
              className="flex-1 overflow-y-auto custom-scrollbar space-y-3 pr-2 font-mono text-[10px] relative z-10 transform-gpu overscroll-contain"
            >
              {LOGS.map(log => (
                <div key={log.id} className="flex gap-3 items-start group">
                  <span className="text-text-muted shrink-0 opacity-50">[{log.time}]</span>
                  <span className={`shrink-0 font-bold w-12 ${log.type === 'INFO' ? 'text-accent-primary' : log.type === 'OK' ? 'text-success' : log.type === 'WARN' ? 'text-warning' : 'text-error'}`}>{log.type}</span>
                  <span className="text-text-primary/90 group-hover:text-text-primary transition-colors">{log.msg}</span>
                </div>
              ))}
            </div>
          </div>

          {/* PRODUCTION HISTORY */}
          <div className="bg-bg-card border border-glass-border rounded-3xl p-6 flex flex-col h-[600px]">
            <h3 className="text-xs font-bold text-text-muted uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
              <History size={14} /> Production History
            </h3>
            <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar transform-gpu overscroll-contain">
              {recentHistory.map(item => (
                <HistoryItem key={item.id} item={item} />
              ))}
            </div>
            <button 
              onClick={handleOpenFullHistory}
              className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-bold uppercase tracking-widest transition-colors mt-6"
            >
              Full History
            </button>
          </div>
        </div>
      </div>

      {/* FULL HISTORY MODAL - macOS Style */}
      {typeof document !== 'undefined' && createPortal(
        <AnimatePresence>
          {showFullHistory && (
            <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 sm:p-6 overflow-hidden">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowFullHistory(false)}
                className="absolute inset-0 bg-black/90 backdrop-blur-sm"
              />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ 
                type: "spring", 
                damping: 25, 
                stiffness: 350 
              }}
              className="relative w-full max-w-4xl h-[90vh] md:h-[85vh] bg-[#0D0D0D] border border-white/10 rounded-[2rem] flex flex-col overflow-hidden"
            >
              {/* Modal Header */}
              <div className="px-6 py-5 sm:px-8 sm:py-6 border-b border-white/5 flex items-center justify-between bg-white/[0.03] shrink-0">
                <div className="flex items-center gap-4 sm:gap-5">
                  <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-accent-primary/10 flex items-center justify-center text-accent-primary shrink-0">
                    <History size={24} className="sm:w-7 sm:h-7" />
                  </div>
                  <div>
                    <h2 className="text-xl sm:text-2xl font-black text-text-primary tracking-tight">Production Archives</h2>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-success animate-pulse shrink-0" />
                      <p className="text-text-muted text-[9px] sm:text-[10px] font-bold uppercase tracking-[0.2em] truncate">Real-time Database Sync Active</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 shrink-0">
                  <button 
                    onClick={() => setShowFullHistory(false)}
                    className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-text-muted hover:text-text-primary transition-colors"
                  >
                    <X size={20} className="sm:w-6 sm:h-6" />
                  </button>
                </div>
              </div>

              {/* Modal Content */}
              <div className="flex-1 overflow-y-auto p-6 sm:p-8 custom-scrollbar space-y-6 transform-gpu overscroll-contain will-change-scroll">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
                  <div className="flex p-1 rounded-2xl bg-white/5 border border-white/10 w-full sm:w-auto">
                    <motion.div layout className="flex w-full sm:w-auto">
                      {[
                        { id: 'all', label: 'All Logs' },
                        { id: 'success', label: 'Success' },
                        { id: 'error', label: 'Errors' }
                      ].map((tab) => (
                        <button 
                          key={tab.id}
                          onClick={() => handleFilterChange(tab.id as any)}
                          className={`relative flex-1 sm:flex-none px-6 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-colors z-10 ${
                            historyFilter === tab.id 
                              ? 'text-black' 
                              : 'text-text-muted hover:text-text-primary'
                          }`}
                        >
                          {historyFilter === tab.id && (
                            <motion.div
                              layoutId="activeTab"
                              className="absolute inset-0 bg-accent-primary rounded-xl -z-10"
                              transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                            />
                          )}
                          {tab.label}
                        </button>
                      ))}
                    </motion.div>
                  </div>
                  <div className="flex items-center gap-4 w-full sm:w-auto">
                    <div className="relative flex-1 sm:w-64">
                      <Filter size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted group-focus-within:text-white transition-colors duration-300" />
                      <input 
                        type="text" 
                        placeholder="Search logs..." 
                        className="w-full bg-white/5 border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-xs text-text-primary placeholder:text-text-muted focus:outline-none focus:border-white/30 focus:bg-white/10 transition-all duration-300 ease-out"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3 sm:gap-4">
                  {displayedHistory.map((item) => (
                    <HistoryItem key={item.id} item={item} isModal />
                  ))}
                  
                  {visibleCount < filteredHistory.length && (
                    <button 
                      onClick={() => setVisibleCount(prev => prev + 20)}
                      className="w-full py-4 mt-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 text-xs font-bold text-text-muted hover:text-text-primary transition-all duration-200 active:scale-[0.98] transform-gpu"
                    >
                      Load More Records ({filteredHistory.length - visibleCount} remaining)
                    </button>
                  )}
                  
                  {filteredHistory.length === 0 && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="py-12 sm:py-20 text-center"
                    >
                      <div className="w-12 h-12 sm:w-16 sm:h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4 text-text-muted">
                        <Info size={24} className="sm:w-8 sm:h-8" />
                      </div>
                      <h4 className="text-text-primary font-bold">No records found</h4>
                      <p className="text-text-muted text-xs">Try adjusting your filters</p>
                    </motion.div>
                  )}
                </div>
              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 sm:px-8 sm:py-5 border-t border-white/5 bg-white/[0.03] flex justify-between items-center shrink-0">
                <div className="flex items-center gap-6">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Total Records</span>
                    <span className="text-lg font-black text-text-primary">{filteredHistory.length}</span>
                  </div>
                </div>
                <button 
                  onClick={() => setShowFullHistory(false)}
                  className="px-8 py-3 rounded-2xl bg-white text-black text-[11px] font-black uppercase tracking-widest hover:scale-105 transition-all"
                >
                  Close Archive
                </button>
              </div>
            </motion.div>
          </div>
        )}
        </AnimatePresence>,
        document.body
      )}
    </div>
  );
};

const Terminal = ({ size, className }: { size?: number, className?: string }) => (
  <svg 
    width={size || 24} 
    height={size || 24} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <polyline points="4 17 10 11 4 5" />
    <line x1="12" y1="19" x2="20" y2="19" />
  </svg>
);
