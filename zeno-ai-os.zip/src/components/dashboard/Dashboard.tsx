import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar } from './shared/Navbar';
import { Overview } from './pages/Overview';
import { Tasks } from './pages/Tasks';
import { Memory } from './pages/Memory';
import { Files } from './pages/Files';
import { Notifs } from './pages/Notifs';
import { Settings } from './pages/Settings';
import { AutomationPage } from './pages/AutomationPage';
import { AppsHub } from './pages/apps/AppsHub';
import { COLORS } from './shared/constants';

interface DashboardProps {
  onBack: () => void;
  initialTab?: string;
}

export const Dashboard: React.FC<DashboardProps> = ({ onBack, initialTab = 'overview' }) => {
  const [activeTab, setActiveTab] = useState(initialTab);

  const [particles] = useState(() => {
    return Array.from({ length: 60 }).map((_, i) => ({
      id: i,
      width: Math.random() * 4 + 1 + 'px',
      height: Math.random() * 4 + 1 + 'px',
      top: Math.random() * 40 - 20 + '%',
      right: Math.random() * 40 - 20 + '%',
      animationDuration: Math.random() * 15 + 15 + 's',
      animationDelay: '-' + Math.random() * 30 + 's',
    }));
  });

  const renderContent = () => {
    switch (activeTab) {
      case 'overview': return <Overview />;
      case 'tasks': return <Tasks />;
      case 'memory': return <Memory />;
      case 'files': return <Files />;
      case 'apps': return <AppsHub />;
      case 'notifs': return <Notifs />;
      case 'settings': return <Settings />;
      case 'automation': return <AutomationPage />;
      case 'profile': return <Settings />; // Reusing settings for profile for now
      default: return <Overview />;
    }
  };

  return (
    <div className="w-full h-screen bg-bg-primary flex overflow-hidden font-inter text-text-primary selection:bg-accent-primary/20">
      {/* Pro Cinematic Animated Rays (Optimized for Performance & Visuals) */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {/* Ray Container - Rotated to point from top-right to bottom-left */}
        <div className="absolute top-[-30%] right-[-20%] w-[150%] h-[150%] origin-top-right rotate-[45deg] pointer-events-none opacity-90">
          {/* Beam 1 (Main) */}
          <div className="absolute top-0 right-[20%] w-[15%] h-full bg-gradient-to-b from-blue-400/60 via-blue-500/20 to-transparent animate-[ray-pulse_8s_ease-in-out_infinite_alternate]" style={{ maskImage: 'linear-gradient(to right, transparent, black 20%, black 80%, transparent)', WebkitMaskImage: 'linear-gradient(to right, transparent, black 20%, black 80%, transparent)' }} />
          {/* Beam 2 (Thin, brighter) */}
          <div className="absolute top-0 right-[40%] w-[5%] h-full bg-gradient-to-b from-cyan-300/80 via-cyan-400/30 to-transparent animate-[ray-pulse_11s_ease-in-out_infinite_alternate_1s]" style={{ maskImage: 'linear-gradient(to right, transparent, black 20%, black 80%, transparent)', WebkitMaskImage: 'linear-gradient(to right, transparent, black 20%, black 80%, transparent)' }} />
          {/* Beam 3 (Wide, faint) */}
          <div className="absolute top-0 right-[50%] w-[25%] h-full bg-gradient-to-b from-blue-500/40 via-blue-600/10 to-transparent animate-[ray-pulse_14s_ease-in-out_infinite_alternate_2s]" style={{ maskImage: 'linear-gradient(to right, transparent, black 20%, black 80%, transparent)', WebkitMaskImage: 'linear-gradient(to right, transparent, black 20%, black 80%, transparent)' }} />
          {/* Beam 4 (Edge) */}
          <div className="absolute top-0 right-[75%] w-[8%] h-full bg-gradient-to-b from-blue-300/50 via-blue-400/20 to-transparent animate-[ray-pulse_10s_ease-in-out_infinite_alternate_3s]" style={{ maskImage: 'linear-gradient(to right, transparent, black 20%, black 80%, transparent)', WebkitMaskImage: 'linear-gradient(to right, transparent, black 20%, black 80%, transparent)' }} />
        </div>
        
        {/* Particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {particles.map((particle) => (
            <div 
              key={particle.id}
              className="absolute rounded-full bg-blue-100/90 animate-[float-particle_linear_infinite]"
              style={{
                width: particle.width,
                height: particle.height,
                top: particle.top,
                right: particle.right,
                animationDuration: particle.animationDuration,
                animationDelay: particle.animationDelay,
              }}
            />
          ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden relative z-10">
        <Navbar onBack={onBack} activeTab={activeTab} setActiveTab={setActiveTab} />

        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="popLayout">
            <motion.div 
              key={activeTab}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className={`h-full w-full will-change-[opacity,transform] ${activeTab === 'apps' ? 'p-0' : 'p-6'}`}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
